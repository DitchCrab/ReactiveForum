(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['webpack:webpack'] = {};

})();

//# sourceMappingURL=webpack_webpack.js.map
