(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ReactMeteorData = Package['react-meteor-data'].ReactMeteorData;
var React = Package['react-runtime'].React;
var ReactDOM = Package['react-runtime'].ReactDOM;
var ReactDOMServer = Package['react-runtime'].ReactDOMServer;
var ReactRouter = Package['reactrouter:react-router'].ReactRouter;
var FastRender = Package['meteorhacks:fast-render'].FastRender;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var RoutePolicy = Package.routepolicy.RoutePolicy;
var babelHelpers = Package['babel-runtime'].babelHelpers;

/* Package-scope variables */
var ReactRouterSSR, html;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/reactrouter_react-router-ssr/lib/react-router-ssr.js                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
ReactRouterSSR = {};                                                                                                  // 1
                                                                                                                      // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/reactrouter_react-router-ssr/lib/server.jsx.js                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// meteor algorithm to check if this is a meteor serving http request or not                                          // 1
function IsAppUrl(req) {                                                                                              // 2
  var url = req.url;                                                                                                  // 3
  if (url === '/favicon.ico' || url === '/robots.txt') {                                                              // 4
    return false;                                                                                                     // 5
  }                                                                                                                   // 6
                                                                                                                      // 7
  // NOTE: app.manifest is not a web standard like favicon.ico and                                                    // 8
  // robots.txt. It is a file name we have chosen to use for HTML5                                                    // 9
  // appcache URLs. It is included here to prevent using an appcache                                                  // 10
  // then removing it from poisoning an app permanently. Eventually,                                                  // 11
  // once we have server side routing, this won't be needed as                                                        // 12
  // unknown URLs with return a 404 automatically.                                                                    // 13
  if (url === '/app.manifest') {                                                                                      // 14
    return false;                                                                                                     // 15
  }                                                                                                                   // 16
                                                                                                                      // 17
  // Avoid serving app HTML for declared routes such as /sockjs/.                                                     // 18
  if (RoutePolicy.classify(url)) {                                                                                    // 19
    return false;                                                                                                     // 20
  }                                                                                                                   // 21
  return true;                                                                                                        // 22
}                                                                                                                     // 23
                                                                                                                      // 24
var _ReactRouter = ReactRouter;                                                                                       // 25
var Router = _ReactRouter.Router;                                                                                     // 26
                                                                                                                      // 27
var url = Npm.require('url');                                                                                         // 28
var Fiber = Npm.require('fibers');                                                                                    // 29
var cookieParser = Npm.require('cookie-parser');                                                                      // 30
                                                                                                                      // 31
var webpackStats = undefined;                                                                                         // 32
                                                                                                                      // 33
ReactRouterSSR.LoadWebpackStats = function (stats) {                                                                  // 34
  webpackStats = stats;                                                                                               // 35
};                                                                                                                    // 36
                                                                                                                      // 37
ReactRouterSSR.Run = function (routes, clientOptions, serverOptions) {                                                // 38
  if (!clientOptions) {                                                                                               // 39
    clientOptions = {};                                                                                               // 40
  }                                                                                                                   // 41
                                                                                                                      // 42
  if (!serverOptions) {                                                                                               // 43
    serverOptions = {};                                                                                               // 44
  }                                                                                                                   // 45
                                                                                                                      // 46
  if (!serverOptions.webpackStats) {                                                                                  // 47
    serverOptions.webpackStats = webpackStats;                                                                        // 48
  }                                                                                                                   // 49
                                                                                                                      // 50
  Meteor.bindEnvironment(function () {                                                                                // 51
    // Parse cookies for the login token                                                                              // 52
    WebApp.rawConnectHandlers.use(cookieParser());                                                                    // 53
                                                                                                                      // 54
    WebApp.connectHandlers.use(Meteor.bindEnvironment(function (req, res, next) {                                     // 55
      if (!IsAppUrl(req)) {                                                                                           // 56
        next();                                                                                                       // 57
        return;                                                                                                       // 58
      }                                                                                                               // 59
                                                                                                                      // 60
      var history = ReactRouter.history.createMemoryHistory(req.url);                                                 // 61
                                                                                                                      // 62
      var path = req.url;                                                                                             // 63
      var loginToken = req.cookies['meteor_login_token'];                                                             // 64
      var headers = req.headers;                                                                                      // 65
                                                                                                                      // 66
      var css = null;                                                                                                 // 67
                                                                                                                      // 68
      var context = new FastRender._Context(loginToken, { headers: headers });                                        // 69
                                                                                                                      // 70
      try {                                                                                                           // 71
        FastRender.frContext.withValue(context, function () {                                                         // 72
          var originalSubscribe = Meteor.subscribe;                                                                   // 73
                                                                                                                      // 74
          Meteor.subscribe = function (name) {                                                                        // 75
            for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
              args[_key - 1] = arguments[_key];                                                                       // 77
            }                                                                                                         // 78
                                                                                                                      // 79
            if (Package.mongo && !Package.autopublish) {                                                              // 80
              Mongo.Collection._isSSR = false;                                                                        // 81
              var publishResult = Meteor.server.publish_handlers[name].apply(context, args);                          // 82
              Mongo.Collection._isSSR = true;                                                                         // 83
                                                                                                                      // 84
              Mongo.Collection._fakePublish(publishResult);                                                           // 85
            }                                                                                                         // 86
                                                                                                                      // 87
            context.subscribe.apply(context, arguments);                                                              // 88
                                                                                                                      // 89
            return {                                                                                                  // 90
              stop: function () {}, // Nothing to stop on server-rendering                                            // 91
              ready: function () {                                                                                    // 92
                return true;                                                                                          // 93
              } // server gets the data straight away                                                                 // 94
            };                                                                                                        // 95
          };                                                                                                          // 96
                                                                                                                      // 97
          if (Package.mongo && !Package.autopublish) {                                                                // 98
            Mongo.Collection._isSSR = true;                                                                           // 99
            Mongo.Collection._publishSelectorsSSR = {};                                                               // 100
          }                                                                                                           // 101
                                                                                                                      // 102
          var originalUserId = Meteor.userId;                                                                         // 103
          var originalUser = Meteor.user;                                                                             // 104
                                                                                                                      // 105
          // This should be the state of the client when he remount the app                                           // 106
          Meteor.userId = function () {                                                                               // 107
            return context.userId;                                                                                    // 108
          };                                                                                                          // 109
          Meteor.user = function () {                                                                                 // 110
            return undefined;                                                                                         // 111
          };                                                                                                          // 112
                                                                                                                      // 113
          if (serverOptions.preRender) {                                                                              // 114
            serverOptions.preRender(req, res);                                                                        // 115
          }                                                                                                           // 116
                                                                                                                      // 117
          global.__STYLE_COLLECTOR_MODULES__ = [];                                                                    // 118
          global.__STYLE_COLLECTOR__ = '';                                                                            // 119
          global.__CHUNK_COLLECTOR__ = [];                                                                            // 120
                                                                                                                      // 121
          html = ReactDOMServer.renderToString(React.createElement(Router, babelHelpers._extends({                    // 122
            history: history,                                                                                         // 123
            children: routes                                                                                          // 124
          }, serverOptions.props)));                                                                                  // 125
                                                                                                                      // 126
          css = global.__STYLE_COLLECTOR__;                                                                           // 127
                                                                                                                      // 128
          if (serverOptions.postRender) {                                                                             // 129
            serverOptions.postRender(req, res);                                                                       // 130
          }                                                                                                           // 131
                                                                                                                      // 132
          Meteor.subscribe = originalSubscribe;                                                                       // 133
          Meteor.userId = originalUserId;                                                                             // 134
          Meteor.user = originalUser;                                                                                 // 135
                                                                                                                      // 136
          if (Package.mongo && !Package.autopublish) {                                                                // 137
            Mongo.Collection._isSSR = false;                                                                          // 138
          }                                                                                                           // 139
        });                                                                                                           // 140
                                                                                                                      // 141
        res.pushData('fast-render-data', context.getData());                                                          // 142
      } catch (err) {                                                                                                 // 143
        console.error('error while server-rendering', err.stack);                                                     // 144
      }                                                                                                               // 145
                                                                                                                      // 146
      var originalWrite = res.write;                                                                                  // 147
      res.write = function (data) {                                                                                   // 148
        if (typeof data === 'string' && data.indexOf('<!DOCTYPE html>') === 0) {                                      // 149
          if (!serverOptions.dontMoveScripts) {                                                                       // 150
            data = moveScripts(data);                                                                                 // 151
          }                                                                                                           // 152
                                                                                                                      // 153
          if (css) {                                                                                                  // 154
            data = data.replace('</head>', '<style id="' + (clientOptions.styleCollectorId || 'css-style-collector-data') + '">' + css + '</style></head>');
          }                                                                                                           // 156
                                                                                                                      // 157
          data = data.replace('<body>', '<body><div id="' + (clientOptions.rootElement || 'react-app') + '">' + html + '</div>');
                                                                                                                      // 159
          if (typeof serverOptions.webpackStats !== 'undefined') {                                                    // 160
            var chunkNames = serverOptions.webpackStats.assetsByChunkName;                                            // 161
            var publicPath = serverOptions.webpackStats.publicPath;                                                   // 162
                                                                                                                      // 163
            if (typeof chunkNames.common !== 'undefined') {                                                           // 164
              var chunkSrc = typeof chunkNames.common === 'string' ? chunkNames.common : chunkNames.common[0];        // 165
                                                                                                                      // 166
              data = data.replace('<head>', '<head><script type="text/javascript" src="' + publicPath + chunkSrc + '"></script>');
            }                                                                                                         // 168
                                                                                                                      // 169
            for (var i = 0; i < global.__CHUNK_COLLECTOR__.length; ++i) {                                             // 170
              if (typeof chunkNames[global.__CHUNK_COLLECTOR__[i]] !== 'undefined') {                                 // 171
                var chunkSrc = typeof chunkNames[global.__CHUNK_COLLECTOR__[i]] === 'string' ? chunkNames[global.__CHUNK_COLLECTOR__[i]] : chunkNames[global.__CHUNK_COLLECTOR__[i]][0];
                                                                                                                      // 173
                data = data.replace('</head>', '<script type="text/javascript" src="' + publicPath + chunkSrc + '"></script></head>');
              }                                                                                                       // 175
            }                                                                                                         // 176
          }                                                                                                           // 177
        }                                                                                                             // 178
                                                                                                                      // 179
        originalWrite.call(this, data);                                                                               // 180
      };                                                                                                              // 181
                                                                                                                      // 182
      next();                                                                                                         // 183
    }));                                                                                                              // 184
  })();                                                                                                               // 185
};                                                                                                                    // 186
                                                                                                                      // 187
// Thank you FlowRouter for this wonderful idea :)                                                                    // 188
// https://github.com/kadirahq/flow-router/blob/ssr/server/route.js                                                   // 189
var Cheerio = Npm.require('cheerio');                                                                                 // 190
                                                                                                                      // 191
function moveScripts(data) {                                                                                          // 192
  var $ = Cheerio.load(data, {                                                                                        // 193
    decodeEntities: false                                                                                             // 194
  });                                                                                                                 // 195
  var heads = $('head script');                                                                                       // 196
  $('body').append(heads);                                                                                            // 197
                                                                                                                      // 198
  // Remove empty lines caused by removing scripts                                                                    // 199
  $('head').html($('head').html().replace(/(^[ \t]*\n)/gm, ''));                                                      // 200
                                                                                                                      // 201
  return $.html();                                                                                                    // 202
}                                                                                                                     // 203
                                                                                                                      // 204
if (Package.mongo && !Package.autopublish) {                                                                          // 205
  (function () {                                                                                                      // 206
    // Protect against returning data that has not been published                                                     // 207
    var originalFind = Mongo.Collection.prototype.find;                                                               // 208
    var originalFindOne = Mongo.Collection.prototype.findOne;                                                         // 209
                                                                                                                      // 210
    Mongo.Collection.prototype.findOne = function () {                                                                // 211
      var args = Array.prototype.slice.call(arguments);                                                               // 212
                                                                                                                      // 213
      if (!Mongo.Collection._isSSR) {                                                                                 // 214
        return originalFindOne.apply(this, args);                                                                     // 215
      }                                                                                                               // 216
                                                                                                                      // 217
      // Make sure to return nothing if no publish has been called                                                    // 218
      if (!Mongo.Collection._publishSelectorsSSR[this._name] || !Mongo.Collection._publishSelectorsSSR[this._name].length) {
        return originalFindOne.apply(this, [undefined]);                                                              // 220
      }                                                                                                               // 221
                                                                                                                      // 222
      if (args.length) {                                                                                              // 223
        if (typeof args[0] === 'string') {                                                                            // 224
          args[0] = { _id: args[0] };                                                                                 // 225
        }                                                                                                             // 226
                                                                                                                      // 227
        args[0] = { $and: [args[0], { $or: Mongo.Collection._publishSelectorsSSR[this._name] }] };                    // 228
      } else {                                                                                                        // 229
        args.push({ $or: Mongo.Collection._publishSelectorsSSR[this._name] });                                        // 230
      }                                                                                                               // 231
                                                                                                                      // 232
      return originalFindOne.apply(this, args);                                                                       // 233
    };                                                                                                                // 234
                                                                                                                      // 235
    Mongo.Collection.prototype.find = function () {                                                                   // 236
      var args = Array.prototype.slice.call(arguments);                                                               // 237
                                                                                                                      // 238
      if (!Mongo.Collection._isSSR) {                                                                                 // 239
        return originalFind.apply(this, args);                                                                        // 240
      }                                                                                                               // 241
                                                                                                                      // 242
      // Make sure to return nothing if no publish has been called                                                    // 243
      if (!Mongo.Collection._publishSelectorsSSR[this._name] || !Mongo.Collection._publishSelectorsSSR[this._name].length) {
        return originalFind.apply(this, [undefined]);                                                                 // 245
      }                                                                                                               // 246
                                                                                                                      // 247
      if (args.length) {                                                                                              // 248
        args[0] = { $and: [args[0], { $or: Mongo.Collection._publishSelectorsSSR[this._name] }] };                    // 249
      } else {                                                                                                        // 250
        args.push({ $or: Mongo.Collection._publishSelectorsSSR[this._name] });                                        // 251
      }                                                                                                               // 252
                                                                                                                      // 253
      return originalFind.apply(this, args);                                                                          // 254
    };                                                                                                                // 255
                                                                                                                      // 256
    Mongo.Collection._fakePublish = function (result) {                                                               // 257
      if (Array.isArray(result)) {                                                                                    // 258
        result.forEach(function (subResult) {                                                                         // 259
          return Mongo.Collection._fakePublish(subResult);                                                            // 260
        });                                                                                                           // 261
        return;                                                                                                       // 262
      }                                                                                                               // 263
                                                                                                                      // 264
      var name = result._cursorDescription.collectionName;                                                            // 265
      var selector = result._cursorDescription.selector;                                                              // 266
                                                                                                                      // 267
      if (!Mongo.Collection._publishSelectorsSSR[name]) {                                                             // 268
        Mongo.Collection._publishSelectorsSSR[name] = [];                                                             // 269
      }                                                                                                               // 270
                                                                                                                      // 271
      Mongo.Collection._publishSelectorsSSR[name].push(selector);                                                     // 272
    };                                                                                                                // 273
  })();                                                                                                               // 274
}                                                                                                                     // 275
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['reactrouter:react-router-ssr'] = {
  ReactRouterSSR: ReactRouterSSR
};

})();

//# sourceMappingURL=reactrouter_react-router-ssr.js.map
