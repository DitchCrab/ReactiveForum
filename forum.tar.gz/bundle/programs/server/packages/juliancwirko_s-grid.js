(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['juliancwirko:s-grid'] = {};

})();

//# sourceMappingURL=juliancwirko_s-grid.js.map
