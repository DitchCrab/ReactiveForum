(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var React = Package['react-runtime'].React;
var ReactDOM = Package['react-runtime'].ReactDOM;
var ReactDOMServer = Package['react-runtime'].ReactDOMServer;
var ReactMeteorData = Package['react-meteor-data'].ReactMeteorData;
var babelHelpers = Package['babel-runtime'].babelHelpers;

/* Package-scope variables */
var injectTapEventPlugin;

(function(){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// packages/coniel_react-tap-event-plugin/client.browserify.js                     //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
(function (global){                                                                //
global.React = React;                                                              // 1
                                                                                   // 2
injectTapEventPlugin = require("react-tap-event-plugin");                          // 3
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                   //
},{"react-tap-event-plugin":5}],2:[function(require,module,exports){               //
/**                                                                                // 1
 * Copyright 2013-2015, Facebook, Inc.                                             // 2
 * All rights reserved.                                                            // 3
 *                                                                                 // 4
 * This source code is licensed under the BSD-style license found in the           // 5
 * LICENSE file in the root directory of this source tree. An additional grant     // 6
 * of patent rights can be found in the PATENTS file in the same directory.        // 7
 *                                                                                 // 8
 * @providesModule keyOf                                                           // 9
 */                                                                                // 10
                                                                                   // 11
/**                                                                                // 12
 * Allows extraction of a minified key. Let's the build system minify keys         // 13
 * without losing the ability to dynamically use key strings as values             // 14
 * themselves. Pass in an object with a single key/val pair and it will return     // 15
 * you the string key of that single record. Suppose you want to grab the          // 16
 * value for a key 'className' inside of an object. Key/val minification may       // 17
 * have aliased that key to be 'xa12'. keyOf({className: null}) will return        // 18
 * 'xa12' in that case. Resolve keys you want to use once at startup time, then    // 19
 * reuse those resolutions.                                                        // 20
 */                                                                                // 21
"use strict";                                                                      // 22
                                                                                   // 23
var keyOf = function (oneKeyObj) {                                                 // 24
  var key;                                                                         // 25
  for (key in oneKeyObj) {                                                         // 26
    if (!oneKeyObj.hasOwnProperty(key)) {                                          // 27
      continue;                                                                    // 28
    }                                                                              // 29
    return key;                                                                    // 30
  }                                                                                // 31
  return null;                                                                     // 32
};                                                                                 // 33
                                                                                   // 34
module.exports = keyOf;                                                            // 35
},{}],3:[function(require,module,exports){                                         //
(function (global){                                                                //
/**                                                                                // 1
 * Copyright 2013-2014 Facebook, Inc.                                              // 2
 *                                                                                 // 3
 * Licensed under the Apache License, Version 2.0 (the "License");                 // 4
 * you may not use this file except in compliance with the License.                // 5
 * You may obtain a copy of the License at                                         // 6
 *                                                                                 // 7
 * http://www.apache.org/licenses/LICENSE-2.0                                      // 8
 *                                                                                 // 9
 * Unless required by applicable law or agreed to in writing, software             // 10
 * distributed under the License is distributed on an "AS IS" BASIS,               // 11
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.        // 12
 * See the License for the specific language governing permissions and             // 13
 * limitations under the License.                                                  // 14
 *                                                                                 // 15
 * @providesModule TapEventPlugin                                                  // 16
 * @typechecks static-only                                                         // 17
 */                                                                                // 18
                                                                                   // 19
"use strict";                                                                      // 20
                                                                                   // 21
var EventConstants = (typeof window !== "undefined" ? window['React']['require'] : typeof global !== "undefined" ? global['React']['require'] : null)("react/lib/EventConstants");
var EventPluginUtils = (typeof window !== "undefined" ? window['React']['require'] : typeof global !== "undefined" ? global['React']['require'] : null)("react/lib/EventPluginUtils");
var EventPropagators = (typeof window !== "undefined" ? window['React']['require'] : typeof global !== "undefined" ? global['React']['require'] : null)("react/lib/EventPropagators");
var SyntheticUIEvent = (typeof window !== "undefined" ? window['React']['require'] : typeof global !== "undefined" ? global['React']['require'] : null)("react/lib/SyntheticUIEvent");
var TouchEventUtils = require('./TouchEventUtils');                                // 26
var ViewportMetrics = (typeof window !== "undefined" ? window['React']['require'] : typeof global !== "undefined" ? global['React']['require'] : null)("react/lib/ViewportMetrics");
                                                                                   // 28
var keyOf = require('fbjs/lib/keyOf');                                             // 29
var topLevelTypes = EventConstants.topLevelTypes;                                  // 30
                                                                                   // 31
var isStartish = EventPluginUtils.isStartish;                                      // 32
var isEndish = EventPluginUtils.isEndish;                                          // 33
                                                                                   // 34
var isTouch = function(topLevelType) {                                             // 35
  var touchTypes = [                                                               // 36
    topLevelTypes.topTouchCancel,                                                  // 37
    topLevelTypes.topTouchEnd,                                                     // 38
    topLevelTypes.topTouchStart,                                                   // 39
    topLevelTypes.topTouchMove                                                     // 40
  ];                                                                               // 41
  return touchTypes.indexOf(topLevelType) >= 0;                                    // 42
}                                                                                  // 43
                                                                                   // 44
/**                                                                                // 45
 * Number of pixels that are tolerated in between a `touchStart` and `touchEnd`    // 46
 * in order to still be considered a 'tap' event.                                  // 47
 */                                                                                // 48
var tapMoveThreshold = 10;                                                         // 49
var ignoreMouseThreshold = 750;                                                    // 50
var startCoords = {x: null, y: null};                                              // 51
var lastTouchEvent = null;                                                         // 52
                                                                                   // 53
var Axis = {                                                                       // 54
  x: {page: 'pageX', client: 'clientX', envScroll: 'currentPageScrollLeft'},       // 55
  y: {page: 'pageY', client: 'clientY', envScroll: 'currentPageScrollTop'}         // 56
};                                                                                 // 57
                                                                                   // 58
function getAxisCoordOfEvent(axis, nativeEvent) {                                  // 59
  var singleTouch = TouchEventUtils.extractSingleTouch(nativeEvent);               // 60
  if (singleTouch) {                                                               // 61
    return singleTouch[axis.page];                                                 // 62
  }                                                                                // 63
  return axis.page in nativeEvent ?                                                // 64
    nativeEvent[axis.page] :                                                       // 65
    nativeEvent[axis.client] + ViewportMetrics[axis.envScroll];                    // 66
}                                                                                  // 67
                                                                                   // 68
function getDistance(coords, nativeEvent) {                                        // 69
  var pageX = getAxisCoordOfEvent(Axis.x, nativeEvent);                            // 70
  var pageY = getAxisCoordOfEvent(Axis.y, nativeEvent);                            // 71
  return Math.pow(                                                                 // 72
    Math.pow(pageX - coords.x, 2) + Math.pow(pageY - coords.y, 2),                 // 73
    0.5                                                                            // 74
  );                                                                               // 75
}                                                                                  // 76
                                                                                   // 77
var touchEvents = [                                                                // 78
  topLevelTypes.topTouchStart,                                                     // 79
  topLevelTypes.topTouchCancel,                                                    // 80
  topLevelTypes.topTouchEnd,                                                       // 81
  topLevelTypes.topTouchMove,                                                      // 82
];                                                                                 // 83
                                                                                   // 84
var dependencies = [                                                               // 85
  topLevelTypes.topMouseDown,                                                      // 86
  topLevelTypes.topMouseMove,                                                      // 87
  topLevelTypes.topMouseUp,                                                        // 88
].concat(touchEvents);                                                             // 89
                                                                                   // 90
var eventTypes = {                                                                 // 91
  touchTap: {                                                                      // 92
    phasedRegistrationNames: {                                                     // 93
      bubbled: keyOf({onTouchTap: null}),                                          // 94
      captured: keyOf({onTouchTapCapture: null})                                   // 95
    },                                                                             // 96
    dependencies: dependencies                                                     // 97
  }                                                                                // 98
};                                                                                 // 99
                                                                                   // 100
var now = (function() {                                                            // 101
  if (Date.now) {                                                                  // 102
    return Date.now;                                                               // 103
  } else {                                                                         // 104
    // IE8 support: http://stackoverflow.com/questions/9430357/please-explain-why-and-how-new-date-works-as-workaround-for-date-now-in
    return function () {                                                           // 106
      return +new Date;                                                            // 107
    }                                                                              // 108
  }                                                                                // 109
})();                                                                              // 110
                                                                                   // 111
var TapEventPlugin = {                                                             // 112
                                                                                   // 113
  tapMoveThreshold: tapMoveThreshold,                                              // 114
                                                                                   // 115
  ignoreMouseThreshold: ignoreMouseThreshold,                                      // 116
                                                                                   // 117
  eventTypes: eventTypes,                                                          // 118
                                                                                   // 119
  /**                                                                              // 120
   * @param {string} topLevelType Record from `EventConstants`.                    // 121
   * @param {DOMEventTarget} topLevelTarget The listening component root node.     // 122
   * @param {string} topLevelTargetID ID of `topLevelTarget`.                      // 123
   * @param {object} nativeEvent Native browser event.                             // 124
   * @return {*} An accumulation of synthetic events.                              // 125
   * @see {EventPluginHub.extractEvents}                                           // 126
   */                                                                              // 127
  extractEvents: function(                                                         // 128
      topLevelType,                                                                // 129
      topLevelTarget,                                                              // 130
      topLevelTargetID,                                                            // 131
      nativeEvent,                                                                 // 132
      nativeEventTarget) {                                                         // 133
                                                                                   // 134
    if (isTouch(topLevelType)) {                                                   // 135
      lastTouchEvent = now();                                                      // 136
    } else {                                                                       // 137
      if (lastTouchEvent && (now() - lastTouchEvent) < ignoreMouseThreshold) {     // 138
        return null;                                                               // 139
      }                                                                            // 140
    }                                                                              // 141
                                                                                   // 142
    if (!isStartish(topLevelType) && !isEndish(topLevelType)) {                    // 143
      return null;                                                                 // 144
    }                                                                              // 145
    var event = null;                                                              // 146
    var distance = getDistance(startCoords, nativeEvent);                          // 147
    if (isEndish(topLevelType) && distance < tapMoveThreshold) {                   // 148
      event = SyntheticUIEvent.getPooled(                                          // 149
        eventTypes.touchTap,                                                       // 150
        topLevelTargetID,                                                          // 151
        nativeEvent,                                                               // 152
        nativeEventTarget                                                          // 153
      );                                                                           // 154
    }                                                                              // 155
    if (isStartish(topLevelType)) {                                                // 156
      startCoords.x = getAxisCoordOfEvent(Axis.x, nativeEvent);                    // 157
      startCoords.y = getAxisCoordOfEvent(Axis.y, nativeEvent);                    // 158
    } else if (isEndish(topLevelType)) {                                           // 159
      startCoords.x = 0;                                                           // 160
      startCoords.y = 0;                                                           // 161
    }                                                                              // 162
    EventPropagators.accumulateTwoPhaseDispatches(event);                          // 163
    return event;                                                                  // 164
  }                                                                                // 165
                                                                                   // 166
};                                                                                 // 167
                                                                                   // 168
module.exports = TapEventPlugin;                                                   // 169
                                                                                   // 170
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                   //
},{"./TouchEventUtils":4,"fbjs/lib/keyOf":2}],4:[function(require,module,exports){
/**                                                                                // 1
 * Copyright 2013-2014 Facebook, Inc.                                              // 2
 *                                                                                 // 3
 * Licensed under the Apache License, Version 2.0 (the "License");                 // 4
 * you may not use this file except in compliance with the License.                // 5
 * You may obtain a copy of the License at                                         // 6
 *                                                                                 // 7
 * http://www.apache.org/licenses/LICENSE-2.0                                      // 8
 *                                                                                 // 9
 * Unless required by applicable law or agreed to in writing, software             // 10
 * distributed under the License is distributed on an "AS IS" BASIS,               // 11
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.        // 12
 * See the License for the specific language governing permissions and             // 13
 * limitations under the License.                                                  // 14
 *                                                                                 // 15
 * @providesModule TouchEventUtils                                                 // 16
 */                                                                                // 17
                                                                                   // 18
var TouchEventUtils = {                                                            // 19
  /**                                                                              // 20
   * Utility function for common case of extracting out the primary touch from a   // 21
   * touch event.                                                                  // 22
   * - `touchEnd` events usually do not have the `touches` property.               // 23
   *   http://stackoverflow.com/questions/3666929/                                 // 24
   *   mobile-sarai-touchend-event-not-firing-when-last-touch-is-removed           // 25
   *                                                                               // 26
   * @param {Event} nativeEvent Native event that may or may not be a touch.       // 27
   * @return {TouchesObject?} an object with pageX and pageY or null.              // 28
   */                                                                              // 29
  extractSingleTouch: function(nativeEvent) {                                      // 30
    var touches = nativeEvent.touches;                                             // 31
    var changedTouches = nativeEvent.changedTouches;                               // 32
    var hasTouches = touches && touches.length > 0;                                // 33
    var hasChangedTouches = changedTouches && changedTouches.length > 0;           // 34
                                                                                   // 35
    return !hasTouches && hasChangedTouches ? changedTouches[0] :                  // 36
           hasTouches ? touches[0] :                                               // 37
           nativeEvent;                                                            // 38
  }                                                                                // 39
};                                                                                 // 40
                                                                                   // 41
module.exports = TouchEventUtils;                                                  // 42
                                                                                   // 43
},{}],5:[function(require,module,exports){                                         //
(function (global){                                                                //
module.exports = function injectTapEventPlugin () {                                // 1
  (typeof window !== "undefined" ? window['React']['require'] : typeof global !== "undefined" ? global['React']['require'] : null)("react/lib/EventPluginHub").injection.injectEventPluginsByName({
    "TapEventPlugin":       require('./TapEventPlugin.js')                         // 3
  });                                                                              // 4
};                                                                                 // 5
                                                                                   // 6
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                   //
},{"./TapEventPlugin.js":3}]},{},[1])                                              //
//# sourceMappingURL=/packages/coniel_react-tap-event-plugin/client.browserify.js  //
                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['coniel:react-tap-event-plugin'] = {
  injectTapEventPlugin: injectTapEventPlugin
};

})();

//# sourceMappingURL=coniel_react-tap-event-plugin.js.map
