(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var React = Package['react-runtime'].React;
var ReactDOM = Package['react-runtime'].ReactDOM;
var ReactDOMServer = Package['react-runtime'].ReactDOMServer;

/* Package-scope variables */
var ReactRouter;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/reactrouter_react-router/react-router.browserify.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
// shim for using process in browser                                                                                   // 1
                                                                                                                       // 2
var process = module.exports = {};                                                                                     // 3
var queue = [];                                                                                                        // 4
var draining = false;                                                                                                  // 5
var currentQueue;                                                                                                      // 6
var queueIndex = -1;                                                                                                   // 7
                                                                                                                       // 8
function cleanUpNextTick() {                                                                                           // 9
    draining = false;                                                                                                  // 10
    if (currentQueue.length) {                                                                                         // 11
        queue = currentQueue.concat(queue);                                                                            // 12
    } else {                                                                                                           // 13
        queueIndex = -1;                                                                                               // 14
    }                                                                                                                  // 15
    if (queue.length) {                                                                                                // 16
        drainQueue();                                                                                                  // 17
    }                                                                                                                  // 18
}                                                                                                                      // 19
                                                                                                                       // 20
function drainQueue() {                                                                                                // 21
    if (draining) {                                                                                                    // 22
        return;                                                                                                        // 23
    }                                                                                                                  // 24
    var timeout = setTimeout(cleanUpNextTick);                                                                         // 25
    draining = true;                                                                                                   // 26
                                                                                                                       // 27
    var len = queue.length;                                                                                            // 28
    while(len) {                                                                                                       // 29
        currentQueue = queue;                                                                                          // 30
        queue = [];                                                                                                    // 31
        while (++queueIndex < len) {                                                                                   // 32
            if (currentQueue) {                                                                                        // 33
                currentQueue[queueIndex].run();                                                                        // 34
            }                                                                                                          // 35
        }                                                                                                              // 36
        queueIndex = -1;                                                                                               // 37
        len = queue.length;                                                                                            // 38
    }                                                                                                                  // 39
    currentQueue = null;                                                                                               // 40
    draining = false;                                                                                                  // 41
    clearTimeout(timeout);                                                                                             // 42
}                                                                                                                      // 43
                                                                                                                       // 44
process.nextTick = function (fun) {                                                                                    // 45
    var args = new Array(arguments.length - 1);                                                                        // 46
    if (arguments.length > 1) {                                                                                        // 47
        for (var i = 1; i < arguments.length; i++) {                                                                   // 48
            args[i - 1] = arguments[i];                                                                                // 49
        }                                                                                                              // 50
    }                                                                                                                  // 51
    queue.push(new Item(fun, args));                                                                                   // 52
    if (queue.length === 1 && !draining) {                                                                             // 53
        setTimeout(drainQueue, 0);                                                                                     // 54
    }                                                                                                                  // 55
};                                                                                                                     // 56
                                                                                                                       // 57
// v8 likes predictible objects                                                                                        // 58
function Item(fun, array) {                                                                                            // 59
    this.fun = fun;                                                                                                    // 60
    this.array = array;                                                                                                // 61
}                                                                                                                      // 62
Item.prototype.run = function () {                                                                                     // 63
    this.fun.apply(null, this.array);                                                                                  // 64
};                                                                                                                     // 65
process.title = 'browser';                                                                                             // 66
process.browser = true;                                                                                                // 67
process.env = {};                                                                                                      // 68
process.argv = [];                                                                                                     // 69
process.version = ''; // empty string to avoid regexp issues                                                           // 70
process.versions = {};                                                                                                 // 71
                                                                                                                       // 72
function noop() {}                                                                                                     // 73
                                                                                                                       // 74
process.on = noop;                                                                                                     // 75
process.addListener = noop;                                                                                            // 76
process.once = noop;                                                                                                   // 77
process.off = noop;                                                                                                    // 78
process.removeListener = noop;                                                                                         // 79
process.removeAllListeners = noop;                                                                                     // 80
process.emit = noop;                                                                                                   // 81
                                                                                                                       // 82
process.binding = function (name) {                                                                                    // 83
    throw new Error('process.binding is not supported');                                                               // 84
};                                                                                                                     // 85
                                                                                                                       // 86
process.cwd = function () { return '/' };                                                                              // 87
process.chdir = function (dir) {                                                                                       // 88
    throw new Error('process.chdir is not supported');                                                                 // 89
};                                                                                                                     // 90
process.umask = function() { return 0; };                                                                              // 91
                                                                                                                       // 92
},{}],2:[function(require,module,exports){                                                                             //
(function (global){                                                                                                    //
// This is required for exposify                                                                                       // 1
global.React = React;                                                                                                  // 2
                                                                                                                       // 3
ReactRouter = require('react-router');                                                                                 // 4
ReactRouter.history = require('history');                                                                              // 5
                                                                                                                       // 6
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{"history":18,"react-router":52}],3:[function(require,module,exports){                                               //
/**                                                                                                                    // 1
 * Indicates that navigation was caused by a call to history.push.                                                     // 2
 */                                                                                                                    // 3
'use strict';                                                                                                          // 4
                                                                                                                       // 5
exports.__esModule = true;                                                                                             // 6
var PUSH = 'PUSH';                                                                                                     // 7
                                                                                                                       // 8
exports.PUSH = PUSH;                                                                                                   // 9
/**                                                                                                                    // 10
 * Indicates that navigation was caused by a call to history.replace.                                                  // 11
 */                                                                                                                    // 12
var REPLACE = 'REPLACE';                                                                                               // 13
                                                                                                                       // 14
exports.REPLACE = REPLACE;                                                                                             // 15
/**                                                                                                                    // 16
 * Indicates that navigation was caused by some other action such                                                      // 17
 * as using a browser's back/forward buttons and/or manually manipulating                                              // 18
 * the URL in a browser's location bar. This is the default.                                                           // 19
 *                                                                                                                     // 20
 * See https://developer.mozilla.org/en-US/docs/Web/API/WindowEventHandlers/onpopstate                                 // 21
 * for more information.                                                                                               // 22
 */                                                                                                                    // 23
var POP = 'POP';                                                                                                       // 24
                                                                                                                       // 25
exports.POP = POP;                                                                                                     // 26
exports['default'] = {                                                                                                 // 27
  PUSH: PUSH,                                                                                                          // 28
  REPLACE: REPLACE,                                                                                                    // 29
  POP: POP                                                                                                             // 30
};                                                                                                                     // 31
},{}],4:[function(require,module,exports){                                                                             //
"use strict";                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
exports.loopAsync = loopAsync;                                                                                         // 4
                                                                                                                       // 5
function loopAsync(turns, work, callback) {                                                                            // 6
  var currentTurn = 0;                                                                                                 // 7
  var isDone = false;                                                                                                  // 8
                                                                                                                       // 9
  function done() {                                                                                                    // 10
    isDone = true;                                                                                                     // 11
    callback.apply(this, arguments);                                                                                   // 12
  }                                                                                                                    // 13
                                                                                                                       // 14
  function next() {                                                                                                    // 15
    if (isDone) return;                                                                                                // 16
                                                                                                                       // 17
    if (currentTurn < turns) {                                                                                         // 18
      work.call(this, currentTurn++, next, done);                                                                      // 19
    } else {                                                                                                           // 20
      done.apply(this, arguments);                                                                                     // 21
    }                                                                                                                  // 22
  }                                                                                                                    // 23
                                                                                                                       // 24
  next();                                                                                                              // 25
}                                                                                                                      // 26
},{}],5:[function(require,module,exports){                                                                             //
(function (process){                                                                                                   //
/*eslint-disable no-empty */                                                                                           // 1
'use strict';                                                                                                          // 2
                                                                                                                       // 3
exports.__esModule = true;                                                                                             // 4
exports.saveState = saveState;                                                                                         // 5
exports.readState = readState;                                                                                         // 6
                                                                                                                       // 7
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 8
                                                                                                                       // 9
var _warning = require('warning');                                                                                     // 10
                                                                                                                       // 11
var _warning2 = _interopRequireDefault(_warning);                                                                      // 12
                                                                                                                       // 13
var KeyPrefix = '@@History/';                                                                                          // 14
var QuotaExceededError = 'QuotaExceededError';                                                                         // 15
var SecurityError = 'SecurityError';                                                                                   // 16
                                                                                                                       // 17
function createKey(key) {                                                                                              // 18
  return KeyPrefix + key;                                                                                              // 19
}                                                                                                                      // 20
                                                                                                                       // 21
function saveState(key, state) {                                                                                       // 22
  try {                                                                                                                // 23
    window.sessionStorage.setItem(createKey(key), JSON.stringify(state));                                              // 24
  } catch (error) {                                                                                                    // 25
    if (error.name === SecurityError) {                                                                                // 26
      // Blocking cookies in Chrome/Firefox/Safari throws SecurityError on any                                         // 27
      // attempt to access window.sessionStorage.                                                                      // 28
      process.env.NODE_ENV !== 'production' ? _warning2['default'](false, '[history] Unable to save state; sessionStorage is not available due to security settings') : undefined;
                                                                                                                       // 30
      return;                                                                                                          // 31
    }                                                                                                                  // 32
                                                                                                                       // 33
    if (error.name === QuotaExceededError && window.sessionStorage.length === 0) {                                     // 34
      // Safari "private mode" throws QuotaExceededError.                                                              // 35
      process.env.NODE_ENV !== 'production' ? _warning2['default'](false, '[history] Unable to save state; sessionStorage is not available in Safari private mode') : undefined;
                                                                                                                       // 37
      return;                                                                                                          // 38
    }                                                                                                                  // 39
                                                                                                                       // 40
    throw error;                                                                                                       // 41
  }                                                                                                                    // 42
}                                                                                                                      // 43
                                                                                                                       // 44
function readState(key) {                                                                                              // 45
  var json = undefined;                                                                                                // 46
  try {                                                                                                                // 47
    json = window.sessionStorage.getItem(createKey(key));                                                              // 48
  } catch (error) {                                                                                                    // 49
    if (error.name === SecurityError) {                                                                                // 50
      // Blocking cookies in Chrome/Firefox/Safari throws SecurityError on any                                         // 51
      // attempt to access window.sessionStorage.                                                                      // 52
      process.env.NODE_ENV !== 'production' ? _warning2['default'](false, '[history] Unable to read state; sessionStorage is not available due to security settings') : undefined;
                                                                                                                       // 54
      return null;                                                                                                     // 55
    }                                                                                                                  // 56
  }                                                                                                                    // 57
                                                                                                                       // 58
  if (json) {                                                                                                          // 59
    try {                                                                                                              // 60
      return JSON.parse(json);                                                                                         // 61
    } catch (error) {                                                                                                  // 62
      // Ignore invalid JSON.                                                                                          // 63
    }                                                                                                                  // 64
  }                                                                                                                    // 65
                                                                                                                       // 66
  return null;                                                                                                         // 67
}                                                                                                                      // 68
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"_process":1,"warning":32}],6:[function(require,module,exports){                                                    //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
exports.addEventListener = addEventListener;                                                                           // 4
exports.removeEventListener = removeEventListener;                                                                     // 5
exports.getHashPath = getHashPath;                                                                                     // 6
exports.replaceHashPath = replaceHashPath;                                                                             // 7
exports.getWindowPath = getWindowPath;                                                                                 // 8
exports.go = go;                                                                                                       // 9
exports.getUserConfirmation = getUserConfirmation;                                                                     // 10
exports.supportsHistory = supportsHistory;                                                                             // 11
exports.supportsGoWithoutReloadUsingHash = supportsGoWithoutReloadUsingHash;                                           // 12
                                                                                                                       // 13
function addEventListener(node, event, listener) {                                                                     // 14
  if (node.addEventListener) {                                                                                         // 15
    node.addEventListener(event, listener, false);                                                                     // 16
  } else {                                                                                                             // 17
    node.attachEvent('on' + event, listener);                                                                          // 18
  }                                                                                                                    // 19
}                                                                                                                      // 20
                                                                                                                       // 21
function removeEventListener(node, event, listener) {                                                                  // 22
  if (node.removeEventListener) {                                                                                      // 23
    node.removeEventListener(event, listener, false);                                                                  // 24
  } else {                                                                                                             // 25
    node.detachEvent('on' + event, listener);                                                                          // 26
  }                                                                                                                    // 27
}                                                                                                                      // 28
                                                                                                                       // 29
function getHashPath() {                                                                                               // 30
  // We can't use window.location.hash here because it's not                                                           // 31
  // consistent across browsers - Firefox will pre-decode it!                                                          // 32
  return window.location.href.split('#')[1] || '';                                                                     // 33
}                                                                                                                      // 34
                                                                                                                       // 35
function replaceHashPath(path) {                                                                                       // 36
  window.location.replace(window.location.pathname + window.location.search + '#' + path);                             // 37
}                                                                                                                      // 38
                                                                                                                       // 39
function getWindowPath() {                                                                                             // 40
  return window.location.pathname + window.location.search + window.location.hash;                                     // 41
}                                                                                                                      // 42
                                                                                                                       // 43
function go(n) {                                                                                                       // 44
  if (n) window.history.go(n);                                                                                         // 45
}                                                                                                                      // 46
                                                                                                                       // 47
function getUserConfirmation(message, callback) {                                                                      // 48
  callback(window.confirm(message));                                                                                   // 49
}                                                                                                                      // 50
                                                                                                                       // 51
/**                                                                                                                    // 52
 * Returns true if the HTML5 history API is supported. Taken from modernizr.                                           // 53
 *                                                                                                                     // 54
 * https://github.com/Modernizr/Modernizr/blob/master/LICENSE                                                          // 55
 * https://github.com/Modernizr/Modernizr/blob/master/feature-detects/history.js                                       // 56
 * changed to avoid false negatives for Windows Phones: https://github.com/rackt/react-router/issues/586               // 57
 */                                                                                                                    // 58
                                                                                                                       // 59
function supportsHistory() {                                                                                           // 60
  var ua = navigator.userAgent;                                                                                        // 61
  if ((ua.indexOf('Android 2.') !== -1 || ua.indexOf('Android 4.0') !== -1) && ua.indexOf('Mobile Safari') !== -1 && ua.indexOf('Chrome') === -1 && ua.indexOf('Windows Phone') === -1) {
    return false;                                                                                                      // 63
  }                                                                                                                    // 64
  return window.history && 'pushState' in window.history;                                                              // 65
}                                                                                                                      // 66
                                                                                                                       // 67
/**                                                                                                                    // 68
 * Returns false if using go(n) with hash history causes a full page reload.                                           // 69
 */                                                                                                                    // 70
                                                                                                                       // 71
function supportsGoWithoutReloadUsingHash() {                                                                          // 72
  var ua = navigator.userAgent;                                                                                        // 73
  return ua.indexOf('Firefox') === -1;                                                                                 // 74
}                                                                                                                      // 75
},{}],7:[function(require,module,exports){                                                                             //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
var canUseDOM = !!(typeof window !== 'undefined' && window.document && window.document.createElement);                 // 4
exports.canUseDOM = canUseDOM;                                                                                         // 5
},{}],8:[function(require,module,exports){                                                                             //
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
var _invariant = require('invariant');                                                                                 // 9
                                                                                                                       // 10
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 11
                                                                                                                       // 12
var _Actions = require('./Actions');                                                                                   // 13
                                                                                                                       // 14
var _ExecutionEnvironment = require('./ExecutionEnvironment');                                                         // 15
                                                                                                                       // 16
var _DOMUtils = require('./DOMUtils');                                                                                 // 17
                                                                                                                       // 18
var _DOMStateStorage = require('./DOMStateStorage');                                                                   // 19
                                                                                                                       // 20
var _createDOMHistory = require('./createDOMHistory');                                                                 // 21
                                                                                                                       // 22
var _createDOMHistory2 = _interopRequireDefault(_createDOMHistory);                                                    // 23
                                                                                                                       // 24
/**                                                                                                                    // 25
 * Creates and returns a history object that uses HTML5's history API                                                  // 26
 * (pushState, replaceState, and the popstate event) to manage history.                                                // 27
 * This is the recommended method of managing history in browsers because                                              // 28
 * it provides the cleanest URLs.                                                                                      // 29
 *                                                                                                                     // 30
 * Note: In browsers that do not support the HTML5 history API full                                                    // 31
 * page reloads will be used to preserve URLs.                                                                         // 32
 */                                                                                                                    // 33
function createBrowserHistory() {                                                                                      // 34
  var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];                               // 35
                                                                                                                       // 36
  !_ExecutionEnvironment.canUseDOM ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'Browser history needs a DOM') : _invariant2['default'](false) : undefined;
                                                                                                                       // 38
  var forceRefresh = options.forceRefresh;                                                                             // 39
                                                                                                                       // 40
  var isSupported = _DOMUtils.supportsHistory();                                                                       // 41
  var useRefresh = !isSupported || forceRefresh;                                                                       // 42
                                                                                                                       // 43
  function getCurrentLocation(historyState) {                                                                          // 44
    historyState = historyState || window.history.state || {};                                                         // 45
                                                                                                                       // 46
    var path = _DOMUtils.getWindowPath();                                                                              // 47
    var _historyState = historyState;                                                                                  // 48
    var key = _historyState.key;                                                                                       // 49
                                                                                                                       // 50
    var state = undefined;                                                                                             // 51
    if (key) {                                                                                                         // 52
      state = _DOMStateStorage.readState(key);                                                                         // 53
    } else {                                                                                                           // 54
      state = null;                                                                                                    // 55
      key = history.createKey();                                                                                       // 56
                                                                                                                       // 57
      if (isSupported) window.history.replaceState(_extends({}, historyState, { key: key }), null, path);              // 58
    }                                                                                                                  // 59
                                                                                                                       // 60
    return history.createLocation(path, state, undefined, key);                                                        // 61
  }                                                                                                                    // 62
                                                                                                                       // 63
  function startPopStateListener(_ref) {                                                                               // 64
    var transitionTo = _ref.transitionTo;                                                                              // 65
                                                                                                                       // 66
    function popStateListener(event) {                                                                                 // 67
      if (event.state === undefined) return; // Ignore extraneous popstate events in WebKit.                           // 68
                                                                                                                       // 69
      transitionTo(getCurrentLocation(event.state));                                                                   // 70
    }                                                                                                                  // 71
                                                                                                                       // 72
    _DOMUtils.addEventListener(window, 'popstate', popStateListener);                                                  // 73
                                                                                                                       // 74
    return function () {                                                                                               // 75
      _DOMUtils.removeEventListener(window, 'popstate', popStateListener);                                             // 76
    };                                                                                                                 // 77
  }                                                                                                                    // 78
                                                                                                                       // 79
  function finishTransition(location) {                                                                                // 80
    var basename = location.basename;                                                                                  // 81
    var pathname = location.pathname;                                                                                  // 82
    var search = location.search;                                                                                      // 83
    var hash = location.hash;                                                                                          // 84
    var state = location.state;                                                                                        // 85
    var action = location.action;                                                                                      // 86
    var key = location.key;                                                                                            // 87
                                                                                                                       // 88
    if (action === _Actions.POP) return; // Nothing to do.                                                             // 89
                                                                                                                       // 90
    _DOMStateStorage.saveState(key, state);                                                                            // 91
                                                                                                                       // 92
    var path = (basename || '') + pathname + search + hash;                                                            // 93
    var historyState = {                                                                                               // 94
      key: key                                                                                                         // 95
    };                                                                                                                 // 96
                                                                                                                       // 97
    if (action === _Actions.PUSH) {                                                                                    // 98
      if (useRefresh) {                                                                                                // 99
        window.location.href = path;                                                                                   // 100
        return false; // Prevent location update.                                                                      // 101
      } else {                                                                                                         // 102
          window.history.pushState(historyState, null, path);                                                          // 103
        }                                                                                                              // 104
    } else {                                                                                                           // 105
      // REPLACE                                                                                                       // 106
      if (useRefresh) {                                                                                                // 107
        window.location.replace(path);                                                                                 // 108
        return false; // Prevent location update.                                                                      // 109
      } else {                                                                                                         // 110
          window.history.replaceState(historyState, null, path);                                                       // 111
        }                                                                                                              // 112
    }                                                                                                                  // 113
  }                                                                                                                    // 114
                                                                                                                       // 115
  var history = _createDOMHistory2['default'](_extends({}, options, {                                                  // 116
    getCurrentLocation: getCurrentLocation,                                                                            // 117
    finishTransition: finishTransition,                                                                                // 118
    saveState: _DOMStateStorage.saveState                                                                              // 119
  }));                                                                                                                 // 120
                                                                                                                       // 121
  var listenerCount = 0,                                                                                               // 122
      stopPopStateListener = undefined;                                                                                // 123
                                                                                                                       // 124
  function listenBefore(listener) {                                                                                    // 125
    if (++listenerCount === 1) stopPopStateListener = startPopStateListener(history);                                  // 126
                                                                                                                       // 127
    var unlisten = history.listenBefore(listener);                                                                     // 128
                                                                                                                       // 129
    return function () {                                                                                               // 130
      unlisten();                                                                                                      // 131
                                                                                                                       // 132
      if (--listenerCount === 0) stopPopStateListener();                                                               // 133
    };                                                                                                                 // 134
  }                                                                                                                    // 135
                                                                                                                       // 136
  function listen(listener) {                                                                                          // 137
    if (++listenerCount === 1) stopPopStateListener = startPopStateListener(history);                                  // 138
                                                                                                                       // 139
    var unlisten = history.listen(listener);                                                                           // 140
                                                                                                                       // 141
    return function () {                                                                                               // 142
      unlisten();                                                                                                      // 143
                                                                                                                       // 144
      if (--listenerCount === 0) stopPopStateListener();                                                               // 145
    };                                                                                                                 // 146
  }                                                                                                                    // 147
                                                                                                                       // 148
  // deprecated                                                                                                        // 149
  function registerTransitionHook(hook) {                                                                              // 150
    if (++listenerCount === 1) stopPopStateListener = startPopStateListener(history);                                  // 151
                                                                                                                       // 152
    history.registerTransitionHook(hook);                                                                              // 153
  }                                                                                                                    // 154
                                                                                                                       // 155
  // deprecated                                                                                                        // 156
  function unregisterTransitionHook(hook) {                                                                            // 157
    history.unregisterTransitionHook(hook);                                                                            // 158
                                                                                                                       // 159
    if (--listenerCount === 0) stopPopStateListener();                                                                 // 160
  }                                                                                                                    // 161
                                                                                                                       // 162
  return _extends({}, history, {                                                                                       // 163
    listenBefore: listenBefore,                                                                                        // 164
    listen: listen,                                                                                                    // 165
    registerTransitionHook: registerTransitionHook,                                                                    // 166
    unregisterTransitionHook: unregisterTransitionHook                                                                 // 167
  });                                                                                                                  // 168
}                                                                                                                      // 169
                                                                                                                       // 170
exports['default'] = createBrowserHistory;                                                                             // 171
module.exports = exports['default'];                                                                                   // 172
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"./Actions":3,"./DOMStateStorage":5,"./DOMUtils":6,"./ExecutionEnvironment":7,"./createDOMHistory":9,"_process":1,"invariant":27}],9:[function(require,module,exports){
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
var _invariant = require('invariant');                                                                                 // 9
                                                                                                                       // 10
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 11
                                                                                                                       // 12
var _ExecutionEnvironment = require('./ExecutionEnvironment');                                                         // 13
                                                                                                                       // 14
var _DOMUtils = require('./DOMUtils');                                                                                 // 15
                                                                                                                       // 16
var _createHistory = require('./createHistory');                                                                       // 17
                                                                                                                       // 18
var _createHistory2 = _interopRequireDefault(_createHistory);                                                          // 19
                                                                                                                       // 20
function createDOMHistory(options) {                                                                                   // 21
  var history = _createHistory2['default'](_extends({                                                                  // 22
    getUserConfirmation: _DOMUtils.getUserConfirmation                                                                 // 23
  }, options, {                                                                                                        // 24
    go: _DOMUtils.go                                                                                                   // 25
  }));                                                                                                                 // 26
                                                                                                                       // 27
  function listen(listener) {                                                                                          // 28
    !_ExecutionEnvironment.canUseDOM ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'DOM history needs a DOM') : _invariant2['default'](false) : undefined;
                                                                                                                       // 30
    return history.listen(listener);                                                                                   // 31
  }                                                                                                                    // 32
                                                                                                                       // 33
  return _extends({}, history, {                                                                                       // 34
    listen: listen                                                                                                     // 35
  });                                                                                                                  // 36
}                                                                                                                      // 37
                                                                                                                       // 38
exports['default'] = createDOMHistory;                                                                                 // 39
module.exports = exports['default'];                                                                                   // 40
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"./DOMUtils":6,"./ExecutionEnvironment":7,"./createHistory":11,"_process":1,"invariant":27}],10:[function(require,module,exports){
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
var _warning = require('warning');                                                                                     // 9
                                                                                                                       // 10
var _warning2 = _interopRequireDefault(_warning);                                                                      // 11
                                                                                                                       // 12
var _invariant = require('invariant');                                                                                 // 13
                                                                                                                       // 14
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 15
                                                                                                                       // 16
var _Actions = require('./Actions');                                                                                   // 17
                                                                                                                       // 18
var _ExecutionEnvironment = require('./ExecutionEnvironment');                                                         // 19
                                                                                                                       // 20
var _DOMUtils = require('./DOMUtils');                                                                                 // 21
                                                                                                                       // 22
var _DOMStateStorage = require('./DOMStateStorage');                                                                   // 23
                                                                                                                       // 24
var _createDOMHistory = require('./createDOMHistory');                                                                 // 25
                                                                                                                       // 26
var _createDOMHistory2 = _interopRequireDefault(_createDOMHistory);                                                    // 27
                                                                                                                       // 28
function isAbsolutePath(path) {                                                                                        // 29
  return typeof path === 'string' && path.charAt(0) === '/';                                                           // 30
}                                                                                                                      // 31
                                                                                                                       // 32
function ensureSlash() {                                                                                               // 33
  var path = _DOMUtils.getHashPath();                                                                                  // 34
                                                                                                                       // 35
  if (isAbsolutePath(path)) return true;                                                                               // 36
                                                                                                                       // 37
  _DOMUtils.replaceHashPath('/' + path);                                                                               // 38
                                                                                                                       // 39
  return false;                                                                                                        // 40
}                                                                                                                      // 41
                                                                                                                       // 42
function addQueryStringValueToPath(path, key, value) {                                                                 // 43
  return path + (path.indexOf('?') === -1 ? '?' : '&') + (key + '=' + value);                                          // 44
}                                                                                                                      // 45
                                                                                                                       // 46
function stripQueryStringValueFromPath(path, key) {                                                                    // 47
  return path.replace(new RegExp('[?&]?' + key + '=[a-zA-Z0-9]+'), '');                                                // 48
}                                                                                                                      // 49
                                                                                                                       // 50
function getQueryStringValueFromPath(path, key) {                                                                      // 51
  var match = path.match(new RegExp('\\?.*?\\b' + key + '=(.+?)\\b'));                                                 // 52
  return match && match[1];                                                                                            // 53
}                                                                                                                      // 54
                                                                                                                       // 55
var DefaultQueryKey = '_k';                                                                                            // 56
                                                                                                                       // 57
function createHashHistory() {                                                                                         // 58
  var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];                               // 59
                                                                                                                       // 60
  !_ExecutionEnvironment.canUseDOM ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'Hash history needs a DOM') : _invariant2['default'](false) : undefined;
                                                                                                                       // 62
  var queryKey = options.queryKey;                                                                                     // 63
                                                                                                                       // 64
  if (queryKey === undefined || !!queryKey) queryKey = typeof queryKey === 'string' ? queryKey : DefaultQueryKey;      // 65
                                                                                                                       // 66
  function getCurrentLocation() {                                                                                      // 67
    var path = _DOMUtils.getHashPath();                                                                                // 68
                                                                                                                       // 69
    var key = undefined,                                                                                               // 70
        state = undefined;                                                                                             // 71
    if (queryKey) {                                                                                                    // 72
      key = getQueryStringValueFromPath(path, queryKey);                                                               // 73
      path = stripQueryStringValueFromPath(path, queryKey);                                                            // 74
                                                                                                                       // 75
      if (key) {                                                                                                       // 76
        state = _DOMStateStorage.readState(key);                                                                       // 77
      } else {                                                                                                         // 78
        state = null;                                                                                                  // 79
        key = history.createKey();                                                                                     // 80
        _DOMUtils.replaceHashPath(addQueryStringValueToPath(path, queryKey, key));                                     // 81
      }                                                                                                                // 82
    } else {                                                                                                           // 83
      key = state = null;                                                                                              // 84
    }                                                                                                                  // 85
                                                                                                                       // 86
    return history.createLocation(path, state, undefined, key);                                                        // 87
  }                                                                                                                    // 88
                                                                                                                       // 89
  function startHashChangeListener(_ref) {                                                                             // 90
    var transitionTo = _ref.transitionTo;                                                                              // 91
                                                                                                                       // 92
    function hashChangeListener() {                                                                                    // 93
      if (!ensureSlash()) return; // Always make sure hashes are preceeded with a /.                                   // 94
                                                                                                                       // 95
      transitionTo(getCurrentLocation());                                                                              // 96
    }                                                                                                                  // 97
                                                                                                                       // 98
    ensureSlash();                                                                                                     // 99
    _DOMUtils.addEventListener(window, 'hashchange', hashChangeListener);                                              // 100
                                                                                                                       // 101
    return function () {                                                                                               // 102
      _DOMUtils.removeEventListener(window, 'hashchange', hashChangeListener);                                         // 103
    };                                                                                                                 // 104
  }                                                                                                                    // 105
                                                                                                                       // 106
  function finishTransition(location) {                                                                                // 107
    var basename = location.basename;                                                                                  // 108
    var pathname = location.pathname;                                                                                  // 109
    var search = location.search;                                                                                      // 110
    var state = location.state;                                                                                        // 111
    var action = location.action;                                                                                      // 112
    var key = location.key;                                                                                            // 113
                                                                                                                       // 114
    if (action === _Actions.POP) return; // Nothing to do.                                                             // 115
                                                                                                                       // 116
    var path = (basename || '') + pathname + search;                                                                   // 117
                                                                                                                       // 118
    if (queryKey) {                                                                                                    // 119
      path = addQueryStringValueToPath(path, queryKey, key);                                                           // 120
      _DOMStateStorage.saveState(key, state);                                                                          // 121
    } else {                                                                                                           // 122
      // Drop key and state.                                                                                           // 123
      location.key = location.state = null;                                                                            // 124
    }                                                                                                                  // 125
                                                                                                                       // 126
    var currentHash = _DOMUtils.getHashPath();                                                                         // 127
                                                                                                                       // 128
    if (action === _Actions.PUSH) {                                                                                    // 129
      if (currentHash !== path) {                                                                                      // 130
        window.location.hash = path;                                                                                   // 131
      } else {                                                                                                         // 132
        process.env.NODE_ENV !== 'production' ? _warning2['default'](false, 'You cannot PUSH the same path using hash history') : undefined;
      }                                                                                                                // 134
    } else if (currentHash !== path) {                                                                                 // 135
      // REPLACE                                                                                                       // 136
      _DOMUtils.replaceHashPath(path);                                                                                 // 137
    }                                                                                                                  // 138
  }                                                                                                                    // 139
                                                                                                                       // 140
  var history = _createDOMHistory2['default'](_extends({}, options, {                                                  // 141
    getCurrentLocation: getCurrentLocation,                                                                            // 142
    finishTransition: finishTransition,                                                                                // 143
    saveState: _DOMStateStorage.saveState                                                                              // 144
  }));                                                                                                                 // 145
                                                                                                                       // 146
  var listenerCount = 0,                                                                                               // 147
      stopHashChangeListener = undefined;                                                                              // 148
                                                                                                                       // 149
  function listenBefore(listener) {                                                                                    // 150
    if (++listenerCount === 1) stopHashChangeListener = startHashChangeListener(history);                              // 151
                                                                                                                       // 152
    var unlisten = history.listenBefore(listener);                                                                     // 153
                                                                                                                       // 154
    return function () {                                                                                               // 155
      unlisten();                                                                                                      // 156
                                                                                                                       // 157
      if (--listenerCount === 0) stopHashChangeListener();                                                             // 158
    };                                                                                                                 // 159
  }                                                                                                                    // 160
                                                                                                                       // 161
  function listen(listener) {                                                                                          // 162
    if (++listenerCount === 1) stopHashChangeListener = startHashChangeListener(history);                              // 163
                                                                                                                       // 164
    var unlisten = history.listen(listener);                                                                           // 165
                                                                                                                       // 166
    return function () {                                                                                               // 167
      unlisten();                                                                                                      // 168
                                                                                                                       // 169
      if (--listenerCount === 0) stopHashChangeListener();                                                             // 170
    };                                                                                                                 // 171
  }                                                                                                                    // 172
                                                                                                                       // 173
  function pushState(state, path) {                                                                                    // 174
    process.env.NODE_ENV !== 'production' ? _warning2['default'](queryKey || state == null, 'You cannot use state without a queryKey it will be dropped') : undefined;
                                                                                                                       // 176
    history.pushState(state, path);                                                                                    // 177
  }                                                                                                                    // 178
                                                                                                                       // 179
  function replaceState(state, path) {                                                                                 // 180
    process.env.NODE_ENV !== 'production' ? _warning2['default'](queryKey || state == null, 'You cannot use state without a queryKey it will be dropped') : undefined;
                                                                                                                       // 182
    history.replaceState(state, path);                                                                                 // 183
  }                                                                                                                    // 184
                                                                                                                       // 185
  var goIsSupportedWithoutReload = _DOMUtils.supportsGoWithoutReloadUsingHash();                                       // 186
                                                                                                                       // 187
  function go(n) {                                                                                                     // 188
    process.env.NODE_ENV !== 'production' ? _warning2['default'](goIsSupportedWithoutReload, 'Hash history go(n) causes a full page reload in this browser') : undefined;
                                                                                                                       // 190
    history.go(n);                                                                                                     // 191
  }                                                                                                                    // 192
                                                                                                                       // 193
  function createHref(path) {                                                                                          // 194
    return '#' + history.createHref(path);                                                                             // 195
  }                                                                                                                    // 196
                                                                                                                       // 197
  // deprecated                                                                                                        // 198
  function registerTransitionHook(hook) {                                                                              // 199
    if (++listenerCount === 1) stopHashChangeListener = startHashChangeListener(history);                              // 200
                                                                                                                       // 201
    history.registerTransitionHook(hook);                                                                              // 202
  }                                                                                                                    // 203
                                                                                                                       // 204
  // deprecated                                                                                                        // 205
  function unregisterTransitionHook(hook) {                                                                            // 206
    history.unregisterTransitionHook(hook);                                                                            // 207
                                                                                                                       // 208
    if (--listenerCount === 0) stopHashChangeListener();                                                               // 209
  }                                                                                                                    // 210
                                                                                                                       // 211
  return _extends({}, history, {                                                                                       // 212
    listenBefore: listenBefore,                                                                                        // 213
    listen: listen,                                                                                                    // 214
    pushState: pushState,                                                                                              // 215
    replaceState: replaceState,                                                                                        // 216
    go: go,                                                                                                            // 217
    createHref: createHref,                                                                                            // 218
    registerTransitionHook: registerTransitionHook,                                                                    // 219
    unregisterTransitionHook: unregisterTransitionHook                                                                 // 220
  });                                                                                                                  // 221
}                                                                                                                      // 222
                                                                                                                       // 223
exports['default'] = createHashHistory;                                                                                // 224
module.exports = exports['default'];                                                                                   // 225
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"./Actions":3,"./DOMStateStorage":5,"./DOMUtils":6,"./ExecutionEnvironment":7,"./createDOMHistory":9,"_process":1,"invariant":27,"warning":32}],11:[function(require,module,exports){
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
var _deepEqual = require('deep-equal');                                                                                // 9
                                                                                                                       // 10
var _deepEqual2 = _interopRequireDefault(_deepEqual);                                                                  // 11
                                                                                                                       // 12
var _AsyncUtils = require('./AsyncUtils');                                                                             // 13
                                                                                                                       // 14
var _Actions = require('./Actions');                                                                                   // 15
                                                                                                                       // 16
var _createLocation2 = require('./createLocation');                                                                    // 17
                                                                                                                       // 18
var _createLocation3 = _interopRequireDefault(_createLocation2);                                                       // 19
                                                                                                                       // 20
var _runTransitionHook = require('./runTransitionHook');                                                               // 21
                                                                                                                       // 22
var _runTransitionHook2 = _interopRequireDefault(_runTransitionHook);                                                  // 23
                                                                                                                       // 24
var _deprecate = require('./deprecate');                                                                               // 25
                                                                                                                       // 26
var _deprecate2 = _interopRequireDefault(_deprecate);                                                                  // 27
                                                                                                                       // 28
function createRandomKey(length) {                                                                                     // 29
  return Math.random().toString(36).substr(2, length);                                                                 // 30
}                                                                                                                      // 31
                                                                                                                       // 32
function locationsAreEqual(a, b) {                                                                                     // 33
  return a.pathname === b.pathname && a.search === b.search &&                                                         // 34
  //a.action === b.action && // Different action !== location change.                                                  // 35
  a.key === b.key && _deepEqual2['default'](a.state, b.state);                                                         // 36
}                                                                                                                      // 37
                                                                                                                       // 38
var DefaultKeyLength = 6;                                                                                              // 39
                                                                                                                       // 40
function createHistory() {                                                                                             // 41
  var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];                               // 42
  var getCurrentLocation = options.getCurrentLocation;                                                                 // 43
  var finishTransition = options.finishTransition;                                                                     // 44
  var saveState = options.saveState;                                                                                   // 45
  var go = options.go;                                                                                                 // 46
  var keyLength = options.keyLength;                                                                                   // 47
  var getUserConfirmation = options.getUserConfirmation;                                                               // 48
                                                                                                                       // 49
  if (typeof keyLength !== 'number') keyLength = DefaultKeyLength;                                                     // 50
                                                                                                                       // 51
  var transitionHooks = [];                                                                                            // 52
                                                                                                                       // 53
  function listenBefore(hook) {                                                                                        // 54
    transitionHooks.push(hook);                                                                                        // 55
                                                                                                                       // 56
    return function () {                                                                                               // 57
      transitionHooks = transitionHooks.filter(function (item) {                                                       // 58
        return item !== hook;                                                                                          // 59
      });                                                                                                              // 60
    };                                                                                                                 // 61
  }                                                                                                                    // 62
                                                                                                                       // 63
  var allKeys = [];                                                                                                    // 64
  var changeListeners = [];                                                                                            // 65
  var location = undefined;                                                                                            // 66
                                                                                                                       // 67
  function getCurrent() {                                                                                              // 68
    if (pendingLocation && pendingLocation.action === _Actions.POP) {                                                  // 69
      return allKeys.indexOf(pendingLocation.key);                                                                     // 70
    } else if (location) {                                                                                             // 71
      return allKeys.indexOf(location.key);                                                                            // 72
    } else {                                                                                                           // 73
      return -1;                                                                                                       // 74
    }                                                                                                                  // 75
  }                                                                                                                    // 76
                                                                                                                       // 77
  function updateLocation(newLocation) {                                                                               // 78
    var current = getCurrent();                                                                                        // 79
                                                                                                                       // 80
    location = newLocation;                                                                                            // 81
                                                                                                                       // 82
    if (location.action === _Actions.PUSH) {                                                                           // 83
      allKeys = [].concat(allKeys.slice(0, current + 1), [location.key]);                                              // 84
    } else if (location.action === _Actions.REPLACE) {                                                                 // 85
      allKeys[current] = location.key;                                                                                 // 86
    }                                                                                                                  // 87
                                                                                                                       // 88
    changeListeners.forEach(function (listener) {                                                                      // 89
      listener(location);                                                                                              // 90
    });                                                                                                                // 91
  }                                                                                                                    // 92
                                                                                                                       // 93
  function listen(listener) {                                                                                          // 94
    changeListeners.push(listener);                                                                                    // 95
                                                                                                                       // 96
    if (location) {                                                                                                    // 97
      listener(location);                                                                                              // 98
    } else {                                                                                                           // 99
      var _location = getCurrentLocation();                                                                            // 100
      allKeys = [_location.key];                                                                                       // 101
      updateLocation(_location);                                                                                       // 102
    }                                                                                                                  // 103
                                                                                                                       // 104
    return function () {                                                                                               // 105
      changeListeners = changeListeners.filter(function (item) {                                                       // 106
        return item !== listener;                                                                                      // 107
      });                                                                                                              // 108
    };                                                                                                                 // 109
  }                                                                                                                    // 110
                                                                                                                       // 111
  function confirmTransitionTo(location, callback) {                                                                   // 112
    _AsyncUtils.loopAsync(transitionHooks.length, function (index, next, done) {                                       // 113
      _runTransitionHook2['default'](transitionHooks[index], location, function (result) {                             // 114
        if (result != null) {                                                                                          // 115
          done(result);                                                                                                // 116
        } else {                                                                                                       // 117
          next();                                                                                                      // 118
        }                                                                                                              // 119
      });                                                                                                              // 120
    }, function (message) {                                                                                            // 121
      if (getUserConfirmation && typeof message === 'string') {                                                        // 122
        getUserConfirmation(message, function (ok) {                                                                   // 123
          callback(ok !== false);                                                                                      // 124
        });                                                                                                            // 125
      } else {                                                                                                         // 126
        callback(message !== false);                                                                                   // 127
      }                                                                                                                // 128
    });                                                                                                                // 129
  }                                                                                                                    // 130
                                                                                                                       // 131
  var pendingLocation = undefined;                                                                                     // 132
                                                                                                                       // 133
  function transitionTo(nextLocation) {                                                                                // 134
    if (location && locationsAreEqual(location, nextLocation)) return; // Nothing to do.                               // 135
                                                                                                                       // 136
    pendingLocation = nextLocation;                                                                                    // 137
                                                                                                                       // 138
    confirmTransitionTo(nextLocation, function (ok) {                                                                  // 139
      if (pendingLocation !== nextLocation) return; // Transition was interrupted.                                     // 140
                                                                                                                       // 141
      if (ok) {                                                                                                        // 142
        // treat PUSH to current path like REPLACE to be consistent with browsers                                      // 143
        if (nextLocation.action === _Actions.PUSH) {                                                                   // 144
          var _getCurrentLocation = getCurrentLocation();                                                              // 145
                                                                                                                       // 146
          var pathname = _getCurrentLocation.pathname;                                                                 // 147
          var search = _getCurrentLocation.search;                                                                     // 148
                                                                                                                       // 149
          var currentPath = pathname + search;                                                                         // 150
          var path = nextLocation.pathname + nextLocation.search;                                                      // 151
                                                                                                                       // 152
          if (currentPath === path) nextLocation.action = _Actions.REPLACE;                                            // 153
        }                                                                                                              // 154
                                                                                                                       // 155
        if (finishTransition(nextLocation) !== false) updateLocation(nextLocation);                                    // 156
      } else if (location && nextLocation.action === _Actions.POP) {                                                   // 157
        var prevIndex = allKeys.indexOf(location.key);                                                                 // 158
        var nextIndex = allKeys.indexOf(nextLocation.key);                                                             // 159
                                                                                                                       // 160
        if (prevIndex !== -1 && nextIndex !== -1) go(prevIndex - nextIndex); // Restore the URL.                       // 161
      }                                                                                                                // 162
    });                                                                                                                // 163
  }                                                                                                                    // 164
                                                                                                                       // 165
  function pushState(state, path) {                                                                                    // 166
    transitionTo(createLocation(path, state, _Actions.PUSH, createKey()));                                             // 167
  }                                                                                                                    // 168
                                                                                                                       // 169
  function push(path) {                                                                                                // 170
    pushState(null, path);                                                                                             // 171
  }                                                                                                                    // 172
                                                                                                                       // 173
  function replaceState(state, path) {                                                                                 // 174
    transitionTo(createLocation(path, state, _Actions.REPLACE, createKey()));                                          // 175
  }                                                                                                                    // 176
                                                                                                                       // 177
  function replace(path) {                                                                                             // 178
    replaceState(null, path);                                                                                          // 179
  }                                                                                                                    // 180
                                                                                                                       // 181
  function goBack() {                                                                                                  // 182
    go(-1);                                                                                                            // 183
  }                                                                                                                    // 184
                                                                                                                       // 185
  function goForward() {                                                                                               // 186
    go(1);                                                                                                             // 187
  }                                                                                                                    // 188
                                                                                                                       // 189
  function createKey() {                                                                                               // 190
    return createRandomKey(keyLength);                                                                                 // 191
  }                                                                                                                    // 192
                                                                                                                       // 193
  function createPath(path) {                                                                                          // 194
    if (path == null || typeof path === 'string') return path;                                                         // 195
                                                                                                                       // 196
    var pathname = path.pathname;                                                                                      // 197
    var search = path.search;                                                                                          // 198
    var hash = path.hash;                                                                                              // 199
                                                                                                                       // 200
    var result = pathname;                                                                                             // 201
                                                                                                                       // 202
    if (search) result += search;                                                                                      // 203
                                                                                                                       // 204
    if (hash) result += hash;                                                                                          // 205
                                                                                                                       // 206
    return result;                                                                                                     // 207
  }                                                                                                                    // 208
                                                                                                                       // 209
  function createHref(path) {                                                                                          // 210
    return createPath(path);                                                                                           // 211
  }                                                                                                                    // 212
                                                                                                                       // 213
  function createLocation(path, state, action) {                                                                       // 214
    var key = arguments.length <= 3 || arguments[3] === undefined ? createKey() : arguments[3];                        // 215
                                                                                                                       // 216
    return _createLocation3['default'](path, state, action, key);                                                      // 217
  }                                                                                                                    // 218
                                                                                                                       // 219
  // deprecated                                                                                                        // 220
  function setState(state) {                                                                                           // 221
    if (location) {                                                                                                    // 222
      updateLocationState(location, state);                                                                            // 223
      updateLocation(location);                                                                                        // 224
    } else {                                                                                                           // 225
      updateLocationState(getCurrentLocation(), state);                                                                // 226
    }                                                                                                                  // 227
  }                                                                                                                    // 228
                                                                                                                       // 229
  function updateLocationState(location, state) {                                                                      // 230
    location.state = _extends({}, location.state, state);                                                              // 231
    saveState(location.key, location.state);                                                                           // 232
  }                                                                                                                    // 233
                                                                                                                       // 234
  // deprecated                                                                                                        // 235
  function registerTransitionHook(hook) {                                                                              // 236
    if (transitionHooks.indexOf(hook) === -1) transitionHooks.push(hook);                                              // 237
  }                                                                                                                    // 238
                                                                                                                       // 239
  // deprecated                                                                                                        // 240
  function unregisterTransitionHook(hook) {                                                                            // 241
    transitionHooks = transitionHooks.filter(function (item) {                                                         // 242
      return item !== hook;                                                                                            // 243
    });                                                                                                                // 244
  }                                                                                                                    // 245
                                                                                                                       // 246
  return {                                                                                                             // 247
    listenBefore: listenBefore,                                                                                        // 248
    listen: listen,                                                                                                    // 249
    transitionTo: transitionTo,                                                                                        // 250
    pushState: pushState,                                                                                              // 251
    replaceState: replaceState,                                                                                        // 252
    push: push,                                                                                                        // 253
    replace: replace,                                                                                                  // 254
    go: go,                                                                                                            // 255
    goBack: goBack,                                                                                                    // 256
    goForward: goForward,                                                                                              // 257
    createKey: createKey,                                                                                              // 258
    createPath: createPath,                                                                                            // 259
    createHref: createHref,                                                                                            // 260
    createLocation: createLocation,                                                                                    // 261
                                                                                                                       // 262
    setState: _deprecate2['default'](setState, 'setState is deprecated; use location.key to save state instead'),      // 263
    registerTransitionHook: _deprecate2['default'](registerTransitionHook, 'registerTransitionHook is deprecated; use listenBefore instead'),
    unregisterTransitionHook: _deprecate2['default'](unregisterTransitionHook, 'unregisterTransitionHook is deprecated; use the callback returned from listenBefore instead')
  };                                                                                                                   // 266
}                                                                                                                      // 267
                                                                                                                       // 268
exports['default'] = createHistory;                                                                                    // 269
module.exports = exports['default'];                                                                                   // 270
},{"./Actions":3,"./AsyncUtils":4,"./createLocation":12,"./deprecate":14,"./runTransitionHook":20,"deep-equal":24}],12:[function(require,module,exports){
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 5
                                                                                                                       // 6
var _Actions = require('./Actions');                                                                                   // 7
                                                                                                                       // 8
var _parsePath = require('./parsePath');                                                                               // 9
                                                                                                                       // 10
var _parsePath2 = _interopRequireDefault(_parsePath);                                                                  // 11
                                                                                                                       // 12
function createLocation() {                                                                                            // 13
  var path = arguments.length <= 0 || arguments[0] === undefined ? '/' : arguments[0];                                 // 14
  var state = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];                               // 15
  var action = arguments.length <= 2 || arguments[2] === undefined ? _Actions.POP : arguments[2];                      // 16
  var key = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];                                 // 17
                                                                                                                       // 18
  if (typeof path === 'string') path = _parsePath2['default'](path);                                                   // 19
                                                                                                                       // 20
  var pathname = path.pathname || '/';                                                                                 // 21
  var search = path.search || '';                                                                                      // 22
  var hash = path.hash || '';                                                                                          // 23
                                                                                                                       // 24
  return {                                                                                                             // 25
    pathname: pathname,                                                                                                // 26
    search: search,                                                                                                    // 27
    hash: hash,                                                                                                        // 28
    state: state,                                                                                                      // 29
    action: action,                                                                                                    // 30
    key: key                                                                                                           // 31
  };                                                                                                                   // 32
}                                                                                                                      // 33
                                                                                                                       // 34
exports['default'] = createLocation;                                                                                   // 35
module.exports = exports['default'];                                                                                   // 36
},{"./Actions":3,"./parsePath":19}],13:[function(require,module,exports){                                              //
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
var _invariant = require('invariant');                                                                                 // 9
                                                                                                                       // 10
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 11
                                                                                                                       // 12
var _Actions = require('./Actions');                                                                                   // 13
                                                                                                                       // 14
var _createHistory = require('./createHistory');                                                                       // 15
                                                                                                                       // 16
var _createHistory2 = _interopRequireDefault(_createHistory);                                                          // 17
                                                                                                                       // 18
function createStateStorage(entries) {                                                                                 // 19
  return entries.filter(function (entry) {                                                                             // 20
    return entry.state;                                                                                                // 21
  }).reduce(function (memo, entry) {                                                                                   // 22
    memo[entry.key] = entry.state;                                                                                     // 23
    return memo;                                                                                                       // 24
  }, {});                                                                                                              // 25
}                                                                                                                      // 26
                                                                                                                       // 27
function createMemoryHistory() {                                                                                       // 28
  var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];                               // 29
                                                                                                                       // 30
  if (Array.isArray(options)) {                                                                                        // 31
    options = { entries: options };                                                                                    // 32
  } else if (typeof options === 'string') {                                                                            // 33
    options = { entries: [options] };                                                                                  // 34
  }                                                                                                                    // 35
                                                                                                                       // 36
  var history = _createHistory2['default'](_extends({}, options, {                                                     // 37
    getCurrentLocation: getCurrentLocation,                                                                            // 38
    finishTransition: finishTransition,                                                                                // 39
    saveState: saveState,                                                                                              // 40
    go: go                                                                                                             // 41
  }));                                                                                                                 // 42
                                                                                                                       // 43
  var _options = options;                                                                                              // 44
  var entries = _options.entries;                                                                                      // 45
  var current = _options.current;                                                                                      // 46
                                                                                                                       // 47
  if (typeof entries === 'string') {                                                                                   // 48
    entries = [entries];                                                                                               // 49
  } else if (!Array.isArray(entries)) {                                                                                // 50
    entries = ['/'];                                                                                                   // 51
  }                                                                                                                    // 52
                                                                                                                       // 53
  entries = entries.map(function (entry) {                                                                             // 54
    var key = history.createKey();                                                                                     // 55
                                                                                                                       // 56
    if (typeof entry === 'string') return { pathname: entry, key: key };                                               // 57
                                                                                                                       // 58
    if (typeof entry === 'object' && entry) return _extends({}, entry, { key: key });                                  // 59
                                                                                                                       // 60
    !false ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'Unable to create history entry from %s', entry) : _invariant2['default'](false) : undefined;
  });                                                                                                                  // 62
                                                                                                                       // 63
  if (current == null) {                                                                                               // 64
    current = entries.length - 1;                                                                                      // 65
  } else {                                                                                                             // 66
    !(current >= 0 && current < entries.length) ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'Current index must be >= 0 and < %s, was %s', entries.length, current) : _invariant2['default'](false) : undefined;
  }                                                                                                                    // 68
                                                                                                                       // 69
  var storage = createStateStorage(entries);                                                                           // 70
                                                                                                                       // 71
  function saveState(key, state) {                                                                                     // 72
    storage[key] = state;                                                                                              // 73
  }                                                                                                                    // 74
                                                                                                                       // 75
  function readState(key) {                                                                                            // 76
    return storage[key];                                                                                               // 77
  }                                                                                                                    // 78
                                                                                                                       // 79
  function getCurrentLocation() {                                                                                      // 80
    var entry = entries[current];                                                                                      // 81
    var key = entry.key;                                                                                               // 82
    var basename = entry.basename;                                                                                     // 83
    var pathname = entry.pathname;                                                                                     // 84
    var search = entry.search;                                                                                         // 85
                                                                                                                       // 86
    var path = (basename || '') + pathname + (search || '');                                                           // 87
                                                                                                                       // 88
    var state = undefined;                                                                                             // 89
    if (key) {                                                                                                         // 90
      state = readState(key);                                                                                          // 91
    } else {                                                                                                           // 92
      state = null;                                                                                                    // 93
      key = history.createKey();                                                                                       // 94
      entry.key = key;                                                                                                 // 95
    }                                                                                                                  // 96
                                                                                                                       // 97
    return history.createLocation(path, state, undefined, key);                                                        // 98
  }                                                                                                                    // 99
                                                                                                                       // 100
  function canGo(n) {                                                                                                  // 101
    var index = current + n;                                                                                           // 102
    return index >= 0 && index < entries.length;                                                                       // 103
  }                                                                                                                    // 104
                                                                                                                       // 105
  function go(n) {                                                                                                     // 106
    if (n) {                                                                                                           // 107
      !canGo(n) ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'Cannot go(%s) there is not enough history', n) : _invariant2['default'](false) : undefined;
                                                                                                                       // 109
      current += n;                                                                                                    // 110
                                                                                                                       // 111
      var currentLocation = getCurrentLocation();                                                                      // 112
                                                                                                                       // 113
      // change action to POP                                                                                          // 114
      history.transitionTo(_extends({}, currentLocation, { action: _Actions.POP }));                                   // 115
    }                                                                                                                  // 116
  }                                                                                                                    // 117
                                                                                                                       // 118
  function finishTransition(location) {                                                                                // 119
    switch (location.action) {                                                                                         // 120
      case _Actions.PUSH:                                                                                              // 121
        current += 1;                                                                                                  // 122
                                                                                                                       // 123
        // if we are not on the top of stack                                                                           // 124
        // remove rest and push new                                                                                    // 125
        if (current < entries.length) entries.splice(current);                                                         // 126
                                                                                                                       // 127
        entries.push(location);                                                                                        // 128
        saveState(location.key, location.state);                                                                       // 129
        break;                                                                                                         // 130
      case _Actions.REPLACE:                                                                                           // 131
        entries[current] = location;                                                                                   // 132
        saveState(location.key, location.state);                                                                       // 133
        break;                                                                                                         // 134
    }                                                                                                                  // 135
  }                                                                                                                    // 136
                                                                                                                       // 137
  return history;                                                                                                      // 138
}                                                                                                                      // 139
                                                                                                                       // 140
exports['default'] = createMemoryHistory;                                                                              // 141
module.exports = exports['default'];                                                                                   // 142
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"./Actions":3,"./createHistory":11,"_process":1,"invariant":27}],14:[function(require,module,exports){              //
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 5
                                                                                                                       // 6
var _warning = require('warning');                                                                                     // 7
                                                                                                                       // 8
var _warning2 = _interopRequireDefault(_warning);                                                                      // 9
                                                                                                                       // 10
function deprecate(fn, message) {                                                                                      // 11
  return function () {                                                                                                 // 12
    process.env.NODE_ENV !== 'production' ? _warning2['default'](false, '[history] ' + message) : undefined;           // 13
    return fn.apply(this, arguments);                                                                                  // 14
  };                                                                                                                   // 15
}                                                                                                                      // 16
                                                                                                                       // 17
exports['default'] = deprecate;                                                                                        // 18
module.exports = exports['default'];                                                                                   // 19
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"_process":1,"warning":32}],15:[function(require,module,exports){                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 5
                                                                                                                       // 6
var _deprecate = require('./deprecate');                                                                               // 7
                                                                                                                       // 8
var _deprecate2 = _interopRequireDefault(_deprecate);                                                                  // 9
                                                                                                                       // 10
var _useBeforeUnload = require('./useBeforeUnload');                                                                   // 11
                                                                                                                       // 12
var _useBeforeUnload2 = _interopRequireDefault(_useBeforeUnload);                                                      // 13
                                                                                                                       // 14
exports['default'] = _deprecate2['default'](_useBeforeUnload2['default'], 'enableBeforeUnload is deprecated, use useBeforeUnload instead');
module.exports = exports['default'];                                                                                   // 16
},{"./deprecate":14,"./useBeforeUnload":22}],16:[function(require,module,exports){                                     //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 5
                                                                                                                       // 6
var _deprecate = require('./deprecate');                                                                               // 7
                                                                                                                       // 8
var _deprecate2 = _interopRequireDefault(_deprecate);                                                                  // 9
                                                                                                                       // 10
var _useQueries = require('./useQueries');                                                                             // 11
                                                                                                                       // 12
var _useQueries2 = _interopRequireDefault(_useQueries);                                                                // 13
                                                                                                                       // 14
exports['default'] = _deprecate2['default'](_useQueries2['default'], 'enableQueries is deprecated, use useQueries instead');
module.exports = exports['default'];                                                                                   // 16
},{"./deprecate":14,"./useQueries":23}],17:[function(require,module,exports){                                          //
"use strict";                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
function extractPath(string) {                                                                                         // 4
  var match = string.match(/^https?:\/\/[^\/]*/);                                                                      // 5
                                                                                                                       // 6
  if (match == null) return string;                                                                                    // 7
                                                                                                                       // 8
  return string.substring(match[0].length);                                                                            // 9
}                                                                                                                      // 10
                                                                                                                       // 11
exports["default"] = extractPath;                                                                                      // 12
module.exports = exports["default"];                                                                                   // 13
},{}],18:[function(require,module,exports){                                                                            //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 5
                                                                                                                       // 6
var _createBrowserHistory = require('./createBrowserHistory');                                                         // 7
                                                                                                                       // 8
var _createBrowserHistory2 = _interopRequireDefault(_createBrowserHistory);                                            // 9
                                                                                                                       // 10
exports.createHistory = _createBrowserHistory2['default'];                                                             // 11
                                                                                                                       // 12
var _createHashHistory2 = require('./createHashHistory');                                                              // 13
                                                                                                                       // 14
var _createHashHistory3 = _interopRequireDefault(_createHashHistory2);                                                 // 15
                                                                                                                       // 16
exports.createHashHistory = _createHashHistory3['default'];                                                            // 17
                                                                                                                       // 18
var _createMemoryHistory2 = require('./createMemoryHistory');                                                          // 19
                                                                                                                       // 20
var _createMemoryHistory3 = _interopRequireDefault(_createMemoryHistory2);                                             // 21
                                                                                                                       // 22
exports.createMemoryHistory = _createMemoryHistory3['default'];                                                        // 23
                                                                                                                       // 24
var _createLocation2 = require('./createLocation');                                                                    // 25
                                                                                                                       // 26
var _createLocation3 = _interopRequireDefault(_createLocation2);                                                       // 27
                                                                                                                       // 28
exports.createLocation = _createLocation3['default'];                                                                  // 29
                                                                                                                       // 30
var _useBasename2 = require('./useBasename');                                                                          // 31
                                                                                                                       // 32
var _useBasename3 = _interopRequireDefault(_useBasename2);                                                             // 33
                                                                                                                       // 34
exports.useBasename = _useBasename3['default'];                                                                        // 35
                                                                                                                       // 36
var _useBeforeUnload2 = require('./useBeforeUnload');                                                                  // 37
                                                                                                                       // 38
var _useBeforeUnload3 = _interopRequireDefault(_useBeforeUnload2);                                                     // 39
                                                                                                                       // 40
exports.useBeforeUnload = _useBeforeUnload3['default'];                                                                // 41
                                                                                                                       // 42
var _useQueries2 = require('./useQueries');                                                                            // 43
                                                                                                                       // 44
var _useQueries3 = _interopRequireDefault(_useQueries2);                                                               // 45
                                                                                                                       // 46
exports.useQueries = _useQueries3['default'];                                                                          // 47
                                                                                                                       // 48
var _Actions2 = require('./Actions');                                                                                  // 49
                                                                                                                       // 50
var _Actions3 = _interopRequireDefault(_Actions2);                                                                     // 51
                                                                                                                       // 52
exports.Actions = _Actions3['default'];                                                                                // 53
                                                                                                                       // 54
// deprecated                                                                                                          // 55
                                                                                                                       // 56
var _enableBeforeUnload2 = require('./enableBeforeUnload');                                                            // 57
                                                                                                                       // 58
var _enableBeforeUnload3 = _interopRequireDefault(_enableBeforeUnload2);                                               // 59
                                                                                                                       // 60
exports.enableBeforeUnload = _enableBeforeUnload3['default'];                                                          // 61
                                                                                                                       // 62
var _enableQueries2 = require('./enableQueries');                                                                      // 63
                                                                                                                       // 64
var _enableQueries3 = _interopRequireDefault(_enableQueries2);                                                         // 65
                                                                                                                       // 66
exports.enableQueries = _enableQueries3['default'];                                                                    // 67
},{"./Actions":3,"./createBrowserHistory":8,"./createHashHistory":10,"./createLocation":12,"./createMemoryHistory":13,"./enableBeforeUnload":15,"./enableQueries":16,"./useBasename":21,"./useBeforeUnload":22,"./useQueries":23}],19:[function(require,module,exports){
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 5
                                                                                                                       // 6
var _warning = require('warning');                                                                                     // 7
                                                                                                                       // 8
var _warning2 = _interopRequireDefault(_warning);                                                                      // 9
                                                                                                                       // 10
var _extractPath = require('./extractPath');                                                                           // 11
                                                                                                                       // 12
var _extractPath2 = _interopRequireDefault(_extractPath);                                                              // 13
                                                                                                                       // 14
function parsePath(path) {                                                                                             // 15
  var pathname = _extractPath2['default'](path);                                                                       // 16
  var search = '';                                                                                                     // 17
  var hash = '';                                                                                                       // 18
                                                                                                                       // 19
  process.env.NODE_ENV !== 'production' ? _warning2['default'](path === pathname, 'A path must be pathname + search + hash only, not a fully qualified URL like "%s"', path) : undefined;
                                                                                                                       // 21
  var hashIndex = pathname.indexOf('#');                                                                               // 22
  if (hashIndex !== -1) {                                                                                              // 23
    hash = pathname.substring(hashIndex);                                                                              // 24
    pathname = pathname.substring(0, hashIndex);                                                                       // 25
  }                                                                                                                    // 26
                                                                                                                       // 27
  var searchIndex = pathname.indexOf('?');                                                                             // 28
  if (searchIndex !== -1) {                                                                                            // 29
    search = pathname.substring(searchIndex);                                                                          // 30
    pathname = pathname.substring(0, searchIndex);                                                                     // 31
  }                                                                                                                    // 32
                                                                                                                       // 33
  if (pathname === '') pathname = '/';                                                                                 // 34
                                                                                                                       // 35
  return {                                                                                                             // 36
    pathname: pathname,                                                                                                // 37
    search: search,                                                                                                    // 38
    hash: hash                                                                                                         // 39
  };                                                                                                                   // 40
}                                                                                                                      // 41
                                                                                                                       // 42
exports['default'] = parsePath;                                                                                        // 43
module.exports = exports['default'];                                                                                   // 44
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"./extractPath":17,"_process":1,"warning":32}],20:[function(require,module,exports){                                //
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 5
                                                                                                                       // 6
var _warning = require('warning');                                                                                     // 7
                                                                                                                       // 8
var _warning2 = _interopRequireDefault(_warning);                                                                      // 9
                                                                                                                       // 10
function runTransitionHook(hook, location, callback) {                                                                 // 11
  var result = hook(location, callback);                                                                               // 12
                                                                                                                       // 13
  if (hook.length < 2) {                                                                                               // 14
    // Assume the hook runs synchronously and automatically                                                            // 15
    // call the callback with the return value.                                                                        // 16
    callback(result);                                                                                                  // 17
  } else {                                                                                                             // 18
    process.env.NODE_ENV !== 'production' ? _warning2['default'](result === undefined, 'You should not "return" in a transition hook with a callback argument; call the callback instead') : undefined;
  }                                                                                                                    // 20
}                                                                                                                      // 21
                                                                                                                       // 22
exports['default'] = runTransitionHook;                                                                                // 23
module.exports = exports['default'];                                                                                   // 24
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"_process":1,"warning":32}],21:[function(require,module,exports){                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }
                                                                                                                       // 10
var _ExecutionEnvironment = require('./ExecutionEnvironment');                                                         // 11
                                                                                                                       // 12
var _runTransitionHook = require('./runTransitionHook');                                                               // 13
                                                                                                                       // 14
var _runTransitionHook2 = _interopRequireDefault(_runTransitionHook);                                                  // 15
                                                                                                                       // 16
var _extractPath = require('./extractPath');                                                                           // 17
                                                                                                                       // 18
var _extractPath2 = _interopRequireDefault(_extractPath);                                                              // 19
                                                                                                                       // 20
var _parsePath = require('./parsePath');                                                                               // 21
                                                                                                                       // 22
var _parsePath2 = _interopRequireDefault(_parsePath);                                                                  // 23
                                                                                                                       // 24
function useBasename(createHistory) {                                                                                  // 25
  return function () {                                                                                                 // 26
    var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];                             // 27
    var basename = options.basename;                                                                                   // 28
                                                                                                                       // 29
    var historyOptions = _objectWithoutProperties(options, ['basename']);                                              // 30
                                                                                                                       // 31
    var history = createHistory(historyOptions);                                                                       // 32
                                                                                                                       // 33
    // Automatically use the value of <base href> in HTML                                                              // 34
    // documents as basename if it's not explicitly given.                                                             // 35
    if (basename == null && _ExecutionEnvironment.canUseDOM) {                                                         // 36
      var base = document.getElementsByTagName('base')[0];                                                             // 37
                                                                                                                       // 38
      if (base) basename = _extractPath2['default'](base.href);                                                        // 39
    }                                                                                                                  // 40
                                                                                                                       // 41
    function addBasename(location) {                                                                                   // 42
      if (basename && location.basename == null) {                                                                     // 43
        if (location.pathname.indexOf(basename) === 0) {                                                               // 44
          location.pathname = location.pathname.substring(basename.length);                                            // 45
          location.basename = basename;                                                                                // 46
                                                                                                                       // 47
          if (location.pathname === '') location.pathname = '/';                                                       // 48
        } else {                                                                                                       // 49
          location.basename = '';                                                                                      // 50
        }                                                                                                              // 51
      }                                                                                                                // 52
                                                                                                                       // 53
      return location;                                                                                                 // 54
    }                                                                                                                  // 55
                                                                                                                       // 56
    function prependBasename(path) {                                                                                   // 57
      if (!basename) return path;                                                                                      // 58
                                                                                                                       // 59
      if (typeof path === 'string') path = _parsePath2['default'](path);                                               // 60
                                                                                                                       // 61
      var pname = path.pathname;                                                                                       // 62
      var normalizedBasename = basename.slice(-1) === '/' ? basename : basename + '/';                                 // 63
      var normalizedPathname = pname.charAt(0) === '/' ? pname.slice(1) : pname;                                       // 64
      var pathname = normalizedBasename + normalizedPathname;                                                          // 65
                                                                                                                       // 66
      return _extends({}, path, {                                                                                      // 67
        pathname: pathname                                                                                             // 68
      });                                                                                                              // 69
    }                                                                                                                  // 70
                                                                                                                       // 71
    // Override all read methods with basename-aware versions.                                                         // 72
    function listenBefore(hook) {                                                                                      // 73
      return history.listenBefore(function (location, callback) {                                                      // 74
        _runTransitionHook2['default'](hook, addBasename(location), callback);                                         // 75
      });                                                                                                              // 76
    }                                                                                                                  // 77
                                                                                                                       // 78
    function listen(listener) {                                                                                        // 79
      return history.listen(function (location) {                                                                      // 80
        listener(addBasename(location));                                                                               // 81
      });                                                                                                              // 82
    }                                                                                                                  // 83
                                                                                                                       // 84
    // Override all write methods with basename-aware versions.                                                        // 85
    function pushState(state, path) {                                                                                  // 86
      history.pushState(state, prependBasename(path));                                                                 // 87
    }                                                                                                                  // 88
                                                                                                                       // 89
    function push(path) {                                                                                              // 90
      pushState(null, path);                                                                                           // 91
    }                                                                                                                  // 92
                                                                                                                       // 93
    function replaceState(state, path) {                                                                               // 94
      history.replaceState(state, prependBasename(path));                                                              // 95
    }                                                                                                                  // 96
                                                                                                                       // 97
    function replace(path) {                                                                                           // 98
      replaceState(null, path);                                                                                        // 99
    }                                                                                                                  // 100
                                                                                                                       // 101
    function createPath(path) {                                                                                        // 102
      return history.createPath(prependBasename(path));                                                                // 103
    }                                                                                                                  // 104
                                                                                                                       // 105
    function createHref(path) {                                                                                        // 106
      return history.createHref(prependBasename(path));                                                                // 107
    }                                                                                                                  // 108
                                                                                                                       // 109
    function createLocation() {                                                                                        // 110
      return addBasename(history.createLocation.apply(history, arguments));                                            // 111
    }                                                                                                                  // 112
                                                                                                                       // 113
    return _extends({}, history, {                                                                                     // 114
      listenBefore: listenBefore,                                                                                      // 115
      listen: listen,                                                                                                  // 116
      pushState: pushState,                                                                                            // 117
      push: push,                                                                                                      // 118
      replaceState: replaceState,                                                                                      // 119
      replace: replace,                                                                                                // 120
      createPath: createPath,                                                                                          // 121
      createHref: createHref,                                                                                          // 122
      createLocation: createLocation                                                                                   // 123
    });                                                                                                                // 124
  };                                                                                                                   // 125
}                                                                                                                      // 126
                                                                                                                       // 127
exports['default'] = useBasename;                                                                                      // 128
module.exports = exports['default'];                                                                                   // 129
},{"./ExecutionEnvironment":7,"./extractPath":17,"./parsePath":19,"./runTransitionHook":20}],22:[function(require,module,exports){
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
var _warning = require('warning');                                                                                     // 9
                                                                                                                       // 10
var _warning2 = _interopRequireDefault(_warning);                                                                      // 11
                                                                                                                       // 12
var _ExecutionEnvironment = require('./ExecutionEnvironment');                                                         // 13
                                                                                                                       // 14
var _DOMUtils = require('./DOMUtils');                                                                                 // 15
                                                                                                                       // 16
var _deprecate = require('./deprecate');                                                                               // 17
                                                                                                                       // 18
var _deprecate2 = _interopRequireDefault(_deprecate);                                                                  // 19
                                                                                                                       // 20
function startBeforeUnloadListener(getBeforeUnloadPromptMessage) {                                                     // 21
  function listener(event) {                                                                                           // 22
    var message = getBeforeUnloadPromptMessage();                                                                      // 23
                                                                                                                       // 24
    if (typeof message === 'string') {                                                                                 // 25
      (event || window.event).returnValue = message;                                                                   // 26
      return message;                                                                                                  // 27
    }                                                                                                                  // 28
  }                                                                                                                    // 29
                                                                                                                       // 30
  _DOMUtils.addEventListener(window, 'beforeunload', listener);                                                        // 31
                                                                                                                       // 32
  return function () {                                                                                                 // 33
    _DOMUtils.removeEventListener(window, 'beforeunload', listener);                                                   // 34
  };                                                                                                                   // 35
}                                                                                                                      // 36
                                                                                                                       // 37
/**                                                                                                                    // 38
 * Returns a new createHistory function that can be used to create                                                     // 39
 * history objects that know how to use the beforeunload event in web                                                  // 40
 * browsers to cancel navigation.                                                                                      // 41
 */                                                                                                                    // 42
function useBeforeUnload(createHistory) {                                                                              // 43
  return function (options) {                                                                                          // 44
    var history = createHistory(options);                                                                              // 45
                                                                                                                       // 46
    var stopBeforeUnloadListener = undefined;                                                                          // 47
    var beforeUnloadHooks = [];                                                                                        // 48
                                                                                                                       // 49
    function getBeforeUnloadPromptMessage() {                                                                          // 50
      var message = undefined;                                                                                         // 51
                                                                                                                       // 52
      for (var i = 0, len = beforeUnloadHooks.length; message == null && i < len; ++i) {                               // 53
        message = beforeUnloadHooks[i].call();                                                                         // 54
      }return message;                                                                                                 // 55
    }                                                                                                                  // 56
                                                                                                                       // 57
    function listenBeforeUnload(hook) {                                                                                // 58
      beforeUnloadHooks.push(hook);                                                                                    // 59
                                                                                                                       // 60
      if (beforeUnloadHooks.length === 1) {                                                                            // 61
        if (_ExecutionEnvironment.canUseDOM) {                                                                         // 62
          stopBeforeUnloadListener = startBeforeUnloadListener(getBeforeUnloadPromptMessage);                          // 63
        } else {                                                                                                       // 64
          process.env.NODE_ENV !== 'production' ? _warning2['default'](false, 'listenBeforeUnload only works in DOM environments') : undefined;
        }                                                                                                              // 66
      }                                                                                                                // 67
                                                                                                                       // 68
      return function () {                                                                                             // 69
        beforeUnloadHooks = beforeUnloadHooks.filter(function (item) {                                                 // 70
          return item !== hook;                                                                                        // 71
        });                                                                                                            // 72
                                                                                                                       // 73
        if (beforeUnloadHooks.length === 0 && stopBeforeUnloadListener) {                                              // 74
          stopBeforeUnloadListener();                                                                                  // 75
          stopBeforeUnloadListener = null;                                                                             // 76
        }                                                                                                              // 77
      };                                                                                                               // 78
    }                                                                                                                  // 79
                                                                                                                       // 80
    // deprecated                                                                                                      // 81
    function registerBeforeUnloadHook(hook) {                                                                          // 82
      if (_ExecutionEnvironment.canUseDOM && beforeUnloadHooks.indexOf(hook) === -1) {                                 // 83
        beforeUnloadHooks.push(hook);                                                                                  // 84
                                                                                                                       // 85
        if (beforeUnloadHooks.length === 1) stopBeforeUnloadListener = startBeforeUnloadListener(getBeforeUnloadPromptMessage);
      }                                                                                                                // 87
    }                                                                                                                  // 88
                                                                                                                       // 89
    // deprecated                                                                                                      // 90
    function unregisterBeforeUnloadHook(hook) {                                                                        // 91
      if (beforeUnloadHooks.length > 0) {                                                                              // 92
        beforeUnloadHooks = beforeUnloadHooks.filter(function (item) {                                                 // 93
          return item !== hook;                                                                                        // 94
        });                                                                                                            // 95
                                                                                                                       // 96
        if (beforeUnloadHooks.length === 0) stopBeforeUnloadListener();                                                // 97
      }                                                                                                                // 98
    }                                                                                                                  // 99
                                                                                                                       // 100
    return _extends({}, history, {                                                                                     // 101
      listenBeforeUnload: listenBeforeUnload,                                                                          // 102
                                                                                                                       // 103
      registerBeforeUnloadHook: _deprecate2['default'](registerBeforeUnloadHook, 'registerBeforeUnloadHook is deprecated; use listenBeforeUnload instead'),
      unregisterBeforeUnloadHook: _deprecate2['default'](unregisterBeforeUnloadHook, 'unregisterBeforeUnloadHook is deprecated; use the callback returned from listenBeforeUnload instead')
    });                                                                                                                // 106
  };                                                                                                                   // 107
}                                                                                                                      // 108
                                                                                                                       // 109
exports['default'] = useBeforeUnload;                                                                                  // 110
module.exports = exports['default'];                                                                                   // 111
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"./DOMUtils":6,"./ExecutionEnvironment":7,"./deprecate":14,"_process":1,"warning":32}],23:[function(require,module,exports){
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }
                                                                                                                       // 10
var _qs = require('qs');                                                                                               // 11
                                                                                                                       // 12
var _qs2 = _interopRequireDefault(_qs);                                                                                // 13
                                                                                                                       // 14
var _runTransitionHook = require('./runTransitionHook');                                                               // 15
                                                                                                                       // 16
var _runTransitionHook2 = _interopRequireDefault(_runTransitionHook);                                                  // 17
                                                                                                                       // 18
var _parsePath = require('./parsePath');                                                                               // 19
                                                                                                                       // 20
var _parsePath2 = _interopRequireDefault(_parsePath);                                                                  // 21
                                                                                                                       // 22
function defaultStringifyQuery(query) {                                                                                // 23
  return _qs2['default'].stringify(query, { arrayFormat: 'brackets' }).replace(/%20/g, '+');                           // 24
}                                                                                                                      // 25
                                                                                                                       // 26
function defaultParseQueryString(queryString) {                                                                        // 27
  return _qs2['default'].parse(queryString.replace(/\+/g, '%20'));                                                     // 28
}                                                                                                                      // 29
                                                                                                                       // 30
/**                                                                                                                    // 31
 * Returns a new createHistory function that may be used to create                                                     // 32
 * history objects that know how to handle URL queries.                                                                // 33
 */                                                                                                                    // 34
function useQueries(createHistory) {                                                                                   // 35
  return function () {                                                                                                 // 36
    var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];                             // 37
    var stringifyQuery = options.stringifyQuery;                                                                       // 38
    var parseQueryString = options.parseQueryString;                                                                   // 39
                                                                                                                       // 40
    var historyOptions = _objectWithoutProperties(options, ['stringifyQuery', 'parseQueryString']);                    // 41
                                                                                                                       // 42
    var history = createHistory(historyOptions);                                                                       // 43
                                                                                                                       // 44
    if (typeof stringifyQuery !== 'function') stringifyQuery = defaultStringifyQuery;                                  // 45
                                                                                                                       // 46
    if (typeof parseQueryString !== 'function') parseQueryString = defaultParseQueryString;                            // 47
                                                                                                                       // 48
    function addQuery(location) {                                                                                      // 49
      if (location.query == null) location.query = parseQueryString(location.search.substring(1));                     // 50
                                                                                                                       // 51
      return location;                                                                                                 // 52
    }                                                                                                                  // 53
                                                                                                                       // 54
    function appendQuery(path, query) {                                                                                // 55
      var queryString = undefined;                                                                                     // 56
      if (!query || (queryString = stringifyQuery(query)) === '') return path;                                         // 57
                                                                                                                       // 58
      if (typeof path === 'string') path = _parsePath2['default'](path);                                               // 59
                                                                                                                       // 60
      var search = path.search + (path.search ? '&' : '?') + queryString;                                              // 61
                                                                                                                       // 62
      return _extends({}, path, {                                                                                      // 63
        search: search                                                                                                 // 64
      });                                                                                                              // 65
    }                                                                                                                  // 66
                                                                                                                       // 67
    // Override all read methods with query-aware versions.                                                            // 68
    function listenBefore(hook) {                                                                                      // 69
      return history.listenBefore(function (location, callback) {                                                      // 70
        _runTransitionHook2['default'](hook, addQuery(location), callback);                                            // 71
      });                                                                                                              // 72
    }                                                                                                                  // 73
                                                                                                                       // 74
    function listen(listener) {                                                                                        // 75
      return history.listen(function (location) {                                                                      // 76
        listener(addQuery(location));                                                                                  // 77
      });                                                                                                              // 78
    }                                                                                                                  // 79
                                                                                                                       // 80
    // Override all write methods with query-aware versions.                                                           // 81
    function pushState(state, path, query) {                                                                           // 82
      return history.pushState(state, appendQuery(path, query));                                                       // 83
    }                                                                                                                  // 84
                                                                                                                       // 85
    function replaceState(state, path, query) {                                                                        // 86
      return history.replaceState(state, appendQuery(path, query));                                                    // 87
    }                                                                                                                  // 88
                                                                                                                       // 89
    function createPath(path, query) {                                                                                 // 90
      return history.createPath(appendQuery(path, query));                                                             // 91
    }                                                                                                                  // 92
                                                                                                                       // 93
    function createHref(path, query) {                                                                                 // 94
      return history.createHref(appendQuery(path, query));                                                             // 95
    }                                                                                                                  // 96
                                                                                                                       // 97
    function createLocation() {                                                                                        // 98
      return addQuery(history.createLocation.apply(history, arguments));                                               // 99
    }                                                                                                                  // 100
                                                                                                                       // 101
    return _extends({}, history, {                                                                                     // 102
      listenBefore: listenBefore,                                                                                      // 103
      listen: listen,                                                                                                  // 104
      pushState: pushState,                                                                                            // 105
      replaceState: replaceState,                                                                                      // 106
      createPath: createPath,                                                                                          // 107
      createHref: createHref,                                                                                          // 108
      createLocation: createLocation                                                                                   // 109
    });                                                                                                                // 110
  };                                                                                                                   // 111
}                                                                                                                      // 112
                                                                                                                       // 113
exports['default'] = useQueries;                                                                                       // 114
module.exports = exports['default'];                                                                                   // 115
},{"./parsePath":19,"./runTransitionHook":20,"qs":28}],24:[function(require,module,exports){                           //
var pSlice = Array.prototype.slice;                                                                                    // 1
var objectKeys = require('./lib/keys.js');                                                                             // 2
var isArguments = require('./lib/is_arguments.js');                                                                    // 3
                                                                                                                       // 4
var deepEqual = module.exports = function (actual, expected, opts) {                                                   // 5
  if (!opts) opts = {};                                                                                                // 6
  // 7.1. All identical values are equivalent, as determined by ===.                                                   // 7
  if (actual === expected) {                                                                                           // 8
    return true;                                                                                                       // 9
                                                                                                                       // 10
  } else if (actual instanceof Date && expected instanceof Date) {                                                     // 11
    return actual.getTime() === expected.getTime();                                                                    // 12
                                                                                                                       // 13
  // 7.3. Other pairs that do not both pass typeof value == 'object',                                                  // 14
  // equivalence is determined by ==.                                                                                  // 15
  } else if (!actual || !expected || typeof actual != 'object' && typeof expected != 'object') {                       // 16
    return opts.strict ? actual === expected : actual == expected;                                                     // 17
                                                                                                                       // 18
  // 7.4. For all other Object pairs, including Array objects, equivalence is                                          // 19
  // determined by having the same number of owned properties (as verified                                             // 20
  // with Object.prototype.hasOwnProperty.call), the same set of keys                                                  // 21
  // (although not necessarily the same order), equivalent values for every                                            // 22
  // corresponding key, and an identical 'prototype' property. Note: this                                              // 23
  // accounts for both named and indexed properties on Arrays.                                                         // 24
  } else {                                                                                                             // 25
    return objEquiv(actual, expected, opts);                                                                           // 26
  }                                                                                                                    // 27
}                                                                                                                      // 28
                                                                                                                       // 29
function isUndefinedOrNull(value) {                                                                                    // 30
  return value === null || value === undefined;                                                                        // 31
}                                                                                                                      // 32
                                                                                                                       // 33
function isBuffer (x) {                                                                                                // 34
  if (!x || typeof x !== 'object' || typeof x.length !== 'number') return false;                                       // 35
  if (typeof x.copy !== 'function' || typeof x.slice !== 'function') {                                                 // 36
    return false;                                                                                                      // 37
  }                                                                                                                    // 38
  if (x.length > 0 && typeof x[0] !== 'number') return false;                                                          // 39
  return true;                                                                                                         // 40
}                                                                                                                      // 41
                                                                                                                       // 42
function objEquiv(a, b, opts) {                                                                                        // 43
  var i, key;                                                                                                          // 44
  if (isUndefinedOrNull(a) || isUndefinedOrNull(b))                                                                    // 45
    return false;                                                                                                      // 46
  // an identical 'prototype' property.                                                                                // 47
  if (a.prototype !== b.prototype) return false;                                                                       // 48
  //~~~I've managed to break Object.keys through screwy arguments passing.                                             // 49
  //   Converting to array solves the problem.                                                                         // 50
  if (isArguments(a)) {                                                                                                // 51
    if (!isArguments(b)) {                                                                                             // 52
      return false;                                                                                                    // 53
    }                                                                                                                  // 54
    a = pSlice.call(a);                                                                                                // 55
    b = pSlice.call(b);                                                                                                // 56
    return deepEqual(a, b, opts);                                                                                      // 57
  }                                                                                                                    // 58
  if (isBuffer(a)) {                                                                                                   // 59
    if (!isBuffer(b)) {                                                                                                // 60
      return false;                                                                                                    // 61
    }                                                                                                                  // 62
    if (a.length !== b.length) return false;                                                                           // 63
    for (i = 0; i < a.length; i++) {                                                                                   // 64
      if (a[i] !== b[i]) return false;                                                                                 // 65
    }                                                                                                                  // 66
    return true;                                                                                                       // 67
  }                                                                                                                    // 68
  try {                                                                                                                // 69
    var ka = objectKeys(a),                                                                                            // 70
        kb = objectKeys(b);                                                                                            // 71
  } catch (e) {//happens when one is a string literal and the other isn't                                              // 72
    return false;                                                                                                      // 73
  }                                                                                                                    // 74
  // having the same number of owned properties (keys incorporates                                                     // 75
  // hasOwnProperty)                                                                                                   // 76
  if (ka.length != kb.length)                                                                                          // 77
    return false;                                                                                                      // 78
  //the same set of keys (although not necessarily the same order),                                                    // 79
  ka.sort();                                                                                                           // 80
  kb.sort();                                                                                                           // 81
  //~~~cheap key test                                                                                                  // 82
  for (i = ka.length - 1; i >= 0; i--) {                                                                               // 83
    if (ka[i] != kb[i])                                                                                                // 84
      return false;                                                                                                    // 85
  }                                                                                                                    // 86
  //equivalent values for every corresponding key, and                                                                 // 87
  //~~~possibly expensive deep test                                                                                    // 88
  for (i = ka.length - 1; i >= 0; i--) {                                                                               // 89
    key = ka[i];                                                                                                       // 90
    if (!deepEqual(a[key], b[key], opts)) return false;                                                                // 91
  }                                                                                                                    // 92
  return typeof a === typeof b;                                                                                        // 93
}                                                                                                                      // 94
                                                                                                                       // 95
},{"./lib/is_arguments.js":25,"./lib/keys.js":26}],25:[function(require,module,exports){                               //
var supportsArgumentsClass = (function(){                                                                              // 1
  return Object.prototype.toString.call(arguments)                                                                     // 2
})() == '[object Arguments]';                                                                                          // 3
                                                                                                                       // 4
exports = module.exports = supportsArgumentsClass ? supported : unsupported;                                           // 5
                                                                                                                       // 6
exports.supported = supported;                                                                                         // 7
function supported(object) {                                                                                           // 8
  return Object.prototype.toString.call(object) == '[object Arguments]';                                               // 9
};                                                                                                                     // 10
                                                                                                                       // 11
exports.unsupported = unsupported;                                                                                     // 12
function unsupported(object){                                                                                          // 13
  return object &&                                                                                                     // 14
    typeof object == 'object' &&                                                                                       // 15
    typeof object.length == 'number' &&                                                                                // 16
    Object.prototype.hasOwnProperty.call(object, 'callee') &&                                                          // 17
    !Object.prototype.propertyIsEnumerable.call(object, 'callee') ||                                                   // 18
    false;                                                                                                             // 19
};                                                                                                                     // 20
                                                                                                                       // 21
},{}],26:[function(require,module,exports){                                                                            //
exports = module.exports = typeof Object.keys === 'function'                                                           // 1
  ? Object.keys : shim;                                                                                                // 2
                                                                                                                       // 3
exports.shim = shim;                                                                                                   // 4
function shim (obj) {                                                                                                  // 5
  var keys = [];                                                                                                       // 6
  for (var key in obj) keys.push(key);                                                                                 // 7
  return keys;                                                                                                         // 8
}                                                                                                                      // 9
                                                                                                                       // 10
},{}],27:[function(require,module,exports){                                                                            //
(function (process){                                                                                                   //
/**                                                                                                                    // 1
 * Copyright 2013-2015, Facebook, Inc.                                                                                 // 2
 * All rights reserved.                                                                                                // 3
 *                                                                                                                     // 4
 * This source code is licensed under the BSD-style license found in the                                               // 5
 * LICENSE file in the root directory of this source tree. An additional grant                                         // 6
 * of patent rights can be found in the PATENTS file in the same directory.                                            // 7
 */                                                                                                                    // 8
                                                                                                                       // 9
'use strict';                                                                                                          // 10
                                                                                                                       // 11
/**                                                                                                                    // 12
 * Use invariant() to assert state which your program assumes to be true.                                              // 13
 *                                                                                                                     // 14
 * Provide sprintf-style format (only %s is supported) and arguments                                                   // 15
 * to provide information about what broke and what you were                                                           // 16
 * expecting.                                                                                                          // 17
 *                                                                                                                     // 18
 * The invariant message will be stripped in production, but the invariant                                             // 19
 * will remain to ensure logic does not differ in production.                                                          // 20
 */                                                                                                                    // 21
                                                                                                                       // 22
var invariant = function(condition, format, a, b, c, d, e, f) {                                                        // 23
  if (process.env.NODE_ENV !== 'production') {                                                                         // 24
    if (format === undefined) {                                                                                        // 25
      throw new Error('invariant requires an error message argument');                                                 // 26
    }                                                                                                                  // 27
  }                                                                                                                    // 28
                                                                                                                       // 29
  if (!condition) {                                                                                                    // 30
    var error;                                                                                                         // 31
    if (format === undefined) {                                                                                        // 32
      error = new Error(                                                                                               // 33
        'Minified exception occurred; use the non-minified dev environment ' +                                         // 34
        'for the full error message and additional helpful warnings.'                                                  // 35
      );                                                                                                               // 36
    } else {                                                                                                           // 37
      var args = [a, b, c, d, e, f];                                                                                   // 38
      var argIndex = 0;                                                                                                // 39
      error = new Error(                                                                                               // 40
        format.replace(/%s/g, function() { return args[argIndex++]; })                                                 // 41
      );                                                                                                               // 42
      error.name = 'Invariant Violation';                                                                              // 43
    }                                                                                                                  // 44
                                                                                                                       // 45
    error.framesToPop = 1; // we don't care about invariant's own frame                                                // 46
    throw error;                                                                                                       // 47
  }                                                                                                                    // 48
};                                                                                                                     // 49
                                                                                                                       // 50
module.exports = invariant;                                                                                            // 51
                                                                                                                       // 52
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"_process":1}],28:[function(require,module,exports){                                                                //
// Load modules                                                                                                        // 1
                                                                                                                       // 2
var Stringify = require('./stringify');                                                                                // 3
var Parse = require('./parse');                                                                                        // 4
                                                                                                                       // 5
                                                                                                                       // 6
// Declare internals                                                                                                   // 7
                                                                                                                       // 8
var internals = {};                                                                                                    // 9
                                                                                                                       // 10
                                                                                                                       // 11
module.exports = {                                                                                                     // 12
    stringify: Stringify,                                                                                              // 13
    parse: Parse                                                                                                       // 14
};                                                                                                                     // 15
                                                                                                                       // 16
},{"./parse":29,"./stringify":30}],29:[function(require,module,exports){                                               //
// Load modules                                                                                                        // 1
                                                                                                                       // 2
var Utils = require('./utils');                                                                                        // 3
                                                                                                                       // 4
                                                                                                                       // 5
// Declare internals                                                                                                   // 6
                                                                                                                       // 7
var internals = {                                                                                                      // 8
    delimiter: '&',                                                                                                    // 9
    depth: 5,                                                                                                          // 10
    arrayLimit: 20,                                                                                                    // 11
    parameterLimit: 1000,                                                                                              // 12
    strictNullHandling: false,                                                                                         // 13
    plainObjects: false,                                                                                               // 14
    allowPrototypes: false                                                                                             // 15
};                                                                                                                     // 16
                                                                                                                       // 17
                                                                                                                       // 18
internals.parseValues = function (str, options) {                                                                      // 19
                                                                                                                       // 20
    var obj = {};                                                                                                      // 21
    var parts = str.split(options.delimiter, options.parameterLimit === Infinity ? undefined : options.parameterLimit);
                                                                                                                       // 23
    for (var i = 0, il = parts.length; i < il; ++i) {                                                                  // 24
        var part = parts[i];                                                                                           // 25
        var pos = part.indexOf(']=') === -1 ? part.indexOf('=') : part.indexOf(']=') + 1;                              // 26
                                                                                                                       // 27
        if (pos === -1) {                                                                                              // 28
            obj[Utils.decode(part)] = '';                                                                              // 29
                                                                                                                       // 30
            if (options.strictNullHandling) {                                                                          // 31
                obj[Utils.decode(part)] = null;                                                                        // 32
            }                                                                                                          // 33
        }                                                                                                              // 34
        else {                                                                                                         // 35
            var key = Utils.decode(part.slice(0, pos));                                                                // 36
            var val = Utils.decode(part.slice(pos + 1));                                                               // 37
                                                                                                                       // 38
            if (!Object.prototype.hasOwnProperty.call(obj, key)) {                                                     // 39
                obj[key] = val;                                                                                        // 40
            }                                                                                                          // 41
            else {                                                                                                     // 42
                obj[key] = [].concat(obj[key]).concat(val);                                                            // 43
            }                                                                                                          // 44
        }                                                                                                              // 45
    }                                                                                                                  // 46
                                                                                                                       // 47
    return obj;                                                                                                        // 48
};                                                                                                                     // 49
                                                                                                                       // 50
                                                                                                                       // 51
internals.parseObject = function (chain, val, options) {                                                               // 52
                                                                                                                       // 53
    if (!chain.length) {                                                                                               // 54
        return val;                                                                                                    // 55
    }                                                                                                                  // 56
                                                                                                                       // 57
    var root = chain.shift();                                                                                          // 58
                                                                                                                       // 59
    var obj;                                                                                                           // 60
    if (root === '[]') {                                                                                               // 61
        obj = [];                                                                                                      // 62
        obj = obj.concat(internals.parseObject(chain, val, options));                                                  // 63
    }                                                                                                                  // 64
    else {                                                                                                             // 65
        obj = options.plainObjects ? Object.create(null) : {};                                                         // 66
        var cleanRoot = root[0] === '[' && root[root.length - 1] === ']' ? root.slice(1, root.length - 1) : root;      // 67
        var index = parseInt(cleanRoot, 10);                                                                           // 68
        var indexString = '' + index;                                                                                  // 69
        if (!isNaN(index) &&                                                                                           // 70
            root !== cleanRoot &&                                                                                      // 71
            indexString === cleanRoot &&                                                                               // 72
            index >= 0 &&                                                                                              // 73
            (options.parseArrays &&                                                                                    // 74
             index <= options.arrayLimit)) {                                                                           // 75
                                                                                                                       // 76
            obj = [];                                                                                                  // 77
            obj[index] = internals.parseObject(chain, val, options);                                                   // 78
        }                                                                                                              // 79
        else {                                                                                                         // 80
            obj[cleanRoot] = internals.parseObject(chain, val, options);                                               // 81
        }                                                                                                              // 82
    }                                                                                                                  // 83
                                                                                                                       // 84
    return obj;                                                                                                        // 85
};                                                                                                                     // 86
                                                                                                                       // 87
                                                                                                                       // 88
internals.parseKeys = function (key, val, options) {                                                                   // 89
                                                                                                                       // 90
    if (!key) {                                                                                                        // 91
        return;                                                                                                        // 92
    }                                                                                                                  // 93
                                                                                                                       // 94
    // Transform dot notation to bracket notation                                                                      // 95
                                                                                                                       // 96
    if (options.allowDots) {                                                                                           // 97
        key = key.replace(/\.([^\.\[]+)/g, '[$1]');                                                                    // 98
    }                                                                                                                  // 99
                                                                                                                       // 100
    // The regex chunks                                                                                                // 101
                                                                                                                       // 102
    var parent = /^([^\[\]]*)/;                                                                                        // 103
    var child = /(\[[^\[\]]*\])/g;                                                                                     // 104
                                                                                                                       // 105
    // Get the parent                                                                                                  // 106
                                                                                                                       // 107
    var segment = parent.exec(key);                                                                                    // 108
                                                                                                                       // 109
    // Stash the parent if it exists                                                                                   // 110
                                                                                                                       // 111
    var keys = [];                                                                                                     // 112
    if (segment[1]) {                                                                                                  // 113
        // If we aren't using plain objects, optionally prefix keys                                                    // 114
        // that would overwrite object prototype properties                                                            // 115
        if (!options.plainObjects &&                                                                                   // 116
            Object.prototype.hasOwnProperty(segment[1])) {                                                             // 117
                                                                                                                       // 118
            if (!options.allowPrototypes) {                                                                            // 119
                return;                                                                                                // 120
            }                                                                                                          // 121
        }                                                                                                              // 122
                                                                                                                       // 123
        keys.push(segment[1]);                                                                                         // 124
    }                                                                                                                  // 125
                                                                                                                       // 126
    // Loop through children appending to the array until we hit depth                                                 // 127
                                                                                                                       // 128
    var i = 0;                                                                                                         // 129
    while ((segment = child.exec(key)) !== null && i < options.depth) {                                                // 130
                                                                                                                       // 131
        ++i;                                                                                                           // 132
        if (!options.plainObjects &&                                                                                   // 133
            Object.prototype.hasOwnProperty(segment[1].replace(/\[|\]/g, ''))) {                                       // 134
                                                                                                                       // 135
            if (!options.allowPrototypes) {                                                                            // 136
                continue;                                                                                              // 137
            }                                                                                                          // 138
        }                                                                                                              // 139
        keys.push(segment[1]);                                                                                         // 140
    }                                                                                                                  // 141
                                                                                                                       // 142
    // If there's a remainder, just add whatever is left                                                               // 143
                                                                                                                       // 144
    if (segment) {                                                                                                     // 145
        keys.push('[' + key.slice(segment.index) + ']');                                                               // 146
    }                                                                                                                  // 147
                                                                                                                       // 148
    return internals.parseObject(keys, val, options);                                                                  // 149
};                                                                                                                     // 150
                                                                                                                       // 151
                                                                                                                       // 152
module.exports = function (str, options) {                                                                             // 153
                                                                                                                       // 154
    options = options || {};                                                                                           // 155
    options.delimiter = typeof options.delimiter === 'string' || Utils.isRegExp(options.delimiter) ? options.delimiter : internals.delimiter;
    options.depth = typeof options.depth === 'number' ? options.depth : internals.depth;                               // 157
    options.arrayLimit = typeof options.arrayLimit === 'number' ? options.arrayLimit : internals.arrayLimit;           // 158
    options.parseArrays = options.parseArrays !== false;                                                               // 159
    options.allowDots = options.allowDots !== false;                                                                   // 160
    options.plainObjects = typeof options.plainObjects === 'boolean' ? options.plainObjects : internals.plainObjects;  // 161
    options.allowPrototypes = typeof options.allowPrototypes === 'boolean' ? options.allowPrototypes : internals.allowPrototypes;
    options.parameterLimit = typeof options.parameterLimit === 'number' ? options.parameterLimit : internals.parameterLimit;
    options.strictNullHandling = typeof options.strictNullHandling === 'boolean' ? options.strictNullHandling : internals.strictNullHandling;
                                                                                                                       // 165
    if (str === '' ||                                                                                                  // 166
        str === null ||                                                                                                // 167
        typeof str === 'undefined') {                                                                                  // 168
                                                                                                                       // 169
        return options.plainObjects ? Object.create(null) : {};                                                        // 170
    }                                                                                                                  // 171
                                                                                                                       // 172
    var tempObj = typeof str === 'string' ? internals.parseValues(str, options) : str;                                 // 173
    var obj = options.plainObjects ? Object.create(null) : {};                                                         // 174
                                                                                                                       // 175
    // Iterate over the keys and setup the new object                                                                  // 176
                                                                                                                       // 177
    var keys = Object.keys(tempObj);                                                                                   // 178
    for (var i = 0, il = keys.length; i < il; ++i) {                                                                   // 179
        var key = keys[i];                                                                                             // 180
        var newObj = internals.parseKeys(key, tempObj[key], options);                                                  // 181
        obj = Utils.merge(obj, newObj, options);                                                                       // 182
    }                                                                                                                  // 183
                                                                                                                       // 184
    return Utils.compact(obj);                                                                                         // 185
};                                                                                                                     // 186
                                                                                                                       // 187
},{"./utils":31}],30:[function(require,module,exports){                                                                //
// Load modules                                                                                                        // 1
                                                                                                                       // 2
var Utils = require('./utils');                                                                                        // 3
                                                                                                                       // 4
                                                                                                                       // 5
// Declare internals                                                                                                   // 6
                                                                                                                       // 7
var internals = {                                                                                                      // 8
    delimiter: '&',                                                                                                    // 9
    arrayPrefixGenerators: {                                                                                           // 10
        brackets: function (prefix, key) {                                                                             // 11
                                                                                                                       // 12
            return prefix + '[]';                                                                                      // 13
        },                                                                                                             // 14
        indices: function (prefix, key) {                                                                              // 15
                                                                                                                       // 16
            return prefix + '[' + key + ']';                                                                           // 17
        },                                                                                                             // 18
        repeat: function (prefix, key) {                                                                               // 19
                                                                                                                       // 20
            return prefix;                                                                                             // 21
        }                                                                                                              // 22
    },                                                                                                                 // 23
    strictNullHandling: false                                                                                          // 24
};                                                                                                                     // 25
                                                                                                                       // 26
                                                                                                                       // 27
internals.stringify = function (obj, prefix, generateArrayPrefix, strictNullHandling, filter) {                        // 28
                                                                                                                       // 29
    if (typeof filter === 'function') {                                                                                // 30
        obj = filter(prefix, obj);                                                                                     // 31
    }                                                                                                                  // 32
    else if (Utils.isBuffer(obj)) {                                                                                    // 33
        obj = obj.toString();                                                                                          // 34
    }                                                                                                                  // 35
    else if (obj instanceof Date) {                                                                                    // 36
        obj = obj.toISOString();                                                                                       // 37
    }                                                                                                                  // 38
    else if (obj === null) {                                                                                           // 39
        if (strictNullHandling) {                                                                                      // 40
            return Utils.encode(prefix);                                                                               // 41
        }                                                                                                              // 42
                                                                                                                       // 43
        obj = '';                                                                                                      // 44
    }                                                                                                                  // 45
                                                                                                                       // 46
    if (typeof obj === 'string' ||                                                                                     // 47
        typeof obj === 'number' ||                                                                                     // 48
        typeof obj === 'boolean') {                                                                                    // 49
                                                                                                                       // 50
        return [Utils.encode(prefix) + '=' + Utils.encode(obj)];                                                       // 51
    }                                                                                                                  // 52
                                                                                                                       // 53
    var values = [];                                                                                                   // 54
                                                                                                                       // 55
    if (typeof obj === 'undefined') {                                                                                  // 56
        return values;                                                                                                 // 57
    }                                                                                                                  // 58
                                                                                                                       // 59
    var objKeys = Array.isArray(filter) ? filter : Object.keys(obj);                                                   // 60
    for (var i = 0, il = objKeys.length; i < il; ++i) {                                                                // 61
        var key = objKeys[i];                                                                                          // 62
                                                                                                                       // 63
        if (Array.isArray(obj)) {                                                                                      // 64
            values = values.concat(internals.stringify(obj[key], generateArrayPrefix(prefix, key), generateArrayPrefix, strictNullHandling, filter));
        }                                                                                                              // 66
        else {                                                                                                         // 67
            values = values.concat(internals.stringify(obj[key], prefix + '[' + key + ']', generateArrayPrefix, strictNullHandling, filter));
        }                                                                                                              // 69
    }                                                                                                                  // 70
                                                                                                                       // 71
    return values;                                                                                                     // 72
};                                                                                                                     // 73
                                                                                                                       // 74
                                                                                                                       // 75
module.exports = function (obj, options) {                                                                             // 76
                                                                                                                       // 77
    options = options || {};                                                                                           // 78
    var delimiter = typeof options.delimiter === 'undefined' ? internals.delimiter : options.delimiter;                // 79
    var strictNullHandling = typeof options.strictNullHandling === 'boolean' ? options.strictNullHandling : internals.strictNullHandling;
    var objKeys;                                                                                                       // 81
    var filter;                                                                                                        // 82
    if (typeof options.filter === 'function') {                                                                        // 83
        filter = options.filter;                                                                                       // 84
        obj = filter('', obj);                                                                                         // 85
    }                                                                                                                  // 86
    else if (Array.isArray(options.filter)) {                                                                          // 87
        objKeys = filter = options.filter;                                                                             // 88
    }                                                                                                                  // 89
                                                                                                                       // 90
    var keys = [];                                                                                                     // 91
                                                                                                                       // 92
    if (typeof obj !== 'object' ||                                                                                     // 93
        obj === null) {                                                                                                // 94
                                                                                                                       // 95
        return '';                                                                                                     // 96
    }                                                                                                                  // 97
                                                                                                                       // 98
    var arrayFormat;                                                                                                   // 99
    if (options.arrayFormat in internals.arrayPrefixGenerators) {                                                      // 100
        arrayFormat = options.arrayFormat;                                                                             // 101
    }                                                                                                                  // 102
    else if ('indices' in options) {                                                                                   // 103
        arrayFormat = options.indices ? 'indices' : 'repeat';                                                          // 104
    }                                                                                                                  // 105
    else {                                                                                                             // 106
        arrayFormat = 'indices';                                                                                       // 107
    }                                                                                                                  // 108
                                                                                                                       // 109
    var generateArrayPrefix = internals.arrayPrefixGenerators[arrayFormat];                                            // 110
                                                                                                                       // 111
    if (!objKeys) {                                                                                                    // 112
        objKeys = Object.keys(obj);                                                                                    // 113
    }                                                                                                                  // 114
    for (var i = 0, il = objKeys.length; i < il; ++i) {                                                                // 115
        var key = objKeys[i];                                                                                          // 116
        keys = keys.concat(internals.stringify(obj[key], key, generateArrayPrefix, strictNullHandling, filter));       // 117
    }                                                                                                                  // 118
                                                                                                                       // 119
    return keys.join(delimiter);                                                                                       // 120
};                                                                                                                     // 121
                                                                                                                       // 122
},{"./utils":31}],31:[function(require,module,exports){                                                                //
// Load modules                                                                                                        // 1
                                                                                                                       // 2
                                                                                                                       // 3
// Declare internals                                                                                                   // 4
                                                                                                                       // 5
var internals = {};                                                                                                    // 6
internals.hexTable = new Array(256);                                                                                   // 7
for (var h = 0; h < 256; ++h) {                                                                                        // 8
    internals.hexTable[h] = '%' + ((h < 16 ? '0' : '') + h.toString(16)).toUpperCase();                                // 9
}                                                                                                                      // 10
                                                                                                                       // 11
                                                                                                                       // 12
exports.arrayToObject = function (source, options) {                                                                   // 13
                                                                                                                       // 14
    var obj = options.plainObjects ? Object.create(null) : {};                                                         // 15
    for (var i = 0, il = source.length; i < il; ++i) {                                                                 // 16
        if (typeof source[i] !== 'undefined') {                                                                        // 17
                                                                                                                       // 18
            obj[i] = source[i];                                                                                        // 19
        }                                                                                                              // 20
    }                                                                                                                  // 21
                                                                                                                       // 22
    return obj;                                                                                                        // 23
};                                                                                                                     // 24
                                                                                                                       // 25
                                                                                                                       // 26
exports.merge = function (target, source, options) {                                                                   // 27
                                                                                                                       // 28
    if (!source) {                                                                                                     // 29
        return target;                                                                                                 // 30
    }                                                                                                                  // 31
                                                                                                                       // 32
    if (typeof source !== 'object') {                                                                                  // 33
        if (Array.isArray(target)) {                                                                                   // 34
            target.push(source);                                                                                       // 35
        }                                                                                                              // 36
        else if (typeof target === 'object') {                                                                         // 37
            target[source] = true;                                                                                     // 38
        }                                                                                                              // 39
        else {                                                                                                         // 40
            target = [target, source];                                                                                 // 41
        }                                                                                                              // 42
                                                                                                                       // 43
        return target;                                                                                                 // 44
    }                                                                                                                  // 45
                                                                                                                       // 46
    if (typeof target !== 'object') {                                                                                  // 47
        target = [target].concat(source);                                                                              // 48
        return target;                                                                                                 // 49
    }                                                                                                                  // 50
                                                                                                                       // 51
    if (Array.isArray(target) &&                                                                                       // 52
        !Array.isArray(source)) {                                                                                      // 53
                                                                                                                       // 54
        target = exports.arrayToObject(target, options);                                                               // 55
    }                                                                                                                  // 56
                                                                                                                       // 57
    var keys = Object.keys(source);                                                                                    // 58
    for (var k = 0, kl = keys.length; k < kl; ++k) {                                                                   // 59
        var key = keys[k];                                                                                             // 60
        var value = source[key];                                                                                       // 61
                                                                                                                       // 62
        if (!Object.prototype.hasOwnProperty.call(target, key)) {                                                      // 63
            target[key] = value;                                                                                       // 64
        }                                                                                                              // 65
        else {                                                                                                         // 66
            target[key] = exports.merge(target[key], value, options);                                                  // 67
        }                                                                                                              // 68
    }                                                                                                                  // 69
                                                                                                                       // 70
    return target;                                                                                                     // 71
};                                                                                                                     // 72
                                                                                                                       // 73
                                                                                                                       // 74
exports.decode = function (str) {                                                                                      // 75
                                                                                                                       // 76
    try {                                                                                                              // 77
        return decodeURIComponent(str.replace(/\+/g, ' '));                                                            // 78
    } catch (e) {                                                                                                      // 79
        return str;                                                                                                    // 80
    }                                                                                                                  // 81
};                                                                                                                     // 82
                                                                                                                       // 83
exports.encode = function (str) {                                                                                      // 84
                                                                                                                       // 85
    // This code was originally written by Brian White (mscdex) for the io.js core querystring library.                // 86
    // It has been adapted here for stricter adherence to RFC 3986                                                     // 87
    if (str.length === 0) {                                                                                            // 88
        return str;                                                                                                    // 89
    }                                                                                                                  // 90
                                                                                                                       // 91
    if (typeof str !== 'string') {                                                                                     // 92
        str = '' + str;                                                                                                // 93
    }                                                                                                                  // 94
                                                                                                                       // 95
    var out = '';                                                                                                      // 96
    for (var i = 0, il = str.length; i < il; ++i) {                                                                    // 97
        var c = str.charCodeAt(i);                                                                                     // 98
                                                                                                                       // 99
        if (c === 0x2D || // -                                                                                         // 100
            c === 0x2E || // .                                                                                         // 101
            c === 0x5F || // _                                                                                         // 102
            c === 0x7E || // ~                                                                                         // 103
            (c >= 0x30 && c <= 0x39) || // 0-9                                                                         // 104
            (c >= 0x41 && c <= 0x5A) || // a-z                                                                         // 105
            (c >= 0x61 && c <= 0x7A)) { // A-Z                                                                         // 106
                                                                                                                       // 107
            out += str[i];                                                                                             // 108
            continue;                                                                                                  // 109
        }                                                                                                              // 110
                                                                                                                       // 111
        if (c < 0x80) {                                                                                                // 112
            out += internals.hexTable[c];                                                                              // 113
            continue;                                                                                                  // 114
        }                                                                                                              // 115
                                                                                                                       // 116
        if (c < 0x800) {                                                                                               // 117
            out += internals.hexTable[0xC0 | (c >> 6)] + internals.hexTable[0x80 | (c & 0x3F)];                        // 118
            continue;                                                                                                  // 119
        }                                                                                                              // 120
                                                                                                                       // 121
        if (c < 0xD800 || c >= 0xE000) {                                                                               // 122
            out += internals.hexTable[0xE0 | (c >> 12)] + internals.hexTable[0x80 | ((c >> 6) & 0x3F)] + internals.hexTable[0x80 | (c & 0x3F)];
            continue;                                                                                                  // 124
        }                                                                                                              // 125
                                                                                                                       // 126
        ++i;                                                                                                           // 127
        c = 0x10000 + (((c & 0x3FF) << 10) | (str.charCodeAt(i) & 0x3FF));                                             // 128
        out += internals.hexTable[0xF0 | (c >> 18)] + internals.hexTable[0x80 | ((c >> 12) & 0x3F)] + internals.hexTable[0x80 | ((c >> 6) & 0x3F)] + internals.hexTable[0x80 | (c & 0x3F)];
    }                                                                                                                  // 130
                                                                                                                       // 131
    return out;                                                                                                        // 132
};                                                                                                                     // 133
                                                                                                                       // 134
exports.compact = function (obj, refs) {                                                                               // 135
                                                                                                                       // 136
    if (typeof obj !== 'object' ||                                                                                     // 137
        obj === null) {                                                                                                // 138
                                                                                                                       // 139
        return obj;                                                                                                    // 140
    }                                                                                                                  // 141
                                                                                                                       // 142
    refs = refs || [];                                                                                                 // 143
    var lookup = refs.indexOf(obj);                                                                                    // 144
    if (lookup !== -1) {                                                                                               // 145
        return refs[lookup];                                                                                           // 146
    }                                                                                                                  // 147
                                                                                                                       // 148
    refs.push(obj);                                                                                                    // 149
                                                                                                                       // 150
    if (Array.isArray(obj)) {                                                                                          // 151
        var compacted = [];                                                                                            // 152
                                                                                                                       // 153
        for (var i = 0, il = obj.length; i < il; ++i) {                                                                // 154
            if (typeof obj[i] !== 'undefined') {                                                                       // 155
                compacted.push(obj[i]);                                                                                // 156
            }                                                                                                          // 157
        }                                                                                                              // 158
                                                                                                                       // 159
        return compacted;                                                                                              // 160
    }                                                                                                                  // 161
                                                                                                                       // 162
    var keys = Object.keys(obj);                                                                                       // 163
    for (i = 0, il = keys.length; i < il; ++i) {                                                                       // 164
        var key = keys[i];                                                                                             // 165
        obj[key] = exports.compact(obj[key], refs);                                                                    // 166
    }                                                                                                                  // 167
                                                                                                                       // 168
    return obj;                                                                                                        // 169
};                                                                                                                     // 170
                                                                                                                       // 171
                                                                                                                       // 172
exports.isRegExp = function (obj) {                                                                                    // 173
                                                                                                                       // 174
    return Object.prototype.toString.call(obj) === '[object RegExp]';                                                  // 175
};                                                                                                                     // 176
                                                                                                                       // 177
                                                                                                                       // 178
exports.isBuffer = function (obj) {                                                                                    // 179
                                                                                                                       // 180
    if (obj === null ||                                                                                                // 181
        typeof obj === 'undefined') {                                                                                  // 182
                                                                                                                       // 183
        return false;                                                                                                  // 184
    }                                                                                                                  // 185
                                                                                                                       // 186
    return !!(obj.constructor &&                                                                                       // 187
              obj.constructor.isBuffer &&                                                                              // 188
              obj.constructor.isBuffer(obj));                                                                          // 189
};                                                                                                                     // 190
                                                                                                                       // 191
},{}],32:[function(require,module,exports){                                                                            //
(function (process){                                                                                                   //
/**                                                                                                                    // 1
 * Copyright 2014-2015, Facebook, Inc.                                                                                 // 2
 * All rights reserved.                                                                                                // 3
 *                                                                                                                     // 4
 * This source code is licensed under the BSD-style license found in the                                               // 5
 * LICENSE file in the root directory of this source tree. An additional grant                                         // 6
 * of patent rights can be found in the PATENTS file in the same directory.                                            // 7
 */                                                                                                                    // 8
                                                                                                                       // 9
'use strict';                                                                                                          // 10
                                                                                                                       // 11
/**                                                                                                                    // 12
 * Similar to invariant but only logs a warning if the condition is not met.                                           // 13
 * This can be used to log issues in development environments in critical                                              // 14
 * paths. Removing the logging code for production environments will keep the                                          // 15
 * same logic and follow the same code paths.                                                                          // 16
 */                                                                                                                    // 17
                                                                                                                       // 18
var warning = function() {};                                                                                           // 19
                                                                                                                       // 20
if (process.env.NODE_ENV !== 'production') {                                                                           // 21
  warning = function(condition, format, args) {                                                                        // 22
    var len = arguments.length;                                                                                        // 23
    args = new Array(len > 2 ? len - 2 : 0);                                                                           // 24
    for (var key = 2; key < len; key++) {                                                                              // 25
      args[key - 2] = arguments[key];                                                                                  // 26
    }                                                                                                                  // 27
    if (format === undefined) {                                                                                        // 28
      throw new Error(                                                                                                 // 29
        '`warning(condition, format, ...args)` requires a warning ' +                                                  // 30
        'message argument'                                                                                             // 31
      );                                                                                                               // 32
    }                                                                                                                  // 33
                                                                                                                       // 34
    if (format.length < 10 || (/^[s\W]*$/).test(format)) {                                                             // 35
      throw new Error(                                                                                                 // 36
        'The warning format should be able to uniquely identify this ' +                                               // 37
        'warning. Please, use a more descriptive format than: ' + format                                               // 38
      );                                                                                                               // 39
    }                                                                                                                  // 40
                                                                                                                       // 41
    if (!condition) {                                                                                                  // 42
      var argIndex = 0;                                                                                                // 43
      var message = 'Warning: ' +                                                                                      // 44
        format.replace(/%s/g, function() {                                                                             // 45
          return args[argIndex++];                                                                                     // 46
        });                                                                                                            // 47
      if (typeof console !== 'undefined') {                                                                            // 48
        console.error(message);                                                                                        // 49
      }                                                                                                                // 50
      try {                                                                                                            // 51
        // This error was thrown as a convenience so that you can use this stack                                       // 52
        // to find the callsite that caused this warning to fire.                                                      // 53
        throw new Error(message);                                                                                      // 54
      } catch(x) {}                                                                                                    // 55
    }                                                                                                                  // 56
  };                                                                                                                   // 57
}                                                                                                                      // 58
                                                                                                                       // 59
module.exports = warning;                                                                                              // 60
                                                                                                                       // 61
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"_process":1}],33:[function(require,module,exports){                                                                //
"use strict";                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
exports.loopAsync = loopAsync;                                                                                         // 4
exports.mapAsync = mapAsync;                                                                                           // 5
                                                                                                                       // 6
function loopAsync(turns, work, callback) {                                                                            // 7
  var currentTurn = 0,                                                                                                 // 8
      isDone = false;                                                                                                  // 9
                                                                                                                       // 10
  function done() {                                                                                                    // 11
    isDone = true;                                                                                                     // 12
    callback.apply(this, arguments);                                                                                   // 13
  }                                                                                                                    // 14
                                                                                                                       // 15
  function next() {                                                                                                    // 16
    if (isDone) return;                                                                                                // 17
                                                                                                                       // 18
    if (currentTurn < turns) {                                                                                         // 19
      work.call(this, currentTurn++, next, done);                                                                      // 20
    } else {                                                                                                           // 21
      done.apply(this, arguments);                                                                                     // 22
    }                                                                                                                  // 23
  }                                                                                                                    // 24
                                                                                                                       // 25
  next();                                                                                                              // 26
}                                                                                                                      // 27
                                                                                                                       // 28
function mapAsync(array, work, callback) {                                                                             // 29
  var length = array.length;                                                                                           // 30
  var values = [];                                                                                                     // 31
                                                                                                                       // 32
  if (length === 0) return callback(null, values);                                                                     // 33
                                                                                                                       // 34
  var isDone = false,                                                                                                  // 35
      doneCount = 0;                                                                                                   // 36
                                                                                                                       // 37
  function done(index, error, value) {                                                                                 // 38
    if (isDone) return;                                                                                                // 39
                                                                                                                       // 40
    if (error) {                                                                                                       // 41
      isDone = true;                                                                                                   // 42
      callback(error);                                                                                                 // 43
    } else {                                                                                                           // 44
      values[index] = value;                                                                                           // 45
                                                                                                                       // 46
      isDone = ++doneCount === length;                                                                                 // 47
                                                                                                                       // 48
      if (isDone) callback(null, values);                                                                              // 49
    }                                                                                                                  // 50
  }                                                                                                                    // 51
                                                                                                                       // 52
  array.forEach(function (item, index) {                                                                               // 53
    work(item, index, function (error, value) {                                                                        // 54
      done(index, error, value);                                                                                       // 55
    });                                                                                                                // 56
  });                                                                                                                  // 57
}                                                                                                                      // 58
},{}],34:[function(require,module,exports){                                                                            //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _PropTypes = require('./PropTypes');                                                                               // 5
                                                                                                                       // 6
/**                                                                                                                    // 7
 * A mixin that adds the "history" instance variable to components.                                                    // 8
 */                                                                                                                    // 9
var History = {                                                                                                        // 10
                                                                                                                       // 11
  contextTypes: {                                                                                                      // 12
    history: _PropTypes.history                                                                                        // 13
  },                                                                                                                   // 14
                                                                                                                       // 15
  componentWillMount: function componentWillMount() {                                                                  // 16
    this.history = this.context.history;                                                                               // 17
  }                                                                                                                    // 18
                                                                                                                       // 19
};                                                                                                                     // 20
                                                                                                                       // 21
exports['default'] = History;                                                                                          // 22
module.exports = exports['default'];                                                                                   // 23
},{"./PropTypes":41}],35:[function(require,module,exports){                                                            //
(function (global){                                                                                                    //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }
                                                                                                                       // 10
function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
                                                                                                                       // 12
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 14
var _react2 = _interopRequireDefault(_react);                                                                          // 15
                                                                                                                       // 16
var _Link = require('./Link');                                                                                         // 17
                                                                                                                       // 18
var _Link2 = _interopRequireDefault(_Link);                                                                            // 19
                                                                                                                       // 20
/**                                                                                                                    // 21
 * An <IndexLink> is used to link to an <IndexRoute>.                                                                  // 22
 */                                                                                                                    // 23
                                                                                                                       // 24
var IndexLink = (function (_Component) {                                                                               // 25
  _inherits(IndexLink, _Component);                                                                                    // 26
                                                                                                                       // 27
  function IndexLink() {                                                                                               // 28
    _classCallCheck(this, IndexLink);                                                                                  // 29
                                                                                                                       // 30
    _Component.apply(this, arguments);                                                                                 // 31
  }                                                                                                                    // 32
                                                                                                                       // 33
  IndexLink.prototype.render = function render() {                                                                     // 34
    return _react2['default'].createElement(_Link2['default'], _extends({}, this.props, { onlyActiveOnIndex: true }));
  };                                                                                                                   // 36
                                                                                                                       // 37
  return IndexLink;                                                                                                    // 38
})(_react.Component);                                                                                                  // 39
                                                                                                                       // 40
exports['default'] = IndexLink;                                                                                        // 41
module.exports = exports['default'];                                                                                   // 42
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{"./Link":39}],36:[function(require,module,exports){                                                                 //
(function (process,global){                                                                                            //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }
                                                                                                                       // 10
function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
                                                                                                                       // 12
var _warning = require('warning');                                                                                     // 13
                                                                                                                       // 14
var _warning2 = _interopRequireDefault(_warning);                                                                      // 15
                                                                                                                       // 16
var _invariant = require('invariant');                                                                                 // 17
                                                                                                                       // 18
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 19
                                                                                                                       // 20
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 22
var _react2 = _interopRequireDefault(_react);                                                                          // 23
                                                                                                                       // 24
var _Redirect = require('./Redirect');                                                                                 // 25
                                                                                                                       // 26
var _Redirect2 = _interopRequireDefault(_Redirect);                                                                    // 27
                                                                                                                       // 28
var _PropTypes = require('./PropTypes');                                                                               // 29
                                                                                                                       // 30
var _React$PropTypes = _react2['default'].PropTypes;                                                                   // 31
var string = _React$PropTypes.string;                                                                                  // 32
var object = _React$PropTypes.object;                                                                                  // 33
                                                                                                                       // 34
/**                                                                                                                    // 35
 * An <IndexRedirect> is used to redirect from an indexRoute.                                                          // 36
 */                                                                                                                    // 37
                                                                                                                       // 38
var IndexRedirect = (function (_Component) {                                                                           // 39
  _inherits(IndexRedirect, _Component);                                                                                // 40
                                                                                                                       // 41
  function IndexRedirect() {                                                                                           // 42
    _classCallCheck(this, IndexRedirect);                                                                              // 43
                                                                                                                       // 44
    _Component.apply(this, arguments);                                                                                 // 45
  }                                                                                                                    // 46
                                                                                                                       // 47
  IndexRedirect.createRouteFromReactElement = function createRouteFromReactElement(element, parentRoute) {             // 48
    /* istanbul ignore else: sanity check */                                                                           // 49
    if (parentRoute) {                                                                                                 // 50
      parentRoute.indexRoute = _Redirect2['default'].createRouteFromReactElement(element);                             // 51
    } else {                                                                                                           // 52
      process.env.NODE_ENV !== 'production' ? _warning2['default'](false, 'An <IndexRedirect> does not make sense at the root of your route config') : undefined;
    }                                                                                                                  // 54
  };                                                                                                                   // 55
                                                                                                                       // 56
  /* istanbul ignore next: sanity check */                                                                             // 57
                                                                                                                       // 58
  IndexRedirect.prototype.render = function render() {                                                                 // 59
    !false ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, '<IndexRedirect> elements are for router configuration only and should not be rendered') : _invariant2['default'](false) : undefined;
  };                                                                                                                   // 61
                                                                                                                       // 62
  _createClass(IndexRedirect, null, [{                                                                                 // 63
    key: 'propTypes',                                                                                                  // 64
    value: {                                                                                                           // 65
      to: string.isRequired,                                                                                           // 66
      query: object,                                                                                                   // 67
      state: object,                                                                                                   // 68
      onEnter: _PropTypes.falsy,                                                                                       // 69
      children: _PropTypes.falsy                                                                                       // 70
    },                                                                                                                 // 71
    enumerable: true                                                                                                   // 72
  }]);                                                                                                                 // 73
                                                                                                                       // 74
  return IndexRedirect;                                                                                                // 75
})(_react.Component);                                                                                                  // 76
                                                                                                                       // 77
exports['default'] = IndexRedirect;                                                                                    // 78
module.exports = exports['default'];                                                                                   // 79
}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{"./PropTypes":41,"./Redirect":42,"_process":1,"invariant":57,"warning":58}],37:[function(require,module,exports){   //
(function (process,global){                                                                                            //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }
                                                                                                                       // 10
function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
                                                                                                                       // 12
var _warning = require('warning');                                                                                     // 13
                                                                                                                       // 14
var _warning2 = _interopRequireDefault(_warning);                                                                      // 15
                                                                                                                       // 16
var _invariant = require('invariant');                                                                                 // 17
                                                                                                                       // 18
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 19
                                                                                                                       // 20
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 22
var _react2 = _interopRequireDefault(_react);                                                                          // 23
                                                                                                                       // 24
var _RouteUtils = require('./RouteUtils');                                                                             // 25
                                                                                                                       // 26
var _PropTypes = require('./PropTypes');                                                                               // 27
                                                                                                                       // 28
var func = _react2['default'].PropTypes.func;                                                                          // 29
                                                                                                                       // 30
/**                                                                                                                    // 31
 * An <IndexRoute> is used to specify its parent's <Route indexRoute> in                                               // 32
 * a JSX route config.                                                                                                 // 33
 */                                                                                                                    // 34
                                                                                                                       // 35
var IndexRoute = (function (_Component) {                                                                              // 36
  _inherits(IndexRoute, _Component);                                                                                   // 37
                                                                                                                       // 38
  function IndexRoute() {                                                                                              // 39
    _classCallCheck(this, IndexRoute);                                                                                 // 40
                                                                                                                       // 41
    _Component.apply(this, arguments);                                                                                 // 42
  }                                                                                                                    // 43
                                                                                                                       // 44
  IndexRoute.createRouteFromReactElement = function createRouteFromReactElement(element, parentRoute) {                // 45
    /* istanbul ignore else: sanity check */                                                                           // 46
    if (parentRoute) {                                                                                                 // 47
      parentRoute.indexRoute = _RouteUtils.createRouteFromReactElement(element);                                       // 48
    } else {                                                                                                           // 49
      process.env.NODE_ENV !== 'production' ? _warning2['default'](false, 'An <IndexRoute> does not make sense at the root of your route config') : undefined;
    }                                                                                                                  // 51
  };                                                                                                                   // 52
                                                                                                                       // 53
  /* istanbul ignore next: sanity check */                                                                             // 54
                                                                                                                       // 55
  IndexRoute.prototype.render = function render() {                                                                    // 56
    !false ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, '<IndexRoute> elements are for router configuration only and should not be rendered') : _invariant2['default'](false) : undefined;
  };                                                                                                                   // 58
                                                                                                                       // 59
  _createClass(IndexRoute, null, [{                                                                                    // 60
    key: 'propTypes',                                                                                                  // 61
    value: {                                                                                                           // 62
      path: _PropTypes.falsy,                                                                                          // 63
      component: _PropTypes.component,                                                                                 // 64
      components: _PropTypes.components,                                                                               // 65
      getComponent: func,                                                                                              // 66
      getComponents: func                                                                                              // 67
    },                                                                                                                 // 68
    enumerable: true                                                                                                   // 69
  }]);                                                                                                                 // 70
                                                                                                                       // 71
  return IndexRoute;                                                                                                   // 72
})(_react.Component);                                                                                                  // 73
                                                                                                                       // 74
exports['default'] = IndexRoute;                                                                                       // 75
module.exports = exports['default'];                                                                                   // 76
}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{"./PropTypes":41,"./RouteUtils":45,"_process":1,"invariant":57,"warning":58}],38:[function(require,module,exports){
(function (process,global){                                                                                            //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 5
                                                                                                                       // 6
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 8
var _react2 = _interopRequireDefault(_react);                                                                          // 9
                                                                                                                       // 10
var _invariant = require('invariant');                                                                                 // 11
                                                                                                                       // 12
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 13
                                                                                                                       // 14
var object = _react2['default'].PropTypes.object;                                                                      // 15
                                                                                                                       // 16
/**                                                                                                                    // 17
 * The Lifecycle mixin adds the routerWillLeave lifecycle method to a                                                  // 18
 * component that may be used to cancel a transition or prompt the user                                                // 19
 * for confirmation.                                                                                                   // 20
 *                                                                                                                     // 21
 * On standard transitions, routerWillLeave receives a single argument: the                                            // 22
 * location we're transitioning to. To cancel the transition, return false.                                            // 23
 * To prompt the user for confirmation, return a prompt message (string).                                              // 24
 *                                                                                                                     // 25
 * During the beforeunload event (assuming you're using the useBeforeUnload                                            // 26
 * history enhancer), routerWillLeave does not receive a location object                                               // 27
 * because it isn't possible for us to know the location we're transitioning                                           // 28
 * to. In this case routerWillLeave must return a prompt message to prevent                                            // 29
 * the user from closing the window/tab.                                                                               // 30
 */                                                                                                                    // 31
var Lifecycle = {                                                                                                      // 32
                                                                                                                       // 33
  contextTypes: {                                                                                                      // 34
    history: object.isRequired,                                                                                        // 35
    // Nested children receive the route as context, either                                                            // 36
    // set by the route component using the RouteContext mixin                                                         // 37
    // or by some other ancestor.                                                                                      // 38
    route: object                                                                                                      // 39
  },                                                                                                                   // 40
                                                                                                                       // 41
  propTypes: {                                                                                                         // 42
    // Route components receive the route object as a prop.                                                            // 43
    route: object                                                                                                      // 44
  },                                                                                                                   // 45
                                                                                                                       // 46
  componentDidMount: function componentDidMount() {                                                                    // 47
    !this.routerWillLeave ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'The Lifecycle mixin requires you to define a routerWillLeave method') : _invariant2['default'](false) : undefined;
                                                                                                                       // 49
    var route = this.props.route || this.context.route;                                                                // 50
                                                                                                                       // 51
    !route ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'The Lifecycle mixin must be used on either a) a <Route component> or ' + 'b) a descendant of a <Route component> that uses the RouteContext mixin') : _invariant2['default'](false) : undefined;
                                                                                                                       // 53
    this._unlistenBeforeLeavingRoute = this.context.history.listenBeforeLeavingRoute(route, this.routerWillLeave);     // 54
  },                                                                                                                   // 55
                                                                                                                       // 56
  componentWillUnmount: function componentWillUnmount() {                                                              // 57
    if (this._unlistenBeforeLeavingRoute) this._unlistenBeforeLeavingRoute();                                          // 58
  }                                                                                                                    // 59
                                                                                                                       // 60
};                                                                                                                     // 61
                                                                                                                       // 62
exports['default'] = Lifecycle;                                                                                        // 63
module.exports = exports['default'];                                                                                   // 64
}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{"_process":1,"invariant":57}],39:[function(require,module,exports){                                                 //
(function (global){                                                                                                    //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();
                                                                                                                       // 8
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 9
                                                                                                                       // 10
function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }
                                                                                                                       // 12
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }
                                                                                                                       // 14
function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
                                                                                                                       // 16
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 18
var _react2 = _interopRequireDefault(_react);                                                                          // 19
                                                                                                                       // 20
var _React$PropTypes = _react2['default'].PropTypes;                                                                   // 21
var bool = _React$PropTypes.bool;                                                                                      // 22
var object = _React$PropTypes.object;                                                                                  // 23
var string = _React$PropTypes.string;                                                                                  // 24
var func = _React$PropTypes.func;                                                                                      // 25
                                                                                                                       // 26
function isLeftClickEvent(event) {                                                                                     // 27
  return event.button === 0;                                                                                           // 28
}                                                                                                                      // 29
                                                                                                                       // 30
function isModifiedEvent(event) {                                                                                      // 31
  return !!(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);                                         // 32
}                                                                                                                      // 33
                                                                                                                       // 34
function isEmptyObject(object) {                                                                                       // 35
  for (var p in object) {                                                                                              // 36
    if (object.hasOwnProperty(p)) return false;                                                                        // 37
  }return true;                                                                                                        // 38
}                                                                                                                      // 39
                                                                                                                       // 40
/**                                                                                                                    // 41
 * A <Link> is used to create an <a> element that links to a route.                                                    // 42
 * When that route is active, the link gets the value of its                                                           // 43
 * `activeClassName` prop                                                                                              // 44
 *                                                                                                                     // 45
 * For example, assuming you have the following route:                                                                 // 46
 *                                                                                                                     // 47
 *   <Route path="/posts/:postID" component={Post} />                                                                  // 48
 *                                                                                                                     // 49
 * You could use the following component to link to that route:                                                        // 50
 *                                                                                                                     // 51
 *   <Link to={`/posts/${post.id}`} />                                                                                 // 52
 *                                                                                                                     // 53
 * Links may pass along location state and/or query string parameters                                                  // 54
 * in the state/query props, respectively.                                                                             // 55
 *                                                                                                                     // 56
 *   <Link ... query={{ show: true }} state={{ the: 'state' }} />                                                      // 57
 */                                                                                                                    // 58
                                                                                                                       // 59
var Link = (function (_Component) {                                                                                    // 60
  _inherits(Link, _Component);                                                                                         // 61
                                                                                                                       // 62
  function Link() {                                                                                                    // 63
    _classCallCheck(this, Link);                                                                                       // 64
                                                                                                                       // 65
    _Component.apply(this, arguments);                                                                                 // 66
  }                                                                                                                    // 67
                                                                                                                       // 68
  Link.prototype.handleClick = function handleClick(event) {                                                           // 69
    var allowTransition = true;                                                                                        // 70
                                                                                                                       // 71
    if (this.props.onClick) this.props.onClick(event);                                                                 // 72
                                                                                                                       // 73
    if (isModifiedEvent(event) || !isLeftClickEvent(event)) return;                                                    // 74
                                                                                                                       // 75
    if (event.defaultPrevented === true) allowTransition = false;                                                      // 76
                                                                                                                       // 77
    // If target prop is set (e.g. to "_blank") let browser handle link.                                               // 78
    /* istanbul ignore if: untestable with Karma */                                                                    // 79
    if (this.props.target) {                                                                                           // 80
      if (!allowTransition) event.preventDefault();                                                                    // 81
                                                                                                                       // 82
      return;                                                                                                          // 83
    }                                                                                                                  // 84
                                                                                                                       // 85
    event.preventDefault();                                                                                            // 86
                                                                                                                       // 87
    if (allowTransition) {                                                                                             // 88
      var _props = this.props;                                                                                         // 89
      var state = _props.state;                                                                                        // 90
      var to = _props.to;                                                                                              // 91
      var query = _props.query;                                                                                        // 92
      var hash = _props.hash;                                                                                          // 93
                                                                                                                       // 94
      if (hash) to += hash;                                                                                            // 95
                                                                                                                       // 96
      this.context.history.pushState(state, to, query);                                                                // 97
    }                                                                                                                  // 98
  };                                                                                                                   // 99
                                                                                                                       // 100
  Link.prototype.render = function render() {                                                                          // 101
    var _this = this;                                                                                                  // 102
                                                                                                                       // 103
    var _props2 = this.props;                                                                                          // 104
    var to = _props2.to;                                                                                               // 105
    var query = _props2.query;                                                                                         // 106
    var hash = _props2.hash;                                                                                           // 107
    var state = _props2.state;                                                                                         // 108
    var activeClassName = _props2.activeClassName;                                                                     // 109
    var activeStyle = _props2.activeStyle;                                                                             // 110
    var onlyActiveOnIndex = _props2.onlyActiveOnIndex;                                                                 // 111
                                                                                                                       // 112
    var props = _objectWithoutProperties(_props2, ['to', 'query', 'hash', 'state', 'activeClassName', 'activeStyle', 'onlyActiveOnIndex']);
                                                                                                                       // 114
    // Manually override onClick.                                                                                      // 115
    props.onClick = function (e) {                                                                                     // 116
      return _this.handleClick(e);                                                                                     // 117
    };                                                                                                                 // 118
                                                                                                                       // 119
    // Ignore if rendered outside the context of history, simplifies unit testing.                                     // 120
    var history = this.context.history;                                                                                // 121
                                                                                                                       // 122
    if (history) {                                                                                                     // 123
      props.href = history.createHref(to, query);                                                                      // 124
                                                                                                                       // 125
      if (hash) props.href += hash;                                                                                    // 126
                                                                                                                       // 127
      if (activeClassName || activeStyle != null && !isEmptyObject(activeStyle)) {                                     // 128
        if (history.isActive(to, query, onlyActiveOnIndex)) {                                                          // 129
          if (activeClassName) props.className += props.className === '' ? activeClassName : ' ' + activeClassName;    // 130
                                                                                                                       // 131
          if (activeStyle) props.style = _extends({}, props.style, activeStyle);                                       // 132
        }                                                                                                              // 133
      }                                                                                                                // 134
    }                                                                                                                  // 135
                                                                                                                       // 136
    return _react2['default'].createElement('a', props);                                                               // 137
  };                                                                                                                   // 138
                                                                                                                       // 139
  _createClass(Link, null, [{                                                                                          // 140
    key: 'contextTypes',                                                                                               // 141
    value: {                                                                                                           // 142
      history: object                                                                                                  // 143
    },                                                                                                                 // 144
    enumerable: true                                                                                                   // 145
  }, {                                                                                                                 // 146
    key: 'propTypes',                                                                                                  // 147
    value: {                                                                                                           // 148
      to: string.isRequired,                                                                                           // 149
      query: object,                                                                                                   // 150
      hash: string,                                                                                                    // 151
      state: object,                                                                                                   // 152
      activeStyle: object,                                                                                             // 153
      activeClassName: string,                                                                                         // 154
      onlyActiveOnIndex: bool.isRequired,                                                                              // 155
      onClick: func                                                                                                    // 156
    },                                                                                                                 // 157
    enumerable: true                                                                                                   // 158
  }, {                                                                                                                 // 159
    key: 'defaultProps',                                                                                               // 160
    value: {                                                                                                           // 161
      onlyActiveOnIndex: false,                                                                                        // 162
      className: '',                                                                                                   // 163
      style: {}                                                                                                        // 164
    },                                                                                                                 // 165
    enumerable: true                                                                                                   // 166
  }]);                                                                                                                 // 167
                                                                                                                       // 168
  return Link;                                                                                                         // 169
})(_react.Component);                                                                                                  // 170
                                                                                                                       // 171
exports['default'] = Link;                                                                                             // 172
module.exports = exports['default'];                                                                                   // 173
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{}],40:[function(require,module,exports){                                                                            //
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
exports.compilePattern = compilePattern;                                                                               // 4
exports.matchPattern = matchPattern;                                                                                   // 5
exports.getParamNames = getParamNames;                                                                                 // 6
exports.getParams = getParams;                                                                                         // 7
exports.formatPattern = formatPattern;                                                                                 // 8
                                                                                                                       // 9
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 10
                                                                                                                       // 11
var _invariant = require('invariant');                                                                                 // 12
                                                                                                                       // 13
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 14
                                                                                                                       // 15
function escapeRegExp(string) {                                                                                        // 16
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');                                                                // 17
}                                                                                                                      // 18
                                                                                                                       // 19
function escapeSource(string) {                                                                                        // 20
  return escapeRegExp(string).replace(/\/+/g, '/+');                                                                   // 21
}                                                                                                                      // 22
                                                                                                                       // 23
function _compilePattern(pattern) {                                                                                    // 24
  var regexpSource = '';                                                                                               // 25
  var paramNames = [];                                                                                                 // 26
  var tokens = [];                                                                                                     // 27
                                                                                                                       // 28
  var match = undefined,                                                                                               // 29
      lastIndex = 0,                                                                                                   // 30
      matcher = /:([a-zA-Z_$][a-zA-Z0-9_$]*)|\*\*|\*|\(|\)/g;                                                          // 31
  while (match = matcher.exec(pattern)) {                                                                              // 32
    if (match.index !== lastIndex) {                                                                                   // 33
      tokens.push(pattern.slice(lastIndex, match.index));                                                              // 34
      regexpSource += escapeSource(pattern.slice(lastIndex, match.index));                                             // 35
    }                                                                                                                  // 36
                                                                                                                       // 37
    if (match[1]) {                                                                                                    // 38
      regexpSource += '([^/?#]+)';                                                                                     // 39
      paramNames.push(match[1]);                                                                                       // 40
    } else if (match[0] === '**') {                                                                                    // 41
      regexpSource += '([\\s\\S]*)';                                                                                   // 42
      paramNames.push('splat');                                                                                        // 43
    } else if (match[0] === '*') {                                                                                     // 44
      regexpSource += '([\\s\\S]*?)';                                                                                  // 45
      paramNames.push('splat');                                                                                        // 46
    } else if (match[0] === '(') {                                                                                     // 47
      regexpSource += '(?:';                                                                                           // 48
    } else if (match[0] === ')') {                                                                                     // 49
      regexpSource += ')?';                                                                                            // 50
    }                                                                                                                  // 51
                                                                                                                       // 52
    tokens.push(match[0]);                                                                                             // 53
                                                                                                                       // 54
    lastIndex = matcher.lastIndex;                                                                                     // 55
  }                                                                                                                    // 56
                                                                                                                       // 57
  if (lastIndex !== pattern.length) {                                                                                  // 58
    tokens.push(pattern.slice(lastIndex, pattern.length));                                                             // 59
    regexpSource += escapeSource(pattern.slice(lastIndex, pattern.length));                                            // 60
  }                                                                                                                    // 61
                                                                                                                       // 62
  return {                                                                                                             // 63
    pattern: pattern,                                                                                                  // 64
    regexpSource: regexpSource,                                                                                        // 65
    paramNames: paramNames,                                                                                            // 66
    tokens: tokens                                                                                                     // 67
  };                                                                                                                   // 68
}                                                                                                                      // 69
                                                                                                                       // 70
var CompiledPatternsCache = {};                                                                                        // 71
                                                                                                                       // 72
function compilePattern(pattern) {                                                                                     // 73
  if (!(pattern in CompiledPatternsCache)) CompiledPatternsCache[pattern] = _compilePattern(pattern);                  // 74
                                                                                                                       // 75
  return CompiledPatternsCache[pattern];                                                                               // 76
}                                                                                                                      // 77
                                                                                                                       // 78
/**                                                                                                                    // 79
 * Attempts to match a pattern on the given pathname. Patterns may use                                                 // 80
 * the following special characters:                                                                                   // 81
 *                                                                                                                     // 82
 * - :paramName     Matches a URL segment up to the next /, ?, or #. The                                               // 83
 *                  captured string is considered a "param"                                                            // 84
 * - ()             Wraps a segment of the URL that is optional                                                        // 85
 * - *              Consumes (non-greedy) all characters up to the next                                                // 86
 *                  character in the pattern, or to the end of the URL if                                              // 87
 *                  there is none                                                                                      // 88
 * - **             Consumes (greedy) all characters up to the next character                                          // 89
 *                  in the pattern, or to the end of the URL if there is none                                          // 90
 *                                                                                                                     // 91
 * The return value is an object with the following properties:                                                        // 92
 *                                                                                                                     // 93
 * - remainingPathname                                                                                                 // 94
 * - paramNames                                                                                                        // 95
 * - paramValues                                                                                                       // 96
 */                                                                                                                    // 97
                                                                                                                       // 98
function matchPattern(pattern, pathname) {                                                                             // 99
  // Make leading slashes consistent between pattern and pathname.                                                     // 100
  if (pattern.charAt(0) !== '/') {                                                                                     // 101
    pattern = '/' + pattern;                                                                                           // 102
  }                                                                                                                    // 103
  if (pathname.charAt(0) !== '/') {                                                                                    // 104
    pathname = '/' + pathname;                                                                                         // 105
  }                                                                                                                    // 106
                                                                                                                       // 107
  var _compilePattern2 = compilePattern(pattern);                                                                      // 108
                                                                                                                       // 109
  var regexpSource = _compilePattern2.regexpSource;                                                                    // 110
  var paramNames = _compilePattern2.paramNames;                                                                        // 111
  var tokens = _compilePattern2.tokens;                                                                                // 112
                                                                                                                       // 113
  regexpSource += '/*'; // Capture path separators                                                                     // 114
                                                                                                                       // 115
  // Special-case patterns like '*' for catch-all routes.                                                              // 116
  var captureRemaining = tokens[tokens.length - 1] !== '*';                                                            // 117
                                                                                                                       // 118
  if (captureRemaining) {                                                                                              // 119
    // This will match newlines in the remaining path.                                                                 // 120
    regexpSource += '([\\s\\S]*?)';                                                                                    // 121
  }                                                                                                                    // 122
                                                                                                                       // 123
  var match = pathname.match(new RegExp('^' + regexpSource + '$', 'i'));                                               // 124
                                                                                                                       // 125
  var remainingPathname = undefined,                                                                                   // 126
      paramValues = undefined;                                                                                         // 127
  if (match != null) {                                                                                                 // 128
    if (captureRemaining) {                                                                                            // 129
      remainingPathname = match.pop();                                                                                 // 130
      var matchedPath = match[0].substr(0, match[0].length - remainingPathname.length);                                // 131
                                                                                                                       // 132
      // If we didn't match the entire pathname, then make sure that the match                                         // 133
      // we did get ends at a path separator (potentially the one we added                                             // 134
      // above at the beginning of the path, if the actual match was empty).                                           // 135
      if (remainingPathname && matchedPath.charAt(matchedPath.length - 1) !== '/') {                                   // 136
        return {                                                                                                       // 137
          remainingPathname: null,                                                                                     // 138
          paramNames: paramNames,                                                                                      // 139
          paramValues: null                                                                                            // 140
        };                                                                                                             // 141
      }                                                                                                                // 142
    } else {                                                                                                           // 143
      // If this matched at all, then the match was the entire pathname.                                               // 144
      remainingPathname = '';                                                                                          // 145
    }                                                                                                                  // 146
                                                                                                                       // 147
    paramValues = match.slice(1).map(function (v) {                                                                    // 148
      return v != null ? decodeURIComponent(v) : v;                                                                    // 149
    });                                                                                                                // 150
  } else {                                                                                                             // 151
    remainingPathname = paramValues = null;                                                                            // 152
  }                                                                                                                    // 153
                                                                                                                       // 154
  return {                                                                                                             // 155
    remainingPathname: remainingPathname,                                                                              // 156
    paramNames: paramNames,                                                                                            // 157
    paramValues: paramValues                                                                                           // 158
  };                                                                                                                   // 159
}                                                                                                                      // 160
                                                                                                                       // 161
function getParamNames(pattern) {                                                                                      // 162
  return compilePattern(pattern).paramNames;                                                                           // 163
}                                                                                                                      // 164
                                                                                                                       // 165
function getParams(pattern, pathname) {                                                                                // 166
  var _matchPattern = matchPattern(pattern, pathname);                                                                 // 167
                                                                                                                       // 168
  var paramNames = _matchPattern.paramNames;                                                                           // 169
  var paramValues = _matchPattern.paramValues;                                                                         // 170
                                                                                                                       // 171
  if (paramValues != null) {                                                                                           // 172
    return paramNames.reduce(function (memo, paramName, index) {                                                       // 173
      memo[paramName] = paramValues[index];                                                                            // 174
      return memo;                                                                                                     // 175
    }, {});                                                                                                            // 176
  }                                                                                                                    // 177
                                                                                                                       // 178
  return null;                                                                                                         // 179
}                                                                                                                      // 180
                                                                                                                       // 181
/**                                                                                                                    // 182
 * Returns a version of the given pattern with params interpolated. Throws                                             // 183
 * if there is a dynamic segment of the pattern for which there is no param.                                           // 184
 */                                                                                                                    // 185
                                                                                                                       // 186
function formatPattern(pattern, params) {                                                                              // 187
  params = params || {};                                                                                               // 188
                                                                                                                       // 189
  var _compilePattern3 = compilePattern(pattern);                                                                      // 190
                                                                                                                       // 191
  var tokens = _compilePattern3.tokens;                                                                                // 192
                                                                                                                       // 193
  var parenCount = 0,                                                                                                  // 194
      pathname = '',                                                                                                   // 195
      splatIndex = 0;                                                                                                  // 196
                                                                                                                       // 197
  var token = undefined,                                                                                               // 198
      paramName = undefined,                                                                                           // 199
      paramValue = undefined;                                                                                          // 200
  for (var i = 0, len = tokens.length; i < len; ++i) {                                                                 // 201
    token = tokens[i];                                                                                                 // 202
                                                                                                                       // 203
    if (token === '*' || token === '**') {                                                                             // 204
      paramValue = Array.isArray(params.splat) ? params.splat[splatIndex++] : params.splat;                            // 205
                                                                                                                       // 206
      !(paramValue != null || parenCount > 0) ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'Missing splat #%s for path "%s"', splatIndex, pattern) : _invariant2['default'](false) : undefined;
                                                                                                                       // 208
      if (paramValue != null) pathname += encodeURI(paramValue);                                                       // 209
    } else if (token === '(') {                                                                                        // 210
      parenCount += 1;                                                                                                 // 211
    } else if (token === ')') {                                                                                        // 212
      parenCount -= 1;                                                                                                 // 213
    } else if (token.charAt(0) === ':') {                                                                              // 214
      paramName = token.substring(1);                                                                                  // 215
      paramValue = params[paramName];                                                                                  // 216
                                                                                                                       // 217
      !(paramValue != null || parenCount > 0) ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'Missing "%s" parameter for path "%s"', paramName, pattern) : _invariant2['default'](false) : undefined;
                                                                                                                       // 219
      if (paramValue != null) pathname += encodeURIComponent(paramValue);                                              // 220
    } else {                                                                                                           // 221
      pathname += token;                                                                                               // 222
    }                                                                                                                  // 223
  }                                                                                                                    // 224
                                                                                                                       // 225
  return pathname.replace(/\/+/g, '/');                                                                                // 226
}                                                                                                                      // 227
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"_process":1,"invariant":57}],41:[function(require,module,exports){                                                 //
(function (global){                                                                                                    //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
exports.falsy = falsy;                                                                                                 // 4
                                                                                                                       // 5
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 7
var func = _react.PropTypes.func;                                                                                      // 8
var object = _react.PropTypes.object;                                                                                  // 9
var arrayOf = _react.PropTypes.arrayOf;                                                                                // 10
var oneOfType = _react.PropTypes.oneOfType;                                                                            // 11
var element = _react.PropTypes.element;                                                                                // 12
var shape = _react.PropTypes.shape;                                                                                    // 13
var string = _react.PropTypes.string;                                                                                  // 14
                                                                                                                       // 15
function falsy(props, propName, componentName) {                                                                       // 16
  if (props[propName]) return new Error('<' + componentName + '> should not have a "' + propName + '" prop');          // 17
}                                                                                                                      // 18
                                                                                                                       // 19
var history = shape({                                                                                                  // 20
  listen: func.isRequired,                                                                                             // 21
  pushState: func.isRequired,                                                                                          // 22
  replaceState: func.isRequired,                                                                                       // 23
  go: func.isRequired                                                                                                  // 24
});                                                                                                                    // 25
                                                                                                                       // 26
exports.history = history;                                                                                             // 27
var location = shape({                                                                                                 // 28
  pathname: string.isRequired,                                                                                         // 29
  search: string.isRequired,                                                                                           // 30
  state: object,                                                                                                       // 31
  action: string.isRequired,                                                                                           // 32
  key: string                                                                                                          // 33
});                                                                                                                    // 34
                                                                                                                       // 35
exports.location = location;                                                                                           // 36
var component = oneOfType([func, string]);                                                                             // 37
exports.component = component;                                                                                         // 38
var components = oneOfType([component, object]);                                                                       // 39
exports.components = components;                                                                                       // 40
var route = oneOfType([object, element]);                                                                              // 41
exports.route = route;                                                                                                 // 42
var routes = oneOfType([route, arrayOf(route)]);                                                                       // 43
                                                                                                                       // 44
exports.routes = routes;                                                                                               // 45
exports['default'] = {                                                                                                 // 46
  falsy: falsy,                                                                                                        // 47
  history: history,                                                                                                    // 48
  location: location,                                                                                                  // 49
  component: component,                                                                                                // 50
  components: components,                                                                                              // 51
  route: route                                                                                                         // 52
};                                                                                                                     // 53
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{}],42:[function(require,module,exports){                                                                            //
(function (process,global){                                                                                            //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }
                                                                                                                       // 10
function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
                                                                                                                       // 12
var _invariant = require('invariant');                                                                                 // 13
                                                                                                                       // 14
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 15
                                                                                                                       // 16
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 18
var _react2 = _interopRequireDefault(_react);                                                                          // 19
                                                                                                                       // 20
var _RouteUtils = require('./RouteUtils');                                                                             // 21
                                                                                                                       // 22
var _PatternUtils = require('./PatternUtils');                                                                         // 23
                                                                                                                       // 24
var _PropTypes = require('./PropTypes');                                                                               // 25
                                                                                                                       // 26
var _React$PropTypes = _react2['default'].PropTypes;                                                                   // 27
var string = _React$PropTypes.string;                                                                                  // 28
var object = _React$PropTypes.object;                                                                                  // 29
                                                                                                                       // 30
/**                                                                                                                    // 31
 * A <Redirect> is used to declare another URL path a client should                                                    // 32
 * be sent to when they request a given URL.                                                                           // 33
 *                                                                                                                     // 34
 * Redirects are placed alongside routes in the route configuration                                                    // 35
 * and are traversed in the same manner.                                                                               // 36
 */                                                                                                                    // 37
                                                                                                                       // 38
var Redirect = (function (_Component) {                                                                                // 39
  _inherits(Redirect, _Component);                                                                                     // 40
                                                                                                                       // 41
  function Redirect() {                                                                                                // 42
    _classCallCheck(this, Redirect);                                                                                   // 43
                                                                                                                       // 44
    _Component.apply(this, arguments);                                                                                 // 45
  }                                                                                                                    // 46
                                                                                                                       // 47
  Redirect.createRouteFromReactElement = function createRouteFromReactElement(element) {                               // 48
    var route = _RouteUtils.createRouteFromReactElement(element);                                                      // 49
                                                                                                                       // 50
    if (route.from) route.path = route.from;                                                                           // 51
                                                                                                                       // 52
    route.onEnter = function (nextState, replaceState) {                                                               // 53
      var location = nextState.location;                                                                               // 54
      var params = nextState.params;                                                                                   // 55
                                                                                                                       // 56
      var pathname = undefined;                                                                                        // 57
      if (route.to.charAt(0) === '/') {                                                                                // 58
        pathname = _PatternUtils.formatPattern(route.to, params);                                                      // 59
      } else if (!route.to) {                                                                                          // 60
        pathname = location.pathname;                                                                                  // 61
      } else {                                                                                                         // 62
        var routeIndex = nextState.routes.indexOf(route);                                                              // 63
        var parentPattern = Redirect.getRoutePattern(nextState.routes, routeIndex - 1);                                // 64
        var pattern = parentPattern.replace(/\/*$/, '/') + route.to;                                                   // 65
        pathname = _PatternUtils.formatPattern(pattern, params);                                                       // 66
      }                                                                                                                // 67
                                                                                                                       // 68
      replaceState(route.state || location.state, pathname, route.query || location.query);                            // 69
    };                                                                                                                 // 70
                                                                                                                       // 71
    return route;                                                                                                      // 72
  };                                                                                                                   // 73
                                                                                                                       // 74
  Redirect.getRoutePattern = function getRoutePattern(routes, routeIndex) {                                            // 75
    var parentPattern = '';                                                                                            // 76
                                                                                                                       // 77
    for (var i = routeIndex; i >= 0; i--) {                                                                            // 78
      var route = routes[i];                                                                                           // 79
      var pattern = route.path || '';                                                                                  // 80
      parentPattern = pattern.replace(/\/*$/, '/') + parentPattern;                                                    // 81
                                                                                                                       // 82
      if (pattern.indexOf('/') === 0) break;                                                                           // 83
    }                                                                                                                  // 84
                                                                                                                       // 85
    return '/' + parentPattern;                                                                                        // 86
  };                                                                                                                   // 87
                                                                                                                       // 88
  /* istanbul ignore next: sanity check */                                                                             // 89
                                                                                                                       // 90
  Redirect.prototype.render = function render() {                                                                      // 91
    !false ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, '<Redirect> elements are for router configuration only and should not be rendered') : _invariant2['default'](false) : undefined;
  };                                                                                                                   // 93
                                                                                                                       // 94
  _createClass(Redirect, null, [{                                                                                      // 95
    key: 'propTypes',                                                                                                  // 96
    value: {                                                                                                           // 97
      path: string,                                                                                                    // 98
      from: string, // Alias for path                                                                                  // 99
      to: string.isRequired,                                                                                           // 100
      query: object,                                                                                                   // 101
      state: object,                                                                                                   // 102
      onEnter: _PropTypes.falsy,                                                                                       // 103
      children: _PropTypes.falsy                                                                                       // 104
    },                                                                                                                 // 105
    enumerable: true                                                                                                   // 106
  }]);                                                                                                                 // 107
                                                                                                                       // 108
  return Redirect;                                                                                                     // 109
})(_react.Component);                                                                                                  // 110
                                                                                                                       // 111
exports['default'] = Redirect;                                                                                         // 112
module.exports = exports['default'];                                                                                   // 113
}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{"./PatternUtils":40,"./PropTypes":41,"./RouteUtils":45,"_process":1,"invariant":57}],43:[function(require,module,exports){
(function (process,global){                                                                                            //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }
                                                                                                                       // 10
function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
                                                                                                                       // 12
var _invariant = require('invariant');                                                                                 // 13
                                                                                                                       // 14
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 15
                                                                                                                       // 16
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 18
var _react2 = _interopRequireDefault(_react);                                                                          // 19
                                                                                                                       // 20
var _RouteUtils = require('./RouteUtils');                                                                             // 21
                                                                                                                       // 22
var _PropTypes = require('./PropTypes');                                                                               // 23
                                                                                                                       // 24
var _React$PropTypes = _react2['default'].PropTypes;                                                                   // 25
var string = _React$PropTypes.string;                                                                                  // 26
var func = _React$PropTypes.func;                                                                                      // 27
                                                                                                                       // 28
/**                                                                                                                    // 29
 * A <Route> is used to declare which components are rendered to the                                                   // 30
 * page when the URL matches a given pattern.                                                                          // 31
 *                                                                                                                     // 32
 * Routes are arranged in a nested tree structure. When a new URL is                                                   // 33
 * requested, the tree is searched depth-first to find a route whose                                                   // 34
 * path matches the URL.  When one is found, all routes in the tree                                                    // 35
 * that lead to it are considered "active" and their components are                                                    // 36
 * rendered into the DOM, nested in the same order as in the tree.                                                     // 37
 */                                                                                                                    // 38
                                                                                                                       // 39
var Route = (function (_Component) {                                                                                   // 40
  _inherits(Route, _Component);                                                                                        // 41
                                                                                                                       // 42
  function Route() {                                                                                                   // 43
    _classCallCheck(this, Route);                                                                                      // 44
                                                                                                                       // 45
    _Component.apply(this, arguments);                                                                                 // 46
  }                                                                                                                    // 47
                                                                                                                       // 48
  /* istanbul ignore next: sanity check */                                                                             // 49
                                                                                                                       // 50
  Route.prototype.render = function render() {                                                                         // 51
    !false ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, '<Route> elements are for router configuration only and should not be rendered') : _invariant2['default'](false) : undefined;
  };                                                                                                                   // 53
                                                                                                                       // 54
  _createClass(Route, null, [{                                                                                         // 55
    key: 'createRouteFromReactElement',                                                                                // 56
    value: _RouteUtils.createRouteFromReactElement,                                                                    // 57
    enumerable: true                                                                                                   // 58
  }, {                                                                                                                 // 59
    key: 'propTypes',                                                                                                  // 60
    value: {                                                                                                           // 61
      path: string,                                                                                                    // 62
      component: _PropTypes.component,                                                                                 // 63
      components: _PropTypes.components,                                                                               // 64
      getComponent: func,                                                                                              // 65
      getComponents: func                                                                                              // 66
    },                                                                                                                 // 67
    enumerable: true                                                                                                   // 68
  }]);                                                                                                                 // 69
                                                                                                                       // 70
  return Route;                                                                                                        // 71
})(_react.Component);                                                                                                  // 72
                                                                                                                       // 73
exports['default'] = Route;                                                                                            // 74
module.exports = exports['default'];                                                                                   // 75
}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{"./PropTypes":41,"./RouteUtils":45,"_process":1,"invariant":57}],44:[function(require,module,exports){              //
(function (global){                                                                                                    //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 5
                                                                                                                       // 6
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 8
var _react2 = _interopRequireDefault(_react);                                                                          // 9
                                                                                                                       // 10
var object = _react2['default'].PropTypes.object;                                                                      // 11
                                                                                                                       // 12
/**                                                                                                                    // 13
 * The RouteContext mixin provides a convenient way for route                                                          // 14
 * components to set the route in context. This is needed for                                                          // 15
 * routes that render elements that want to use the Lifecycle                                                          // 16
 * mixin to prevent transitions.                                                                                       // 17
 */                                                                                                                    // 18
var RouteContext = {                                                                                                   // 19
                                                                                                                       // 20
  propTypes: {                                                                                                         // 21
    route: object.isRequired                                                                                           // 22
  },                                                                                                                   // 23
                                                                                                                       // 24
  childContextTypes: {                                                                                                 // 25
    route: object.isRequired                                                                                           // 26
  },                                                                                                                   // 27
                                                                                                                       // 28
  getChildContext: function getChildContext() {                                                                        // 29
    return {                                                                                                           // 30
      route: this.props.route                                                                                          // 31
    };                                                                                                                 // 32
  }                                                                                                                    // 33
                                                                                                                       // 34
};                                                                                                                     // 35
                                                                                                                       // 36
exports['default'] = RouteContext;                                                                                     // 37
module.exports = exports['default'];                                                                                   // 38
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{}],45:[function(require,module,exports){                                                                            //
(function (process,global){                                                                                            //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
exports.isReactChildren = isReactChildren;                                                                             // 7
exports.createRouteFromReactElement = createRouteFromReactElement;                                                     // 8
exports.createRoutesFromReactChildren = createRoutesFromReactChildren;                                                 // 9
exports.createRoutes = createRoutes;                                                                                   // 10
                                                                                                                       // 11
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 12
                                                                                                                       // 13
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 15
var _react2 = _interopRequireDefault(_react);                                                                          // 16
                                                                                                                       // 17
var _warning = require('warning');                                                                                     // 18
                                                                                                                       // 19
var _warning2 = _interopRequireDefault(_warning);                                                                      // 20
                                                                                                                       // 21
function isValidChild(object) {                                                                                        // 22
  return object == null || _react2['default'].isValidElement(object);                                                  // 23
}                                                                                                                      // 24
                                                                                                                       // 25
function isReactChildren(object) {                                                                                     // 26
  return isValidChild(object) || Array.isArray(object) && object.every(isValidChild);                                  // 27
}                                                                                                                      // 28
                                                                                                                       // 29
function checkPropTypes(componentName, propTypes, props) {                                                             // 30
  componentName = componentName || 'UnknownComponent';                                                                 // 31
                                                                                                                       // 32
  for (var propName in propTypes) {                                                                                    // 33
    if (propTypes.hasOwnProperty(propName)) {                                                                          // 34
      var error = propTypes[propName](props, propName, componentName);                                                 // 35
                                                                                                                       // 36
      /* istanbul ignore if: error logging */                                                                          // 37
      if (error instanceof Error) process.env.NODE_ENV !== 'production' ? _warning2['default'](false, error.message) : undefined;
    }                                                                                                                  // 39
  }                                                                                                                    // 40
}                                                                                                                      // 41
                                                                                                                       // 42
function createRoute(defaultProps, props) {                                                                            // 43
  return _extends({}, defaultProps, props);                                                                            // 44
}                                                                                                                      // 45
                                                                                                                       // 46
function createRouteFromReactElement(element) {                                                                        // 47
  var type = element.type;                                                                                             // 48
  var route = createRoute(type.defaultProps, element.props);                                                           // 49
                                                                                                                       // 50
  if (type.propTypes) checkPropTypes(type.displayName || type.name, type.propTypes, route);                            // 51
                                                                                                                       // 52
  if (route.children) {                                                                                                // 53
    var childRoutes = createRoutesFromReactChildren(route.children, route);                                            // 54
                                                                                                                       // 55
    if (childRoutes.length) route.childRoutes = childRoutes;                                                           // 56
                                                                                                                       // 57
    delete route.children;                                                                                             // 58
  }                                                                                                                    // 59
                                                                                                                       // 60
  return route;                                                                                                        // 61
}                                                                                                                      // 62
                                                                                                                       // 63
/**                                                                                                                    // 64
 * Creates and returns a routes object from the given ReactChildren. JSX                                               // 65
 * provides a convenient way to visualize how routes in the hierarchy are                                              // 66
 * nested.                                                                                                             // 67
 *                                                                                                                     // 68
 *   import { Route, createRoutesFromReactChildren } from 'react-router'                                               // 69
 *                                                                                                                     // 70
 *   const routes = createRoutesFromReactChildren(                                                                     // 71
 *     <Route component={App}>                                                                                         // 72
 *       <Route path="home" component={Dashboard}/>                                                                    // 73
 *       <Route path="news" component={NewsFeed}/>                                                                     // 74
 *     </Route>                                                                                                        // 75
 *   )                                                                                                                 // 76
 *                                                                                                                     // 77
 * Note: This method is automatically used when you provide <Route> children                                           // 78
 * to a <Router> component.                                                                                            // 79
 */                                                                                                                    // 80
                                                                                                                       // 81
function createRoutesFromReactChildren(children, parentRoute) {                                                        // 82
  var routes = [];                                                                                                     // 83
                                                                                                                       // 84
  _react2['default'].Children.forEach(children, function (element) {                                                   // 85
    if (_react2['default'].isValidElement(element)) {                                                                  // 86
      // Component classes may have a static create* method.                                                           // 87
      if (element.type.createRouteFromReactElement) {                                                                  // 88
        var route = element.type.createRouteFromReactElement(element, parentRoute);                                    // 89
                                                                                                                       // 90
        if (route) routes.push(route);                                                                                 // 91
      } else {                                                                                                         // 92
        routes.push(createRouteFromReactElement(element));                                                             // 93
      }                                                                                                                // 94
    }                                                                                                                  // 95
  });                                                                                                                  // 96
                                                                                                                       // 97
  return routes;                                                                                                       // 98
}                                                                                                                      // 99
                                                                                                                       // 100
/**                                                                                                                    // 101
 * Creates and returns an array of routes from the given object which                                                  // 102
 * may be a JSX route, a plain object route, or an array of either.                                                    // 103
 */                                                                                                                    // 104
                                                                                                                       // 105
function createRoutes(routes) {                                                                                        // 106
  if (isReactChildren(routes)) {                                                                                       // 107
    routes = createRoutesFromReactChildren(routes);                                                                    // 108
  } else if (routes && !Array.isArray(routes)) {                                                                       // 109
    routes = [routes];                                                                                                 // 110
  }                                                                                                                    // 111
                                                                                                                       // 112
  return routes;                                                                                                       // 113
}                                                                                                                      // 114
}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{"_process":1,"warning":58}],46:[function(require,module,exports){                                                   //
(function (process,global){                                                                                            //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();
                                                                                                                       // 8
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 9
                                                                                                                       // 10
function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }
                                                                                                                       // 12
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }
                                                                                                                       // 14
function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
                                                                                                                       // 16
var _warning = require('warning');                                                                                     // 17
                                                                                                                       // 18
var _warning2 = _interopRequireDefault(_warning);                                                                      // 19
                                                                                                                       // 20
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 22
var _react2 = _interopRequireDefault(_react);                                                                          // 23
                                                                                                                       // 24
var _historyLibCreateHashHistory = require('history/lib/createHashHistory');                                           // 25
                                                                                                                       // 26
var _historyLibCreateHashHistory2 = _interopRequireDefault(_historyLibCreateHashHistory);                              // 27
                                                                                                                       // 28
var _RouteUtils = require('./RouteUtils');                                                                             // 29
                                                                                                                       // 30
var _RoutingContext = require('./RoutingContext');                                                                     // 31
                                                                                                                       // 32
var _RoutingContext2 = _interopRequireDefault(_RoutingContext);                                                        // 33
                                                                                                                       // 34
var _useRoutes = require('./useRoutes');                                                                               // 35
                                                                                                                       // 36
var _useRoutes2 = _interopRequireDefault(_useRoutes);                                                                  // 37
                                                                                                                       // 38
var _PropTypes = require('./PropTypes');                                                                               // 39
                                                                                                                       // 40
var _React$PropTypes = _react2['default'].PropTypes;                                                                   // 41
var func = _React$PropTypes.func;                                                                                      // 42
var object = _React$PropTypes.object;                                                                                  // 43
                                                                                                                       // 44
/**                                                                                                                    // 45
 * A <Router> is a high-level API for automatically setting up                                                         // 46
 * a router that renders a <RoutingContext> with all the props                                                         // 47
 * it needs each time the URL changes.                                                                                 // 48
 */                                                                                                                    // 49
                                                                                                                       // 50
var Router = (function (_Component) {                                                                                  // 51
  _inherits(Router, _Component);                                                                                       // 52
                                                                                                                       // 53
  _createClass(Router, null, [{                                                                                        // 54
    key: 'propTypes',                                                                                                  // 55
    value: {                                                                                                           // 56
      history: object,                                                                                                 // 57
      children: _PropTypes.routes,                                                                                     // 58
      routes: _PropTypes.routes, // alias for children                                                                 // 59
      RoutingContext: func.isRequired,                                                                                 // 60
      createElement: func,                                                                                             // 61
      onError: func,                                                                                                   // 62
      onUpdate: func,                                                                                                  // 63
      parseQueryString: func,                                                                                          // 64
      stringifyQuery: func                                                                                             // 65
    },                                                                                                                 // 66
    enumerable: true                                                                                                   // 67
  }, {                                                                                                                 // 68
    key: 'defaultProps',                                                                                               // 69
    value: {                                                                                                           // 70
      RoutingContext: _RoutingContext2['default']                                                                      // 71
    },                                                                                                                 // 72
    enumerable: true                                                                                                   // 73
  }]);                                                                                                                 // 74
                                                                                                                       // 75
  function Router(props, context) {                                                                                    // 76
    _classCallCheck(this, Router);                                                                                     // 77
                                                                                                                       // 78
    _Component.call(this, props, context);                                                                             // 79
                                                                                                                       // 80
    this.state = {                                                                                                     // 81
      location: null,                                                                                                  // 82
      routes: null,                                                                                                    // 83
      params: null,                                                                                                    // 84
      components: null                                                                                                 // 85
    };                                                                                                                 // 86
  }                                                                                                                    // 87
                                                                                                                       // 88
  Router.prototype.handleError = function handleError(error) {                                                         // 89
    if (this.props.onError) {                                                                                          // 90
      this.props.onError.call(this, error);                                                                            // 91
    } else {                                                                                                           // 92
      // Throw errors by default so we don't silently swallow them!                                                    // 93
      throw error; // This error probably occurred in getChildRoutes or getComponents.                                 // 94
    }                                                                                                                  // 95
  };                                                                                                                   // 96
                                                                                                                       // 97
  Router.prototype.componentWillMount = function componentWillMount() {                                                // 98
    var _this = this;                                                                                                  // 99
                                                                                                                       // 100
    var _props = this.props;                                                                                           // 101
    var history = _props.history;                                                                                      // 102
    var children = _props.children;                                                                                    // 103
    var routes = _props.routes;                                                                                        // 104
    var parseQueryString = _props.parseQueryString;                                                                    // 105
    var stringifyQuery = _props.stringifyQuery;                                                                        // 106
                                                                                                                       // 107
    var createHistory = history ? function () {                                                                        // 108
      return history;                                                                                                  // 109
    } : _historyLibCreateHashHistory2['default'];                                                                      // 110
                                                                                                                       // 111
    this.history = _useRoutes2['default'](createHistory)({                                                             // 112
      routes: _RouteUtils.createRoutes(routes || children),                                                            // 113
      parseQueryString: parseQueryString,                                                                              // 114
      stringifyQuery: stringifyQuery                                                                                   // 115
    });                                                                                                                // 116
                                                                                                                       // 117
    this._unlisten = this.history.listen(function (error, state) {                                                     // 118
      if (error) {                                                                                                     // 119
        _this.handleError(error);                                                                                      // 120
      } else {                                                                                                         // 121
        _this.setState(state, _this.props.onUpdate);                                                                   // 122
      }                                                                                                                // 123
    });                                                                                                                // 124
  };                                                                                                                   // 125
                                                                                                                       // 126
  /* istanbul ignore next: sanity check */                                                                             // 127
                                                                                                                       // 128
  Router.prototype.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {                         // 129
    process.env.NODE_ENV !== 'production' ? _warning2['default'](nextProps.history === this.props.history, 'You cannot change <Router history>; it will be ignored') : undefined;
  };                                                                                                                   // 131
                                                                                                                       // 132
  Router.prototype.componentWillUnmount = function componentWillUnmount() {                                            // 133
    if (this._unlisten) this._unlisten();                                                                              // 134
  };                                                                                                                   // 135
                                                                                                                       // 136
  Router.prototype.render = function render() {                                                                        // 137
    var _state = this.state;                                                                                           // 138
    var location = _state.location;                                                                                    // 139
    var routes = _state.routes;                                                                                        // 140
    var params = _state.params;                                                                                        // 141
    var components = _state.components;                                                                                // 142
    var _props2 = this.props;                                                                                          // 143
    var RoutingContext = _props2.RoutingContext;                                                                       // 144
    var createElement = _props2.createElement;                                                                         // 145
                                                                                                                       // 146
    var props = _objectWithoutProperties(_props2, ['RoutingContext', 'createElement']);                                // 147
                                                                                                                       // 148
    if (location == null) return null; // Async match                                                                  // 149
                                                                                                                       // 150
    // Only forward non-Router-specific props to routing context, as those are                                         // 151
    // the only ones that might be custom routing context props.                                                       // 152
    Object.keys(Router.propTypes).forEach(function (propType) {                                                        // 153
      return delete props[propType];                                                                                   // 154
    });                                                                                                                // 155
                                                                                                                       // 156
    return _react2['default'].createElement(RoutingContext, _extends({}, props, {                                      // 157
      history: this.history,                                                                                           // 158
      createElement: createElement,                                                                                    // 159
      location: location,                                                                                              // 160
      routes: routes,                                                                                                  // 161
      params: params,                                                                                                  // 162
      components: components                                                                                           // 163
    }));                                                                                                               // 164
  };                                                                                                                   // 165
                                                                                                                       // 166
  return Router;                                                                                                       // 167
})(_react.Component);                                                                                                  // 168
                                                                                                                       // 169
exports['default'] = Router;                                                                                           // 170
module.exports = exports['default'];                                                                                   // 171
}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{"./PropTypes":41,"./RouteUtils":45,"./RoutingContext":47,"./useRoutes":56,"_process":1,"history/lib/createHashHistory":10,"warning":58}],47:[function(require,module,exports){
(function (process,global){                                                                                            //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }
                                                                                                                       // 10
function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
                                                                                                                       // 12
var _invariant = require('invariant');                                                                                 // 13
                                                                                                                       // 14
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 15
                                                                                                                       // 16
var _react = (typeof window !== "undefined" ? window['React'] : typeof global !== "undefined" ? global['React'] : null);
                                                                                                                       // 18
var _react2 = _interopRequireDefault(_react);                                                                          // 19
                                                                                                                       // 20
var _RouteUtils = require('./RouteUtils');                                                                             // 21
                                                                                                                       // 22
var _getRouteParams = require('./getRouteParams');                                                                     // 23
                                                                                                                       // 24
var _getRouteParams2 = _interopRequireDefault(_getRouteParams);                                                        // 25
                                                                                                                       // 26
var _React$PropTypes = _react2['default'].PropTypes;                                                                   // 27
var array = _React$PropTypes.array;                                                                                    // 28
var func = _React$PropTypes.func;                                                                                      // 29
var object = _React$PropTypes.object;                                                                                  // 30
                                                                                                                       // 31
/**                                                                                                                    // 32
 * A <RoutingContext> renders the component tree for a given router state                                              // 33
 * and sets the history object and the current location in context.                                                    // 34
 */                                                                                                                    // 35
                                                                                                                       // 36
var RoutingContext = (function (_Component) {                                                                          // 37
  _inherits(RoutingContext, _Component);                                                                               // 38
                                                                                                                       // 39
  function RoutingContext() {                                                                                          // 40
    _classCallCheck(this, RoutingContext);                                                                             // 41
                                                                                                                       // 42
    _Component.apply(this, arguments);                                                                                 // 43
  }                                                                                                                    // 44
                                                                                                                       // 45
  RoutingContext.prototype.getChildContext = function getChildContext() {                                              // 46
    var _props = this.props;                                                                                           // 47
    var history = _props.history;                                                                                      // 48
    var location = _props.location;                                                                                    // 49
                                                                                                                       // 50
    return { history: history, location: location };                                                                   // 51
  };                                                                                                                   // 52
                                                                                                                       // 53
  RoutingContext.prototype.createElement = function createElement(component, props) {                                  // 54
    return component == null ? null : this.props.createElement(component, props);                                      // 55
  };                                                                                                                   // 56
                                                                                                                       // 57
  RoutingContext.prototype.render = function render() {                                                                // 58
    var _this = this;                                                                                                  // 59
                                                                                                                       // 60
    var _props2 = this.props;                                                                                          // 61
    var history = _props2.history;                                                                                     // 62
    var location = _props2.location;                                                                                   // 63
    var routes = _props2.routes;                                                                                       // 64
    var params = _props2.params;                                                                                       // 65
    var components = _props2.components;                                                                               // 66
                                                                                                                       // 67
    var element = null;                                                                                                // 68
                                                                                                                       // 69
    if (components) {                                                                                                  // 70
      element = components.reduceRight(function (element, components, index) {                                         // 71
        if (components == null) return element; // Don't create new children; use the grandchildren.                   // 72
                                                                                                                       // 73
        var route = routes[index];                                                                                     // 74
        var routeParams = _getRouteParams2['default'](route, params);                                                  // 75
        var props = {                                                                                                  // 76
          history: history,                                                                                            // 77
          location: location,                                                                                          // 78
          params: params,                                                                                              // 79
          route: route,                                                                                                // 80
          routeParams: routeParams,                                                                                    // 81
          routes: routes                                                                                               // 82
        };                                                                                                             // 83
                                                                                                                       // 84
        if (_RouteUtils.isReactChildren(element)) {                                                                    // 85
          props.children = element;                                                                                    // 86
        } else if (element) {                                                                                          // 87
          for (var prop in element) {                                                                                  // 88
            if (element.hasOwnProperty(prop)) props[prop] = element[prop];                                             // 89
          }                                                                                                            // 90
        }                                                                                                              // 91
                                                                                                                       // 92
        if (typeof components === 'object') {                                                                          // 93
          var elements = {};                                                                                           // 94
                                                                                                                       // 95
          for (var key in components) {                                                                                // 96
            if (components.hasOwnProperty(key)) elements[key] = _this.createElement(components[key], props);           // 97
          }return elements;                                                                                            // 98
        }                                                                                                              // 99
                                                                                                                       // 100
        return _this.createElement(components, props);                                                                 // 101
      }, element);                                                                                                     // 102
    }                                                                                                                  // 103
                                                                                                                       // 104
    !(element === null || element === false || _react2['default'].isValidElement(element)) ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'The root route must render a single element') : _invariant2['default'](false) : undefined;
                                                                                                                       // 106
    return element;                                                                                                    // 107
  };                                                                                                                   // 108
                                                                                                                       // 109
  _createClass(RoutingContext, null, [{                                                                                // 110
    key: 'propTypes',                                                                                                  // 111
    value: {                                                                                                           // 112
      history: object.isRequired,                                                                                      // 113
      createElement: func.isRequired,                                                                                  // 114
      location: object.isRequired,                                                                                     // 115
      routes: array.isRequired,                                                                                        // 116
      params: object.isRequired,                                                                                       // 117
      components: array.isRequired                                                                                     // 118
    },                                                                                                                 // 119
    enumerable: true                                                                                                   // 120
  }, {                                                                                                                 // 121
    key: 'defaultProps',                                                                                               // 122
    value: {                                                                                                           // 123
      createElement: _react2['default'].createElement                                                                  // 124
    },                                                                                                                 // 125
    enumerable: true                                                                                                   // 126
  }, {                                                                                                                 // 127
    key: 'childContextTypes',                                                                                          // 128
    value: {                                                                                                           // 129
      history: object.isRequired,                                                                                      // 130
      location: object.isRequired                                                                                      // 131
    },                                                                                                                 // 132
    enumerable: true                                                                                                   // 133
  }]);                                                                                                                 // 134
                                                                                                                       // 135
  return RoutingContext;                                                                                               // 136
})(_react.Component);                                                                                                  // 137
                                                                                                                       // 138
exports['default'] = RoutingContext;                                                                                   // 139
module.exports = exports['default'];                                                                                   // 140
}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                                                                                                                       //
},{"./RouteUtils":45,"./getRouteParams":51,"_process":1,"invariant":57}],48:[function(require,module,exports){         //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
exports.runEnterHooks = runEnterHooks;                                                                                 // 4
exports.runLeaveHooks = runLeaveHooks;                                                                                 // 5
                                                                                                                       // 6
var _AsyncUtils = require('./AsyncUtils');                                                                             // 7
                                                                                                                       // 8
function createEnterHook(hook, route) {                                                                                // 9
  return function (a, b, callback) {                                                                                   // 10
    hook.apply(route, arguments);                                                                                      // 11
                                                                                                                       // 12
    if (hook.length < 3) {                                                                                             // 13
      // Assume hook executes synchronously and                                                                        // 14
      // automatically call the callback.                                                                              // 15
      callback();                                                                                                      // 16
    }                                                                                                                  // 17
  };                                                                                                                   // 18
}                                                                                                                      // 19
                                                                                                                       // 20
function getEnterHooks(routes) {                                                                                       // 21
  return routes.reduce(function (hooks, route) {                                                                       // 22
    if (route.onEnter) hooks.push(createEnterHook(route.onEnter, route));                                              // 23
                                                                                                                       // 24
    return hooks;                                                                                                      // 25
  }, []);                                                                                                              // 26
}                                                                                                                      // 27
                                                                                                                       // 28
/**                                                                                                                    // 29
 * Runs all onEnter hooks in the given array of routes in order                                                        // 30
 * with onEnter(nextState, replaceState, callback) and calls                                                           // 31
 * callback(error, redirectInfo) when finished. The first hook                                                         // 32
 * to use replaceState short-circuits the loop.                                                                        // 33
 *                                                                                                                     // 34
 * If a hook needs to run asynchronously, it may use the callback                                                      // 35
 * function. However, doing so will cause the transition to pause,                                                     // 36
 * which could lead to a non-responsive UI if the hook is slow.                                                        // 37
 */                                                                                                                    // 38
                                                                                                                       // 39
function runEnterHooks(routes, nextState, callback) {                                                                  // 40
  var hooks = getEnterHooks(routes);                                                                                   // 41
                                                                                                                       // 42
  if (!hooks.length) {                                                                                                 // 43
    callback();                                                                                                        // 44
    return;                                                                                                            // 45
  }                                                                                                                    // 46
                                                                                                                       // 47
  var redirectInfo = undefined;                                                                                        // 48
  function replaceState(state, pathname, query) {                                                                      // 49
    redirectInfo = { pathname: pathname, query: query, state: state };                                                 // 50
  }                                                                                                                    // 51
                                                                                                                       // 52
  _AsyncUtils.loopAsync(hooks.length, function (index, next, done) {                                                   // 53
    hooks[index](nextState, replaceState, function (error) {                                                           // 54
      if (error || redirectInfo) {                                                                                     // 55
        done(error, redirectInfo); // No need to continue.                                                             // 56
      } else {                                                                                                         // 57
          next();                                                                                                      // 58
        }                                                                                                              // 59
    });                                                                                                                // 60
  }, callback);                                                                                                        // 61
}                                                                                                                      // 62
                                                                                                                       // 63
/**                                                                                                                    // 64
 * Runs all onLeave hooks in the given array of routes in order.                                                       // 65
 */                                                                                                                    // 66
                                                                                                                       // 67
function runLeaveHooks(routes) {                                                                                       // 68
  for (var i = 0, len = routes.length; i < len; ++i) {                                                                 // 69
    if (routes[i].onLeave) routes[i].onLeave.call(routes[i]);                                                          // 70
  }                                                                                                                    // 71
}                                                                                                                      // 72
},{"./AsyncUtils":33}],49:[function(require,module,exports){                                                           //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _PatternUtils = require('./PatternUtils');                                                                         // 5
                                                                                                                       // 6
function routeParamsChanged(route, prevState, nextState) {                                                             // 7
  if (!route.path) return false;                                                                                       // 8
                                                                                                                       // 9
  var paramNames = _PatternUtils.getParamNames(route.path);                                                            // 10
                                                                                                                       // 11
  return paramNames.some(function (paramName) {                                                                        // 12
    return prevState.params[paramName] !== nextState.params[paramName];                                                // 13
  });                                                                                                                  // 14
}                                                                                                                      // 15
                                                                                                                       // 16
/**                                                                                                                    // 17
 * Returns an object of { leaveRoutes, enterRoutes } determined by                                                     // 18
 * the change from prevState to nextState. We leave routes if either                                                   // 19
 * 1) they are not in the next state or 2) they are in the next state                                                  // 20
 * but their params have changed (i.e. /users/123 => /users/456).                                                      // 21
 *                                                                                                                     // 22
 * leaveRoutes are ordered starting at the leaf route of the tree                                                      // 23
 * we're leaving up to the common parent route. enterRoutes are ordered                                                // 24
 * from the top of the tree we're entering down to the leaf route.                                                     // 25
 */                                                                                                                    // 26
function computeChangedRoutes(prevState, nextState) {                                                                  // 27
  var prevRoutes = prevState && prevState.routes;                                                                      // 28
  var nextRoutes = nextState.routes;                                                                                   // 29
                                                                                                                       // 30
  var leaveRoutes = undefined,                                                                                         // 31
      enterRoutes = undefined;                                                                                         // 32
  if (prevRoutes) {                                                                                                    // 33
    leaveRoutes = prevRoutes.filter(function (route) {                                                                 // 34
      return nextRoutes.indexOf(route) === -1 || routeParamsChanged(route, prevState, nextState);                      // 35
    });                                                                                                                // 36
                                                                                                                       // 37
    // onLeave hooks start at the leaf route.                                                                          // 38
    leaveRoutes.reverse();                                                                                             // 39
                                                                                                                       // 40
    enterRoutes = nextRoutes.filter(function (route) {                                                                 // 41
      return prevRoutes.indexOf(route) === -1 || leaveRoutes.indexOf(route) !== -1;                                    // 42
    });                                                                                                                // 43
  } else {                                                                                                             // 44
    leaveRoutes = [];                                                                                                  // 45
    enterRoutes = nextRoutes;                                                                                          // 46
  }                                                                                                                    // 47
                                                                                                                       // 48
  return {                                                                                                             // 49
    leaveRoutes: leaveRoutes,                                                                                          // 50
    enterRoutes: enterRoutes                                                                                           // 51
  };                                                                                                                   // 52
}                                                                                                                      // 53
                                                                                                                       // 54
exports['default'] = computeChangedRoutes;                                                                             // 55
module.exports = exports['default'];                                                                                   // 56
},{"./PatternUtils":40}],50:[function(require,module,exports){                                                         //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _AsyncUtils = require('./AsyncUtils');                                                                             // 5
                                                                                                                       // 6
function getComponentsForRoute(location, route, callback) {                                                            // 7
  if (route.component || route.components) {                                                                           // 8
    callback(null, route.component || route.components);                                                               // 9
  } else if (route.getComponent) {                                                                                     // 10
    route.getComponent(location, callback);                                                                            // 11
  } else if (route.getComponents) {                                                                                    // 12
    route.getComponents(location, callback);                                                                           // 13
  } else {                                                                                                             // 14
    callback();                                                                                                        // 15
  }                                                                                                                    // 16
}                                                                                                                      // 17
                                                                                                                       // 18
/**                                                                                                                    // 19
 * Asynchronously fetches all components needed for the given router                                                   // 20
 * state and calls callback(error, components) when finished.                                                          // 21
 *                                                                                                                     // 22
 * Note: This operation may finish synchronously if no routes have an                                                  // 23
 * asynchronous getComponents method.                                                                                  // 24
 */                                                                                                                    // 25
function getComponents(nextState, callback) {                                                                          // 26
  _AsyncUtils.mapAsync(nextState.routes, function (route, index, callback) {                                           // 27
    getComponentsForRoute(nextState.location, route, callback);                                                        // 28
  }, callback);                                                                                                        // 29
}                                                                                                                      // 30
                                                                                                                       // 31
exports['default'] = getComponents;                                                                                    // 32
module.exports = exports['default'];                                                                                   // 33
},{"./AsyncUtils":33}],51:[function(require,module,exports){                                                           //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _PatternUtils = require('./PatternUtils');                                                                         // 5
                                                                                                                       // 6
/**                                                                                                                    // 7
 * Extracts an object of params the given route cares about from                                                       // 8
 * the given params object.                                                                                            // 9
 */                                                                                                                    // 10
function getRouteParams(route, params) {                                                                               // 11
  var routeParams = {};                                                                                                // 12
                                                                                                                       // 13
  if (!route.path) return routeParams;                                                                                 // 14
                                                                                                                       // 15
  var paramNames = _PatternUtils.getParamNames(route.path);                                                            // 16
                                                                                                                       // 17
  for (var p in params) {                                                                                              // 18
    if (params.hasOwnProperty(p) && paramNames.indexOf(p) !== -1) routeParams[p] = params[p];                          // 19
  }return routeParams;                                                                                                 // 20
}                                                                                                                      // 21
                                                                                                                       // 22
exports['default'] = getRouteParams;                                                                                   // 23
module.exports = exports['default'];                                                                                   // 24
},{"./PatternUtils":40}],52:[function(require,module,exports){                                                         //
/* components */                                                                                                       // 1
'use strict';                                                                                                          // 2
                                                                                                                       // 3
exports.__esModule = true;                                                                                             // 4
                                                                                                                       // 5
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 6
                                                                                                                       // 7
var _Router2 = require('./Router');                                                                                    // 8
                                                                                                                       // 9
var _Router3 = _interopRequireDefault(_Router2);                                                                       // 10
                                                                                                                       // 11
exports.Router = _Router3['default'];                                                                                  // 12
                                                                                                                       // 13
var _Link2 = require('./Link');                                                                                        // 14
                                                                                                                       // 15
var _Link3 = _interopRequireDefault(_Link2);                                                                           // 16
                                                                                                                       // 17
exports.Link = _Link3['default'];                                                                                      // 18
                                                                                                                       // 19
var _IndexLink2 = require('./IndexLink');                                                                              // 20
                                                                                                                       // 21
var _IndexLink3 = _interopRequireDefault(_IndexLink2);                                                                 // 22
                                                                                                                       // 23
exports.IndexLink = _IndexLink3['default'];                                                                            // 24
                                                                                                                       // 25
/* components (configuration) */                                                                                       // 26
                                                                                                                       // 27
var _IndexRedirect2 = require('./IndexRedirect');                                                                      // 28
                                                                                                                       // 29
var _IndexRedirect3 = _interopRequireDefault(_IndexRedirect2);                                                         // 30
                                                                                                                       // 31
exports.IndexRedirect = _IndexRedirect3['default'];                                                                    // 32
                                                                                                                       // 33
var _IndexRoute2 = require('./IndexRoute');                                                                            // 34
                                                                                                                       // 35
var _IndexRoute3 = _interopRequireDefault(_IndexRoute2);                                                               // 36
                                                                                                                       // 37
exports.IndexRoute = _IndexRoute3['default'];                                                                          // 38
                                                                                                                       // 39
var _Redirect2 = require('./Redirect');                                                                                // 40
                                                                                                                       // 41
var _Redirect3 = _interopRequireDefault(_Redirect2);                                                                   // 42
                                                                                                                       // 43
exports.Redirect = _Redirect3['default'];                                                                              // 44
                                                                                                                       // 45
var _Route2 = require('./Route');                                                                                      // 46
                                                                                                                       // 47
var _Route3 = _interopRequireDefault(_Route2);                                                                         // 48
                                                                                                                       // 49
exports.Route = _Route3['default'];                                                                                    // 50
                                                                                                                       // 51
/* mixins */                                                                                                           // 52
                                                                                                                       // 53
var _History2 = require('./History');                                                                                  // 54
                                                                                                                       // 55
var _History3 = _interopRequireDefault(_History2);                                                                     // 56
                                                                                                                       // 57
exports.History = _History3['default'];                                                                                // 58
                                                                                                                       // 59
var _Lifecycle2 = require('./Lifecycle');                                                                              // 60
                                                                                                                       // 61
var _Lifecycle3 = _interopRequireDefault(_Lifecycle2);                                                                 // 62
                                                                                                                       // 63
exports.Lifecycle = _Lifecycle3['default'];                                                                            // 64
                                                                                                                       // 65
var _RouteContext2 = require('./RouteContext');                                                                        // 66
                                                                                                                       // 67
var _RouteContext3 = _interopRequireDefault(_RouteContext2);                                                           // 68
                                                                                                                       // 69
exports.RouteContext = _RouteContext3['default'];                                                                      // 70
                                                                                                                       // 71
/* utils */                                                                                                            // 72
                                                                                                                       // 73
var _useRoutes2 = require('./useRoutes');                                                                              // 74
                                                                                                                       // 75
var _useRoutes3 = _interopRequireDefault(_useRoutes2);                                                                 // 76
                                                                                                                       // 77
exports.useRoutes = _useRoutes3['default'];                                                                            // 78
                                                                                                                       // 79
var _RouteUtils = require('./RouteUtils');                                                                             // 80
                                                                                                                       // 81
exports.createRoutes = _RouteUtils.createRoutes;                                                                       // 82
                                                                                                                       // 83
var _RoutingContext2 = require('./RoutingContext');                                                                    // 84
                                                                                                                       // 85
var _RoutingContext3 = _interopRequireDefault(_RoutingContext2);                                                       // 86
                                                                                                                       // 87
exports.RoutingContext = _RoutingContext3['default'];                                                                  // 88
                                                                                                                       // 89
var _PropTypes2 = require('./PropTypes');                                                                              // 90
                                                                                                                       // 91
var _PropTypes3 = _interopRequireDefault(_PropTypes2);                                                                 // 92
                                                                                                                       // 93
exports.PropTypes = _PropTypes3['default'];                                                                            // 94
                                                                                                                       // 95
var _match2 = require('./match');                                                                                      // 96
                                                                                                                       // 97
var _match3 = _interopRequireDefault(_match2);                                                                         // 98
                                                                                                                       // 99
exports.match = _match3['default'];                                                                                    // 100
                                                                                                                       // 101
var _Router4 = _interopRequireDefault(_Router2);                                                                       // 102
                                                                                                                       // 103
exports['default'] = _Router4['default'];                                                                              // 104
},{"./History":34,"./IndexLink":35,"./IndexRedirect":36,"./IndexRoute":37,"./Lifecycle":38,"./Link":39,"./PropTypes":41,"./Redirect":42,"./Route":43,"./RouteContext":44,"./RouteUtils":45,"./Router":46,"./RoutingContext":47,"./match":54,"./useRoutes":56}],53:[function(require,module,exports){
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _PatternUtils = require('./PatternUtils');                                                                         // 5
                                                                                                                       // 6
function deepEqual(a, b) {                                                                                             // 7
  if (a == b) return true;                                                                                             // 8
                                                                                                                       // 9
  if (a == null || b == null) return false;                                                                            // 10
                                                                                                                       // 11
  if (Array.isArray(a)) {                                                                                              // 12
    return Array.isArray(b) && a.length === b.length && a.every(function (item, index) {                               // 13
      return deepEqual(item, b[index]);                                                                                // 14
    });                                                                                                                // 15
  }                                                                                                                    // 16
                                                                                                                       // 17
  if (typeof a === 'object') {                                                                                         // 18
    for (var p in a) {                                                                                                 // 19
      if (!a.hasOwnProperty(p)) {                                                                                      // 20
        continue;                                                                                                      // 21
      }                                                                                                                // 22
                                                                                                                       // 23
      if (a[p] === undefined) {                                                                                        // 24
        if (b[p] !== undefined) {                                                                                      // 25
          return false;                                                                                                // 26
        }                                                                                                              // 27
      } else if (!b.hasOwnProperty(p)) {                                                                               // 28
        return false;                                                                                                  // 29
      } else if (!deepEqual(a[p], b[p])) {                                                                             // 30
        return false;                                                                                                  // 31
      }                                                                                                                // 32
    }                                                                                                                  // 33
                                                                                                                       // 34
    return true;                                                                                                       // 35
  }                                                                                                                    // 36
                                                                                                                       // 37
  return String(a) === String(b);                                                                                      // 38
}                                                                                                                      // 39
                                                                                                                       // 40
function paramsAreActive(paramNames, paramValues, activeParams) {                                                      // 41
  // FIXME: This doesn't work on repeated params in activeParams.                                                      // 42
  return paramNames.every(function (paramName, index) {                                                                // 43
    return String(paramValues[index]) === String(activeParams[paramName]);                                             // 44
  });                                                                                                                  // 45
}                                                                                                                      // 46
                                                                                                                       // 47
function getMatchingRouteIndex(pathname, activeRoutes, activeParams) {                                                 // 48
  var remainingPathname = pathname,                                                                                    // 49
      paramNames = [],                                                                                                 // 50
      paramValues = [];                                                                                                // 51
                                                                                                                       // 52
  for (var i = 0, len = activeRoutes.length; i < len; ++i) {                                                           // 53
    var route = activeRoutes[i];                                                                                       // 54
    var pattern = route.path || '';                                                                                    // 55
                                                                                                                       // 56
    if (pattern.charAt(0) === '/') {                                                                                   // 57
      remainingPathname = pathname;                                                                                    // 58
      paramNames = [];                                                                                                 // 59
      paramValues = [];                                                                                                // 60
    }                                                                                                                  // 61
                                                                                                                       // 62
    if (remainingPathname !== null) {                                                                                  // 63
      var matched = _PatternUtils.matchPattern(pattern, remainingPathname);                                            // 64
      remainingPathname = matched.remainingPathname;                                                                   // 65
      paramNames = [].concat(paramNames, matched.paramNames);                                                          // 66
      paramValues = [].concat(paramValues, matched.paramValues);                                                       // 67
    }                                                                                                                  // 68
                                                                                                                       // 69
    if (remainingPathname === '' && route.path && paramsAreActive(paramNames, paramValues, activeParams)) return i;    // 70
  }                                                                                                                    // 71
                                                                                                                       // 72
  return null;                                                                                                         // 73
}                                                                                                                      // 74
                                                                                                                       // 75
/**                                                                                                                    // 76
 * Returns true if the given pathname matches the active routes                                                        // 77
 * and params.                                                                                                         // 78
 */                                                                                                                    // 79
function routeIsActive(pathname, routes, params, indexOnly) {                                                          // 80
  var i = getMatchingRouteIndex(pathname, routes, params);                                                             // 81
                                                                                                                       // 82
  if (i === null) {                                                                                                    // 83
    // No match.                                                                                                       // 84
    return false;                                                                                                      // 85
  } else if (!indexOnly) {                                                                                             // 86
    // Any match is good enough.                                                                                       // 87
    return true;                                                                                                       // 88
  }                                                                                                                    // 89
                                                                                                                       // 90
  // If any remaining routes past the match index have paths, then we can't                                            // 91
  // be on the index route.                                                                                            // 92
  return routes.slice(i + 1).every(function (route) {                                                                  // 93
    return !route.path;                                                                                                // 94
  });                                                                                                                  // 95
}                                                                                                                      // 96
                                                                                                                       // 97
/**                                                                                                                    // 98
 * Returns true if all key/value pairs in the given query are                                                          // 99
 * currently active.                                                                                                   // 100
 */                                                                                                                    // 101
function queryIsActive(query, activeQuery) {                                                                           // 102
  if (activeQuery == null) return query == null;                                                                       // 103
                                                                                                                       // 104
  if (query == null) return true;                                                                                      // 105
                                                                                                                       // 106
  return deepEqual(query, activeQuery);                                                                                // 107
}                                                                                                                      // 108
                                                                                                                       // 109
/**                                                                                                                    // 110
 * Returns true if a <Link> to the given pathname/query combination is                                                 // 111
 * currently active.                                                                                                   // 112
 */                                                                                                                    // 113
function isActive(pathname, query, indexOnly, location, routes, params) {                                              // 114
  if (location == null) return false;                                                                                  // 115
                                                                                                                       // 116
  if (!routeIsActive(pathname, routes, params, indexOnly)) return false;                                               // 117
                                                                                                                       // 118
  return queryIsActive(query, location.query);                                                                         // 119
}                                                                                                                      // 120
                                                                                                                       // 121
exports['default'] = isActive;                                                                                         // 122
module.exports = exports['default'];                                                                                   // 123
},{"./PatternUtils":40}],54:[function(require,module,exports){                                                         //
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
var _invariant = require('invariant');                                                                                 // 9
                                                                                                                       // 10
var _invariant2 = _interopRequireDefault(_invariant);                                                                  // 11
                                                                                                                       // 12
var _historyLibCreateMemoryHistory = require('history/lib/createMemoryHistory');                                       // 13
                                                                                                                       // 14
var _historyLibCreateMemoryHistory2 = _interopRequireDefault(_historyLibCreateMemoryHistory);                          // 15
                                                                                                                       // 16
var _historyLibUseBasename = require('history/lib/useBasename');                                                       // 17
                                                                                                                       // 18
var _historyLibUseBasename2 = _interopRequireDefault(_historyLibUseBasename);                                          // 19
                                                                                                                       // 20
var _RouteUtils = require('./RouteUtils');                                                                             // 21
                                                                                                                       // 22
var _useRoutes = require('./useRoutes');                                                                               // 23
                                                                                                                       // 24
var _useRoutes2 = _interopRequireDefault(_useRoutes);                                                                  // 25
                                                                                                                       // 26
var createHistory = _useRoutes2['default'](_historyLibUseBasename2['default'](_historyLibCreateMemoryHistory2['default']));
                                                                                                                       // 28
/**                                                                                                                    // 29
 * A high-level API to be used for server-side rendering.                                                              // 30
 *                                                                                                                     // 31
 * This function matches a location to a set of routes and calls                                                       // 32
 * callback(error, redirectLocation, renderProps) when finished.                                                       // 33
 *                                                                                                                     // 34
 * Note: You probably don't want to use this in a browser. Use                                                         // 35
 * the history.listen API instead.                                                                                     // 36
 */                                                                                                                    // 37
function match(_ref, callback) {                                                                                       // 38
  var routes = _ref.routes;                                                                                            // 39
  var location = _ref.location;                                                                                        // 40
  var parseQueryString = _ref.parseQueryString;                                                                        // 41
  var stringifyQuery = _ref.stringifyQuery;                                                                            // 42
  var basename = _ref.basename;                                                                                        // 43
                                                                                                                       // 44
  !location ? process.env.NODE_ENV !== 'production' ? _invariant2['default'](false, 'match needs a location') : _invariant2['default'](false) : undefined;
                                                                                                                       // 46
  var history = createHistory({                                                                                        // 47
    routes: _RouteUtils.createRoutes(routes),                                                                          // 48
    parseQueryString: parseQueryString,                                                                                // 49
    stringifyQuery: stringifyQuery,                                                                                    // 50
    basename: basename                                                                                                 // 51
  });                                                                                                                  // 52
                                                                                                                       // 53
  // Allow match({ location: '/the/path', ... })                                                                       // 54
  if (typeof location === 'string') location = history.createLocation(location);                                       // 55
                                                                                                                       // 56
  history.match(location, function (error, redirectLocation, nextState) {                                              // 57
    callback(error, redirectLocation, nextState && _extends({}, nextState, { history: history }));                     // 58
  });                                                                                                                  // 59
}                                                                                                                      // 60
                                                                                                                       // 61
exports['default'] = match;                                                                                            // 62
module.exports = exports['default'];                                                                                   // 63
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"./RouteUtils":45,"./useRoutes":56,"_process":1,"history/lib/createMemoryHistory":13,"history/lib/useBasename":21,"invariant":57}],55:[function(require,module,exports){
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 5
                                                                                                                       // 6
var _warning = require('warning');                                                                                     // 7
                                                                                                                       // 8
var _warning2 = _interopRequireDefault(_warning);                                                                      // 9
                                                                                                                       // 10
var _AsyncUtils = require('./AsyncUtils');                                                                             // 11
                                                                                                                       // 12
var _PatternUtils = require('./PatternUtils');                                                                         // 13
                                                                                                                       // 14
var _RouteUtils = require('./RouteUtils');                                                                             // 15
                                                                                                                       // 16
function getChildRoutes(route, location, callback) {                                                                   // 17
  if (route.childRoutes) {                                                                                             // 18
    callback(null, route.childRoutes);                                                                                 // 19
  } else if (route.getChildRoutes) {                                                                                   // 20
    route.getChildRoutes(location, function (error, childRoutes) {                                                     // 21
      callback(error, !error && _RouteUtils.createRoutes(childRoutes));                                                // 22
    });                                                                                                                // 23
  } else {                                                                                                             // 24
    callback();                                                                                                        // 25
  }                                                                                                                    // 26
}                                                                                                                      // 27
                                                                                                                       // 28
function getIndexRoute(route, location, callback) {                                                                    // 29
  if (route.indexRoute) {                                                                                              // 30
    callback(null, route.indexRoute);                                                                                  // 31
  } else if (route.getIndexRoute) {                                                                                    // 32
    route.getIndexRoute(location, function (error, indexRoute) {                                                       // 33
      callback(error, !error && _RouteUtils.createRoutes(indexRoute)[0]);                                              // 34
    });                                                                                                                // 35
  } else if (route.childRoutes) {                                                                                      // 36
    (function () {                                                                                                     // 37
      var pathless = route.childRoutes.filter(function (obj) {                                                         // 38
        return !obj.hasOwnProperty('path');                                                                            // 39
      });                                                                                                              // 40
                                                                                                                       // 41
      _AsyncUtils.loopAsync(pathless.length, function (index, next, done) {                                            // 42
        getIndexRoute(pathless[index], location, function (error, indexRoute) {                                        // 43
          if (error || indexRoute) {                                                                                   // 44
            var routes = [pathless[index]].concat(Array.isArray(indexRoute) ? indexRoute : [indexRoute]);              // 45
            done(error, routes);                                                                                       // 46
          } else {                                                                                                     // 47
            next();                                                                                                    // 48
          }                                                                                                            // 49
        });                                                                                                            // 50
      }, function (err, routes) {                                                                                      // 51
        callback(null, routes);                                                                                        // 52
      });                                                                                                              // 53
    })();                                                                                                              // 54
  } else {                                                                                                             // 55
    callback();                                                                                                        // 56
  }                                                                                                                    // 57
}                                                                                                                      // 58
                                                                                                                       // 59
function assignParams(params, paramNames, paramValues) {                                                               // 60
  return paramNames.reduce(function (params, paramName, index) {                                                       // 61
    var paramValue = paramValues && paramValues[index];                                                                // 62
                                                                                                                       // 63
    if (Array.isArray(params[paramName])) {                                                                            // 64
      params[paramName].push(paramValue);                                                                              // 65
    } else if (paramName in params) {                                                                                  // 66
      params[paramName] = [params[paramName], paramValue];                                                             // 67
    } else {                                                                                                           // 68
      params[paramName] = paramValue;                                                                                  // 69
    }                                                                                                                  // 70
                                                                                                                       // 71
    return params;                                                                                                     // 72
  }, params);                                                                                                          // 73
}                                                                                                                      // 74
                                                                                                                       // 75
function createParams(paramNames, paramValues) {                                                                       // 76
  return assignParams({}, paramNames, paramValues);                                                                    // 77
}                                                                                                                      // 78
                                                                                                                       // 79
function matchRouteDeep(route, location, remainingPathname, paramNames, paramValues, callback) {                       // 80
  var pattern = route.path || '';                                                                                      // 81
                                                                                                                       // 82
  if (pattern.charAt(0) === '/') {                                                                                     // 83
    remainingPathname = location.pathname;                                                                             // 84
    paramNames = [];                                                                                                   // 85
    paramValues = [];                                                                                                  // 86
  }                                                                                                                    // 87
                                                                                                                       // 88
  if (remainingPathname !== null) {                                                                                    // 89
    var matched = _PatternUtils.matchPattern(pattern, remainingPathname);                                              // 90
    remainingPathname = matched.remainingPathname;                                                                     // 91
    paramNames = [].concat(paramNames, matched.paramNames);                                                            // 92
    paramValues = [].concat(paramValues, matched.paramValues);                                                         // 93
                                                                                                                       // 94
    if (remainingPathname === '' && route.path) {                                                                      // 95
      var _ret2 = (function () {                                                                                       // 96
        var match = {                                                                                                  // 97
          routes: [route],                                                                                             // 98
          params: createParams(paramNames, paramValues)                                                                // 99
        };                                                                                                             // 100
                                                                                                                       // 101
        getIndexRoute(route, location, function (error, indexRoute) {                                                  // 102
          if (error) {                                                                                                 // 103
            callback(error);                                                                                           // 104
          } else {                                                                                                     // 105
            if (Array.isArray(indexRoute)) {                                                                           // 106
              var _match$routes;                                                                                       // 107
                                                                                                                       // 108
              process.env.NODE_ENV !== 'production' ? _warning2['default'](indexRoute.every(function (route) {         // 109
                return !route.path;                                                                                    // 110
              }), 'Index routes should not have paths') : undefined;                                                   // 111
              (_match$routes = match.routes).push.apply(_match$routes, indexRoute);                                    // 112
            } else if (indexRoute) {                                                                                   // 113
              process.env.NODE_ENV !== 'production' ? _warning2['default'](!indexRoute.path, 'Index routes should not have paths') : undefined;
              match.routes.push(indexRoute);                                                                           // 115
            }                                                                                                          // 116
                                                                                                                       // 117
            callback(null, match);                                                                                     // 118
          }                                                                                                            // 119
        });                                                                                                            // 120
        return {                                                                                                       // 121
          v: undefined                                                                                                 // 122
        };                                                                                                             // 123
      })();                                                                                                            // 124
                                                                                                                       // 125
      if (typeof _ret2 === 'object') return _ret2.v;                                                                   // 126
    }                                                                                                                  // 127
  }                                                                                                                    // 128
                                                                                                                       // 129
  if (remainingPathname != null || route.childRoutes) {                                                                // 130
    // Either a) this route matched at least some of the path or b)                                                    // 131
    // we don't have to load this route's children asynchronously. In                                                  // 132
    // either case continue checking for matches in the subtree.                                                       // 133
    getChildRoutes(route, location, function (error, childRoutes) {                                                    // 134
      if (error) {                                                                                                     // 135
        callback(error);                                                                                               // 136
      } else if (childRoutes) {                                                                                        // 137
        // Check the child routes to see if any of them match.                                                         // 138
        matchRoutes(childRoutes, location, function (error, match) {                                                   // 139
          if (error) {                                                                                                 // 140
            callback(error);                                                                                           // 141
          } else if (match) {                                                                                          // 142
            // A child route matched! Augment the match and pass it up the stack.                                      // 143
            match.routes.unshift(route);                                                                               // 144
            callback(null, match);                                                                                     // 145
          } else {                                                                                                     // 146
            callback();                                                                                                // 147
          }                                                                                                            // 148
        }, remainingPathname, paramNames, paramValues);                                                                // 149
      } else {                                                                                                         // 150
        callback();                                                                                                    // 151
      }                                                                                                                // 152
    });                                                                                                                // 153
  } else {                                                                                                             // 154
    callback();                                                                                                        // 155
  }                                                                                                                    // 156
}                                                                                                                      // 157
                                                                                                                       // 158
/**                                                                                                                    // 159
 * Asynchronously matches the given location to a set of routes and calls                                              // 160
 * callback(error, state) when finished. The state object will have the                                                // 161
 * following properties:                                                                                               // 162
 *                                                                                                                     // 163
 * - routes       An array of routes that matched, in hierarchical order                                               // 164
 * - params       An object of URL parameters                                                                          // 165
 *                                                                                                                     // 166
 * Note: This operation may finish synchronously if no routes have an                                                  // 167
 * asynchronous getChildRoutes method.                                                                                 // 168
 */                                                                                                                    // 169
function matchRoutes(routes, location, callback) {                                                                     // 170
  var remainingPathname = arguments.length <= 3 || arguments[3] === undefined ? location.pathname : arguments[3];      // 171
  var paramNames = arguments.length <= 4 || arguments[4] === undefined ? [] : arguments[4];                            // 172
  var paramValues = arguments.length <= 5 || arguments[5] === undefined ? [] : arguments[5];                           // 173
  return (function () {                                                                                                // 174
    _AsyncUtils.loopAsync(routes.length, function (index, next, done) {                                                // 175
      matchRouteDeep(routes[index], location, remainingPathname, paramNames, paramValues, function (error, match) {    // 176
        if (error || match) {                                                                                          // 177
          done(error, match);                                                                                          // 178
        } else {                                                                                                       // 179
          next();                                                                                                      // 180
        }                                                                                                              // 181
      });                                                                                                              // 182
    }, callback);                                                                                                      // 183
  })();                                                                                                                // 184
}                                                                                                                      // 185
                                                                                                                       // 186
exports['default'] = matchRoutes;                                                                                      // 187
module.exports = exports['default'];                                                                                   // 188
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"./AsyncUtils":33,"./PatternUtils":40,"./RouteUtils":45,"_process":1,"warning":58}],56:[function(require,module,exports){
(function (process){                                                                                                   //
'use strict';                                                                                                          // 1
                                                                                                                       // 2
exports.__esModule = true;                                                                                             // 3
                                                                                                                       // 4
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
                                                                                                                       // 6
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                      // 7
                                                                                                                       // 8
function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }
                                                                                                                       // 10
var _warning = require('warning');                                                                                     // 11
                                                                                                                       // 12
var _warning2 = _interopRequireDefault(_warning);                                                                      // 13
                                                                                                                       // 14
var _historyLibActions = require('history/lib/Actions');                                                               // 15
                                                                                                                       // 16
var _historyLibUseQueries = require('history/lib/useQueries');                                                         // 17
                                                                                                                       // 18
var _historyLibUseQueries2 = _interopRequireDefault(_historyLibUseQueries);                                            // 19
                                                                                                                       // 20
var _computeChangedRoutes2 = require('./computeChangedRoutes');                                                        // 21
                                                                                                                       // 22
var _computeChangedRoutes3 = _interopRequireDefault(_computeChangedRoutes2);                                           // 23
                                                                                                                       // 24
var _TransitionUtils = require('./TransitionUtils');                                                                   // 25
                                                                                                                       // 26
var _isActive2 = require('./isActive');                                                                                // 27
                                                                                                                       // 28
var _isActive3 = _interopRequireDefault(_isActive2);                                                                   // 29
                                                                                                                       // 30
var _getComponents = require('./getComponents');                                                                       // 31
                                                                                                                       // 32
var _getComponents2 = _interopRequireDefault(_getComponents);                                                          // 33
                                                                                                                       // 34
var _matchRoutes = require('./matchRoutes');                                                                           // 35
                                                                                                                       // 36
var _matchRoutes2 = _interopRequireDefault(_matchRoutes);                                                              // 37
                                                                                                                       // 38
function hasAnyProperties(object) {                                                                                    // 39
  for (var p in object) {                                                                                              // 40
    if (object.hasOwnProperty(p)) return true;                                                                         // 41
  }return false;                                                                                                       // 42
}                                                                                                                      // 43
                                                                                                                       // 44
/**                                                                                                                    // 45
 * Returns a new createHistory function that may be used to create                                                     // 46
 * history objects that know about routing.                                                                            // 47
 *                                                                                                                     // 48
 * Enhances history objects with the following methods:                                                                // 49
 *                                                                                                                     // 50
 * - listen((error, nextState) => {})                                                                                  // 51
 * - listenBeforeLeavingRoute(route, (nextLocation) => {})                                                             // 52
 * - match(location, (error, redirectLocation, nextState) => {})                                                       // 53
 * - isActive(pathname, query, indexOnly=false)                                                                        // 54
 */                                                                                                                    // 55
function useRoutes(createHistory) {                                                                                    // 56
  return function () {                                                                                                 // 57
    var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];                             // 58
    var routes = options.routes;                                                                                       // 59
                                                                                                                       // 60
    var historyOptions = _objectWithoutProperties(options, ['routes']);                                                // 61
                                                                                                                       // 62
    var history = _historyLibUseQueries2['default'](createHistory)(historyOptions);                                    // 63
    var state = {};                                                                                                    // 64
                                                                                                                       // 65
    function isActive(pathname, query) {                                                                               // 66
      var indexOnly = arguments.length <= 2 || arguments[2] === undefined ? false : arguments[2];                      // 67
                                                                                                                       // 68
      return _isActive3['default'](pathname, query, indexOnly, state.location, state.routes, state.params);            // 69
    }                                                                                                                  // 70
                                                                                                                       // 71
    function createLocationFromRedirectInfo(_ref) {                                                                    // 72
      var pathname = _ref.pathname;                                                                                    // 73
      var query = _ref.query;                                                                                          // 74
      var state = _ref.state;                                                                                          // 75
                                                                                                                       // 76
      return history.createLocation(history.createPath(pathname, query), state, _historyLibActions.REPLACE);           // 77
    }                                                                                                                  // 78
                                                                                                                       // 79
    var partialNextState = undefined;                                                                                  // 80
                                                                                                                       // 81
    function match(location, callback) {                                                                               // 82
      if (partialNextState && partialNextState.location === location) {                                                // 83
        // Continue from where we left off.                                                                            // 84
        finishMatch(partialNextState, callback);                                                                       // 85
      } else {                                                                                                         // 86
        _matchRoutes2['default'](routes, location, function (error, nextState) {                                       // 87
          if (error) {                                                                                                 // 88
            callback(error);                                                                                           // 89
          } else if (nextState) {                                                                                      // 90
            finishMatch(_extends({}, nextState, { location: location }), callback);                                    // 91
          } else {                                                                                                     // 92
            callback();                                                                                                // 93
          }                                                                                                            // 94
        });                                                                                                            // 95
      }                                                                                                                // 96
    }                                                                                                                  // 97
                                                                                                                       // 98
    function finishMatch(nextState, callback) {                                                                        // 99
      var _computeChangedRoutes = _computeChangedRoutes3['default'](state, nextState);                                 // 100
                                                                                                                       // 101
      var leaveRoutes = _computeChangedRoutes.leaveRoutes;                                                             // 102
      var enterRoutes = _computeChangedRoutes.enterRoutes;                                                             // 103
                                                                                                                       // 104
      _TransitionUtils.runLeaveHooks(leaveRoutes);                                                                     // 105
                                                                                                                       // 106
      _TransitionUtils.runEnterHooks(enterRoutes, nextState, function (error, redirectInfo) {                          // 107
        if (error) {                                                                                                   // 108
          callback(error);                                                                                             // 109
        } else if (redirectInfo) {                                                                                     // 110
          callback(null, createLocationFromRedirectInfo(redirectInfo));                                                // 111
        } else {                                                                                                       // 112
          // TODO: Fetch components after state is updated.                                                            // 113
          _getComponents2['default'](nextState, function (error, components) {                                         // 114
            if (error) {                                                                                               // 115
              callback(error);                                                                                         // 116
            } else {                                                                                                   // 117
              // TODO: Make match a pure function and have some other API                                              // 118
              // for "match and update state".                                                                         // 119
              callback(null, null, state = _extends({}, nextState, { components: components }));                       // 120
            }                                                                                                          // 121
          });                                                                                                          // 122
        }                                                                                                              // 123
      });                                                                                                              // 124
    }                                                                                                                  // 125
                                                                                                                       // 126
    var RouteGuid = 1;                                                                                                 // 127
                                                                                                                       // 128
    function getRouteID(route) {                                                                                       // 129
      return route.__id__ || (route.__id__ = RouteGuid++);                                                             // 130
    }                                                                                                                  // 131
                                                                                                                       // 132
    var RouteHooks = {};                                                                                               // 133
                                                                                                                       // 134
    function getRouteHooksForRoutes(routes) {                                                                          // 135
      return routes.reduce(function (hooks, route) {                                                                   // 136
        hooks.push.apply(hooks, RouteHooks[getRouteID(route)]);                                                        // 137
        return hooks;                                                                                                  // 138
      }, []);                                                                                                          // 139
    }                                                                                                                  // 140
                                                                                                                       // 141
    function transitionHook(location, callback) {                                                                      // 142
      _matchRoutes2['default'](routes, location, function (error, nextState) {                                         // 143
        if (nextState == null) {                                                                                       // 144
          // TODO: We didn't actually match anything, but hang                                                         // 145
          // onto error/nextState so we don't have to matchRoutes                                                      // 146
          // again in the listen callback.                                                                             // 147
          callback();                                                                                                  // 148
          return;                                                                                                      // 149
        }                                                                                                              // 150
                                                                                                                       // 151
        // Cache some state here so we don't have to                                                                   // 152
        // matchRoutes() again in the listen callback.                                                                 // 153
        partialNextState = _extends({}, nextState, { location: location });                                            // 154
                                                                                                                       // 155
        var hooks = getRouteHooksForRoutes(_computeChangedRoutes3['default'](state, partialNextState).leaveRoutes);    // 156
                                                                                                                       // 157
        var result = undefined;                                                                                        // 158
        for (var i = 0, len = hooks.length; result == null && i < len; ++i) {                                          // 159
          // Passing the location arg here indicates to                                                                // 160
          // the user that this is a transition hook.                                                                  // 161
          result = hooks[i](location);                                                                                 // 162
        }                                                                                                              // 163
                                                                                                                       // 164
        callback(result);                                                                                              // 165
      });                                                                                                              // 166
    }                                                                                                                  // 167
                                                                                                                       // 168
    function beforeUnloadHook() {                                                                                      // 169
      // Synchronously check to see if any route hooks want                                                            // 170
      // to prevent the current window/tab from closing.                                                               // 171
      if (state.routes) {                                                                                              // 172
        var hooks = getRouteHooksForRoutes(state.routes);                                                              // 173
                                                                                                                       // 174
        var message = undefined;                                                                                       // 175
        for (var i = 0, len = hooks.length; typeof message !== 'string' && i < len; ++i) {                             // 176
          // Passing no args indicates to the user that this is a                                                      // 177
          // beforeunload hook. We don't know the next location.                                                       // 178
          message = hooks[i]();                                                                                        // 179
        }                                                                                                              // 180
                                                                                                                       // 181
        return message;                                                                                                // 182
      }                                                                                                                // 183
    }                                                                                                                  // 184
                                                                                                                       // 185
    var unlistenBefore = undefined,                                                                                    // 186
        unlistenBeforeUnload = undefined;                                                                              // 187
                                                                                                                       // 188
    /**                                                                                                                // 189
     * Registers the given hook function to run before leaving the given route.                                        // 190
     *                                                                                                                 // 191
     * During a normal transition, the hook function receives the next location                                        // 192
     * as its only argument and must return either a) a prompt message to show                                         // 193
     * the user, to make sure they want to leave the page or b) false, to prevent                                      // 194
     * the transition.                                                                                                 // 195
     *                                                                                                                 // 196
     * During the beforeunload event (in browsers) the hook receives no arguments.                                     // 197
     * In this case it must return a prompt message to prevent the transition.                                         // 198
     *                                                                                                                 // 199
     * Returns a function that may be used to unbind the listener.                                                     // 200
     */                                                                                                                // 201
    function listenBeforeLeavingRoute(route, hook) {                                                                   // 202
      // TODO: Warn if they register for a route that isn't currently                                                  // 203
      // active. They're probably doing something wrong, like re-creating                                              // 204
      // route objects on every location change.                                                                       // 205
      var routeID = getRouteID(route);                                                                                 // 206
      var hooks = RouteHooks[routeID];                                                                                 // 207
                                                                                                                       // 208
      if (hooks == null) {                                                                                             // 209
        var thereWereNoRouteHooks = !hasAnyProperties(RouteHooks);                                                     // 210
                                                                                                                       // 211
        hooks = RouteHooks[routeID] = [hook];                                                                          // 212
                                                                                                                       // 213
        if (thereWereNoRouteHooks) {                                                                                   // 214
          // setup transition & beforeunload hooks                                                                     // 215
          unlistenBefore = history.listenBefore(transitionHook);                                                       // 216
                                                                                                                       // 217
          if (history.listenBeforeUnload) unlistenBeforeUnload = history.listenBeforeUnload(beforeUnloadHook);         // 218
        }                                                                                                              // 219
      } else if (hooks.indexOf(hook) === -1) {                                                                         // 220
        hooks.push(hook);                                                                                              // 221
      }                                                                                                                // 222
                                                                                                                       // 223
      return function () {                                                                                             // 224
        var hooks = RouteHooks[routeID];                                                                               // 225
                                                                                                                       // 226
        if (hooks != null) {                                                                                           // 227
          var newHooks = hooks.filter(function (item) {                                                                // 228
            return item !== hook;                                                                                      // 229
          });                                                                                                          // 230
                                                                                                                       // 231
          if (newHooks.length === 0) {                                                                                 // 232
            delete RouteHooks[routeID];                                                                                // 233
                                                                                                                       // 234
            if (!hasAnyProperties(RouteHooks)) {                                                                       // 235
              // teardown transition & beforeunload hooks                                                              // 236
              if (unlistenBefore) {                                                                                    // 237
                unlistenBefore();                                                                                      // 238
                unlistenBefore = null;                                                                                 // 239
              }                                                                                                        // 240
                                                                                                                       // 241
              if (unlistenBeforeUnload) {                                                                              // 242
                unlistenBeforeUnload();                                                                                // 243
                unlistenBeforeUnload = null;                                                                           // 244
              }                                                                                                        // 245
            }                                                                                                          // 246
          } else {                                                                                                     // 247
            RouteHooks[routeID] = newHooks;                                                                            // 248
          }                                                                                                            // 249
        }                                                                                                              // 250
      };                                                                                                               // 251
    }                                                                                                                  // 252
                                                                                                                       // 253
    /**                                                                                                                // 254
     * This is the API for stateful environments. As the location                                                      // 255
     * changes, we update state and call the listener. We can also                                                     // 256
     * gracefully handle errors and redirects.                                                                         // 257
     */                                                                                                                // 258
    function listen(listener) {                                                                                        // 259
      // TODO: Only use a single history listener. Otherwise we'll                                                     // 260
      // end up with multiple concurrent calls to match.                                                               // 261
      return history.listen(function (location) {                                                                      // 262
        if (state.location === location) {                                                                             // 263
          listener(null, state);                                                                                       // 264
        } else {                                                                                                       // 265
          match(location, function (error, redirectLocation, nextState) {                                              // 266
            if (error) {                                                                                               // 267
              listener(error);                                                                                         // 268
            } else if (redirectLocation) {                                                                             // 269
              history.transitionTo(redirectLocation);                                                                  // 270
            } else if (nextState) {                                                                                    // 271
              listener(null, nextState);                                                                               // 272
            } else {                                                                                                   // 273
              process.env.NODE_ENV !== 'production' ? _warning2['default'](false, 'Location "%s" did not match any routes', location.pathname + location.search + location.hash) : undefined;
            }                                                                                                          // 275
          });                                                                                                          // 276
        }                                                                                                              // 277
      });                                                                                                              // 278
    }                                                                                                                  // 279
                                                                                                                       // 280
    return _extends({}, history, {                                                                                     // 281
      isActive: isActive,                                                                                              // 282
      match: match,                                                                                                    // 283
      listenBeforeLeavingRoute: listenBeforeLeavingRoute,                                                              // 284
      listen: listen                                                                                                   // 285
    });                                                                                                                // 286
  };                                                                                                                   // 287
}                                                                                                                      // 288
                                                                                                                       // 289
exports['default'] = useRoutes;                                                                                        // 290
module.exports = exports['default'];                                                                                   // 291
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"./TransitionUtils":48,"./computeChangedRoutes":49,"./getComponents":50,"./isActive":53,"./matchRoutes":55,"_process":1,"history/lib/Actions":3,"history/lib/useQueries":23,"warning":58}],57:[function(require,module,exports){
(function (process){                                                                                                   //
/**                                                                                                                    // 1
 * Copyright 2013-2015, Facebook, Inc.                                                                                 // 2
 * All rights reserved.                                                                                                // 3
 *                                                                                                                     // 4
 * This source code is licensed under the BSD-style license found in the                                               // 5
 * LICENSE file in the root directory of this source tree. An additional grant                                         // 6
 * of patent rights can be found in the PATENTS file in the same directory.                                            // 7
 */                                                                                                                    // 8
                                                                                                                       // 9
'use strict';                                                                                                          // 10
                                                                                                                       // 11
/**                                                                                                                    // 12
 * Use invariant() to assert state which your program assumes to be true.                                              // 13
 *                                                                                                                     // 14
 * Provide sprintf-style format (only %s is supported) and arguments                                                   // 15
 * to provide information about what broke and what you were                                                           // 16
 * expecting.                                                                                                          // 17
 *                                                                                                                     // 18
 * The invariant message will be stripped in production, but the invariant                                             // 19
 * will remain to ensure logic does not differ in production.                                                          // 20
 */                                                                                                                    // 21
                                                                                                                       // 22
var invariant = function(condition, format, a, b, c, d, e, f) {                                                        // 23
  if (process.env.NODE_ENV !== 'production') {                                                                         // 24
    if (format === undefined) {                                                                                        // 25
      throw new Error('invariant requires an error message argument');                                                 // 26
    }                                                                                                                  // 27
  }                                                                                                                    // 28
                                                                                                                       // 29
  if (!condition) {                                                                                                    // 30
    var error;                                                                                                         // 31
    if (format === undefined) {                                                                                        // 32
      error = new Error(                                                                                               // 33
        'Minified exception occurred; use the non-minified dev environment ' +                                         // 34
        'for the full error message and additional helpful warnings.'                                                  // 35
      );                                                                                                               // 36
    } else {                                                                                                           // 37
      var args = [a, b, c, d, e, f];                                                                                   // 38
      var argIndex = 0;                                                                                                // 39
      error = new Error(                                                                                               // 40
        format.replace(/%s/g, function() { return args[argIndex++]; })                                                 // 41
      );                                                                                                               // 42
      error.name = 'Invariant Violation';                                                                              // 43
    }                                                                                                                  // 44
                                                                                                                       // 45
    error.framesToPop = 1; // we don't care about invariant's own frame                                                // 46
    throw error;                                                                                                       // 47
  }                                                                                                                    // 48
};                                                                                                                     // 49
                                                                                                                       // 50
module.exports = invariant;                                                                                            // 51
                                                                                                                       // 52
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"_process":1}],58:[function(require,module,exports){                                                                //
(function (process){                                                                                                   //
/**                                                                                                                    // 1
 * Copyright 2014-2015, Facebook, Inc.                                                                                 // 2
 * All rights reserved.                                                                                                // 3
 *                                                                                                                     // 4
 * This source code is licensed under the BSD-style license found in the                                               // 5
 * LICENSE file in the root directory of this source tree. An additional grant                                         // 6
 * of patent rights can be found in the PATENTS file in the same directory.                                            // 7
 */                                                                                                                    // 8
                                                                                                                       // 9
'use strict';                                                                                                          // 10
                                                                                                                       // 11
/**                                                                                                                    // 12
 * Similar to invariant but only logs a warning if the condition is not met.                                           // 13
 * This can be used to log issues in development environments in critical                                              // 14
 * paths. Removing the logging code for production environments will keep the                                          // 15
 * same logic and follow the same code paths.                                                                          // 16
 */                                                                                                                    // 17
                                                                                                                       // 18
var warning = function() {};                                                                                           // 19
                                                                                                                       // 20
if (process.env.NODE_ENV !== 'production') {                                                                           // 21
  warning = function(condition, format, args) {                                                                        // 22
    var len = arguments.length;                                                                                        // 23
    args = new Array(len > 2 ? len - 2 : 0);                                                                           // 24
    for (var key = 2; key < len; key++) {                                                                              // 25
      args[key - 2] = arguments[key];                                                                                  // 26
    }                                                                                                                  // 27
    if (format === undefined) {                                                                                        // 28
      throw new Error(                                                                                                 // 29
        '`warning(condition, format, ...args)` requires a warning ' +                                                  // 30
        'message argument'                                                                                             // 31
      );                                                                                                               // 32
    }                                                                                                                  // 33
                                                                                                                       // 34
    if (format.length < 10 || (/^[s\W]*$/).test(format)) {                                                             // 35
      throw new Error(                                                                                                 // 36
        'The warning format should be able to uniquely identify this ' +                                               // 37
        'warning. Please, use a more descriptive format than: ' + format                                               // 38
      );                                                                                                               // 39
    }                                                                                                                  // 40
                                                                                                                       // 41
    if (!condition) {                                                                                                  // 42
      var argIndex = 0;                                                                                                // 43
      var message = 'Warning: ' +                                                                                      // 44
        format.replace(/%s/g, function() {                                                                             // 45
          return args[argIndex++];                                                                                     // 46
        });                                                                                                            // 47
      if (typeof console !== 'undefined') {                                                                            // 48
        console.error(message);                                                                                        // 49
      }                                                                                                                // 50
      try {                                                                                                            // 51
        // This error was thrown as a convenience so that you can use this stack                                       // 52
        // to find the callsite that caused this warning to fire.                                                      // 53
        throw new Error(message);                                                                                      // 54
      } catch(x) {}                                                                                                    // 55
    }                                                                                                                  // 56
  };                                                                                                                   // 57
}                                                                                                                      // 58
                                                                                                                       // 59
module.exports = warning;                                                                                              // 60
                                                                                                                       // 61
}).call(this,require('_process'))                                                                                      //
                                                                                                                       //
},{"_process":1}]},{},[2])                                                                                             //
//# sourceMappingURL=/packages/reactrouter_react-router/react-router.browserify.js                                     //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['reactrouter:react-router'] = {
  ReactRouter: ReactRouter
};

})();

//# sourceMappingURL=reactrouter_react-router.js.map
